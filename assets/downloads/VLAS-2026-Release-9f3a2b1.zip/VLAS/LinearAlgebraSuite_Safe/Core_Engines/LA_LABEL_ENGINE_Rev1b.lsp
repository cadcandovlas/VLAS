;=====================================================================
;  cadcando Visual Linear Algebra System (VLAS)
;  LA_LABEL_ENGINE � Rev1b (SAFE?REV)
;  Author: Chris A. LaFollette
;  Licensed for individual educational use after purchase.
;  Redistribution or modification without permission prohibited.
;
;  Revision 1b Notes:
;    � Added label-style selection prompt (A/B/C)
;    � Supports indexed, textbook, and hybrid notation
;    � Dynamic text height and lane offset
;    � Perpendicular lane placement
;    � REGEN after label creation to avoid outline flicker
;    � Multi-vector support for VP1�VP5
;; LA_LABEL_ENGINE  (Rev1c SMART, 2026-03-12)
;=====================================================================

;; ============================================================
;; GLOBAL: Label style for this session
;; ============================================================
(setq *LA-label-style* nil)   ;; nil = not chosen yet

;; ============================================================
;; PROMPT: Choose label style (A/B/C)
;; ============================================================
(defun LA:choose-style ( / s )
  (if (not *LA-label-style*)
    (progn
      (setq s
        (getstring
          "\nChoose label style:
   A = Indexed notation (v?, v?, v?�)
   B = Textbook letters (v, u, n, a, b)
   C = Hybrid (v?, u?, n?�)
 <Default = A>: "
        )
      )
      (cond
        ((or (eq s "") (eq (strcase s) "A"))
          (setq *LA-label-style* "A")
        )
        ((eq (strcase s) "B")
          (setq *LA-label-style* "B")
        )
        ((eq (strcase s) "C")
          (setq *LA-label-style* "C")
        )
        (T
          (princ "\nInvalid choice. Using A.")
          (setq *LA-label-style* "A")
        )
      )
    )
  )
  *LA-label-style*
)

;; ============================================================
;; UTILITY: Dynamic text height + lane offset
;; ============================================================
(defun LA:label-params (vx vy vz / mag baseH baseOff h off)
  (setq mag (sqrt (+ (* vx vx) (* vy vy) (* vz vz))))
  (setq baseH   0.20)
  (setq baseOff 0.30)

  (cond
    ((< mag 0.5) (setq h (* baseH 0.5)
                       off (* baseOff 0.5)))
    ((> mag 20.0) (setq h (* baseH 2.0)
                        off (* baseOff 2.0)))
    (T (setq h baseH
             off baseOff))
  )
  (list h off)
)

;; ============================================================
;; UTILITY: Build label strings based on style + index
;; ============================================================
(defun LA:build-label-strings (vx vy vz idx / style magStr xStr yStr zStr)
  (setq style (LA:choose-style))

  ;; magnitude
  (cond
    ((equal style "A")
      (setq magStr (strcat "|v" (itoa idx) "| = " (rtos (sqrt (+ (* vx vx) (* vy vy) (* vz vz))) 2 3)))
      (setq xStr   (strcat "x" (itoa idx) " = " (rtos vx 2 2)))
      (setq yStr   (strcat "y" (itoa idx) " = " (rtos vy 2 2)))
      (setq zStr   (strcat "z" (itoa idx) " = " (rtos vz 2 2)))
    )

    ((equal style "B")
      ;; textbook letters: v, u, n, a, b...
      (setq magStr (strcat "|v| = " (rtos (sqrt (+ (* vx vx) (* vy vy) (* vz vz))) 2 3)))
      (setq xStr   (strcat "x_v = " (rtos vx 2 2)))
      (setq yStr   (strcat "y_v = " (rtos vy 2 2)))
      (setq zStr   (strcat "z_v = " (rtos vz 2 2)))
    )

    ((equal style "C")
      ;; hybrid: v?, u?, n?...
      (setq magStr (strcat "|v" (itoa idx) "| = " (rtos (sqrt (+ (* vx vx) (* vy vy) (* vz vz))) 2 3)))
      (setq xStr   (strcat "x_v" (itoa idx) " = " (rtos vx 2 2)))
      (setq yStr   (strcat "y_v" (itoa idx) " = " (rtos vy 2 2)))
      (setq zStr   (strcat "z_v" (itoa idx) " = " (rtos vz 2 2)))
    )
  )

  (list magStr xStr yStr zStr)
)

;; ============================================================
;; MAIN LABEL FUNCTION
;; ============================================================
(defun LA:LABEL-VECTOR (tip vx vy vz idx / ang perpUnit params h off
                               baseX baseY baseZ
                               magStr xStr yStr zStr
                               magPt xPt yPt zPt)

  ;; Build label strings
  (setq strs (LA:build-label-strings vx vy vz idx))
  (setq magStr (nth 0 strs))
  (setq xStr   (nth 1 strs))
  (setq yStr   (nth 2 strs))
  (setq zStr   (nth 3 strs))

   ;; ------------------------------------------------------------
  ;; SMART MODE DETECTION (Rev1c � corrected)
  ;; Decide whether caller is using:
  ;;   - classic vector labeling (real vector, tip?label direction)
  ;;   - quadrant-style labeling (neutralized or mismatched vector)
  ;; ------------------------------------------------------------

  (setq vecMag (sqrt (+ (* vx vx) (* vy vy) (* vz vz))))

  (setq tipToBase
    (list
      (- (car tip)  (car '(0 0 0)))   ;; tip is already the geometric tip
      (- (cadr tip) (cadr '(0 0 0)))
      (- (caddr tip) (caddr '(0 0 0)))
    )
  )

  (setq tipToBaseMag
    (sqrt (+ (* (car tipToBase) (car tipToBase))
             (* (cadr tipToBase) (cadr tipToBase))
             (* (caddr tipToBase) (caddr tipToBase)) )))

  (setq dot
    (+ (* vx (car tipToBase))
       (* vy (cadr tipToBase))
       (* vz (caddr tipToBase)) ))

  (setq dirMismatch
    (if (or (< vecMag 1e-6) (< tipToBaseMag 1e-6))
        T
        (< (/ dot (* vecMag tipToBaseMag)) 0.95)  ;; angle > ~18�
    )
  )

  (setq quadMode
    (or
      (< vecMag 1e-6)   ;; neutralized vector
      dirMismatch       ;; direction mismatch
    )
  )

  (if quadMode
    (progn
      ;; Quadrant mode: caller (e.g., VPAP) has already chosen base point,
      ;; quadrant, and any z-lift. Engine must not add its own offset.
      (setq ang 0.0)
      (setq perpUnit '(0 1 0))
      (setq params (LA:label-params vx vy vz))
      (setq h   (car params))
      (setq off 0.0)
    )
    (progn
      ;; Classic mode: original behavior
      ;; Angle of vector projection in XY
      
      ;; SMART clustered-case override for VPM Test 5 and similar cases
(setq xyMag (sqrt (+ (* vx vx) (* vy vy))))

(if (< xyMag 0.35)
    ;; Stable diagonal offset: +Y and +Z
    (setq perpUnit '(0 1 1))
    ;; Otherwise use classic perpendicular direction
    (progn
      (setq ang (angle '(0 0 0) (list vx vy 0)))
      (setq perpUnit (list (- (sin ang)) (cos ang) 0.0))
    )
)


      ;; Dynamic text height + offset
      (setq params (LA:label-params vx vy vz))
      (setq h   (car params))
      (setq off (cadr params))
    )
  )


  ;; Base label point = tip + perpendicular offset
  (setq baseX (+ (car tip)  (* off (car  perpUnit))))
  (setq baseY (+ (cadr tip) (* off (cadr perpUnit))))
  
  ;; Rev1c HOLD: small z-lift to separate overlapping blocks (A2: v1/v3, B3: v2/v5)
(setq zLift (if (member idx '(3 5)) (* 4.0 h) 0.0))
  
  ;; Rev1c SMART: lane-based z-lift with adaptive boost for clustered tips
(setq zLift
  (cond
    ((member idx '(4 6)) (* 8.0 h))  ;; highest lanes (VPDC v_perp, VPPS perp, VPM w)
    ((member idx '(3 5)) (* 4.0 h))  ;; middle lanes (VPDC v_parallel, VPPS proj, VPM proj_x(v))
    (T 0.0)                          ;; base lane (v, x, others)
  )
)

;; Adaptive boost: if tip is very close to origin in XY, increase separation
(setq xyMag (sqrt (+ (* (car tip) (car tip))
                     (* (cadr tip) (cadr tip)))))

;; If clustered near origin and this is lane 1 (|v1|), give it a big extra lift
(if (and (< xyMag 0.35) (= idx 1))
  (setq zLift (+ zLift (* 8.0 h)))   ;; push |v1| well above |v3|
)

(setq baseZ (+ (caddr tip) (* off (caddr perpUnit)) zLift))


  ;; Vertical spacing scaled with h
  (setq magPt (list baseX (+ baseY (* 2.25 h)) baseZ))
  (setq xPt   (list baseX (+ baseY (* 0.75 h)) baseZ))
  (setq yPt   (list baseX (- baseY (* 0.75 h)) baseZ))
  (setq zPt   (list baseX (- baseY (* 2.25 h)) baseZ))

  ;; Draw labels
  (setvar "CLAYER" "LA-VEC3D-LABEL")
  (command "._TEXT" "J" "ML" magPt h 0 magStr)
  (command "._TEXT" "J" "ML" xPt   h 0 xStr)
  (command "._TEXT" "J" "ML" yPt   h 0 yStr)
  (command "._TEXT" "J" "ML" zPt   h 0 zStr)

  ;; Avoid outline-only flicker
  (command "._REGEN")

  (princ)
)

;=====================================================================
;  END OF FILE: LA_LABEL_ENGINE_Rev1b.lsp
;=====================================================================
