;;; ============================================================
;;; cadcando Visual Linear Algebra System (VLAS)
;;; Module: VP-PROJ-MATRIX-VIS_Rev1 — SAFE‑REV
;;; Author: Chris A. LaFollette
;;;
;;; Licensed to the end user after purchase from the official
;;; cadcando VLAS website.
;;;
;;; This software is provided for individual educational,
;;; instructional, or personal use. Redistribution, resale,
;;; or modification without explicit written permission is
;;; strictly prohibited.
;;; ============================================================
;;; ------------------------------------------------------------
;;; DESCRIPTION:
;;;   Visualizes the action of the orthogonal projection matrix P
;;;   onto span{x} by:
;;;     - drawing x
;;;     - drawing a test vector v
;;;     - drawing proj_x(v) = P v
;;;     - drawing the perpendicular component v - proj_x(v)
;;;
;;;   Uses MEXP3D_LABEL_ENGINE_Rev2k for labeling.
;;; ------------------------------------------------------------
;;; ------------------------------------------------------------
;;; ARCHITECTURE (SAFE‑REV):
;;;   - No layers are created here; the Launcher owns all layers.
;;;   - Uses layers:
;;;       LA-VPM-AXIS
;;;       LA-VPM-VECTOR
;;;       LA-VPM-MATRIX   (reserved for future text use)
;;; ------------------------------------------------------------

(defun C:VPMV ( / x1 x2 x3
                  v1 v2 v3
                  denom
                  p11 p12 p13
                  p21 p22 p23
                  p31 p32 p33
                  pv1 pv2 pv3
                  w1 w2 w3
                  idx-x idx-v idx-p idx-w
                )

  (princ "\nLinear Algebra Tool: Visual Projection Matrix onto span{x}")
  (princ "\nVP-PROJ-MATRIX-VIS_Rev1 - Visualizing P v = proj_x(v)")

  ;; ------------------------------------------------------------
  ;; Input: x (nonzero)
  ;; ------------------------------------------------------------
  (princ "\nEnter direction vector x (nonzero):")
  (setq x1 (getreal "\n  x_x: "))
  (setq x2 (getreal "\n  x_y: "))
  (setq x3 (getreal "\n  x_z: "))

  (setq denom (+ (* x1 x1) (* x2 x2) (* x3 x3)))
  (if (<= denom 1e-12)
    (progn
      (princ "\nERROR: x must be nonzero. Projection matrix is undefined.")
      (princ)
      (exit)
    )
  )

  ;; ------------------------------------------------------------
  ;; Input: test vector v
  ;; ------------------------------------------------------------
  (princ "\nEnter test vector v (to be projected onto span{x}):")
  (setq v1 (getreal "\n  v_x: "))
  (setq v2 (getreal "\n  v_y: "))
  (setq v3 (getreal "\n  v_z: "))

  ;; ------------------------------------------------------------
  ;; Compute P = (x x^T) / (x^T x)
  ;; ------------------------------------------------------------
  (setq p11 (/ (* x1 x1) denom))
  (setq p12 (/ (* x1 x2) denom))
  (setq p13 (/ (* x1 x3) denom))

  (setq p21 (/ (* x2 x1) denom))
  (setq p22 (/ (* x2 x2) denom))
  (setq p23 (/ (* x2 x3) denom))

  (setq p31 (/ (* x3 x1) denom))
  (setq p32 (/ (* x3 x2) denom))
  (setq p33 (/ (* x3 x3) denom))

  ;; ------------------------------------------------------------
  ;; Compute proj_x(v) = P v and w = v - proj_x(v)
  ;; ------------------------------------------------------------
  (setq pv1 (+ (* p11 v1) (* p12 v2) (* p13 v3)))
  (setq pv2 (+ (* p21 v1) (* p22 v2) (* p23 v3)))
  (setq pv3 (+ (* p31 v1) (* p32 v2) (* p33 v3)))

  (setq w1 (- v1 pv1))
  (setq w2 (- v2 pv2))
  (setq w3 (- v3 pv3))

  ;; ------------------------------------------------------------
  ;; Lane indices for Label Engine
  ;; ------------------------------------------------------------
  (setq idx-x 1)  ;; x
  (setq idx-v 2)  ;; v
  (setq idx-p 3)  ;; proj_x(v)
  (setq idx-w 4)  ;; v - proj_x(v)

  ;; ------------------------------------------------------------
  ;; Draw axes (optional, simple XYZ frame)
  ;; ------------------------------------------------------------
  (setvar "CLAYER" "LA-VPM-AXIS")
  (command "._3DPOLY" "0,0,0" "1,0,0" "")
  (command "._3DPOLY" "0,0,0" "0,1,0" "")
  (command "._3DPOLY" "0,0,0" "0,0,1" "")

  ;; ------------------------------------------------------------
  ;; Draw x, v, proj_x(v), and w
  ;; ------------------------------------------------------------

  ;; x
  (setvar "CLAYER" "LA-VPM-VECTOR")
  (command "._3DPOLY"
           "0,0,0"
           (strcat (rtos x1 2 6) ","
                   (rtos x2 2 6) ","
                   (rtos x3 2 6))
           "")

  ;; v
  (command "._3DPOLY"
           "0,0,0"
           (strcat (rtos v1 2 6) ","
                   (rtos v2 2 6) ","
                   (rtos v3 2 6))
           "")

  ;; proj_x(v)
  (command "._3DPOLY"
           "0,0,0"
           (strcat (rtos pv1 2 6) ","
                   (rtos pv2 2 6) ","
                   (rtos pv3 2 6))
           "")

  ;; w = v - proj_x(v), drawn from proj_x(v) to v
  (command "._3DPOLY"
           (strcat (rtos pv1 2 6) ","
                   (rtos pv2 2 6) ","
                   (rtos pv3 2 6))
           (strcat (rtos v1 2 6) ","
                   (rtos v2 2 6) ","
                   (rtos v3 2 6))
           "")

  ;; ------------------------------------------------------------
  ;; Labels via Label Engine
  ;; ------------------------------------------------------------

  ;; x
  (LA:LABEL-VECTOR (list x1 x2 x3) x1 x2 x3 idx-x)

  ;; v
  (LA:LABEL-VECTOR (list v1 v2 v3) v1 v2 v3 idx-v)

  ;; proj_x(v)
  (LA:LABEL-VECTOR (list pv1 pv2 pv3) pv1 pv2 pv3 idx-p)

  ;; w = v - proj_x(v)
  (LA:LABEL-VECTOR (list w1 w2 w3) w1 w2 w3 idx-w)

  ;; ------------------------------------------------------------
  ;; Brief textual summary
  ;; ------------------------------------------------------------
  (princ "\n\nSummary:")
  (princ (strcat
           "\n  x          = ("
           (rtos x1 2 4) ", "
           (rtos x2 2 4) ", "
           (rtos x3 2 4) ")"))
  (princ (strcat
           "\n  v          = ("
           (rtos v1 2 4) ", "
           (rtos v2 2 4) ", "
           (rtos v3 2 4) ")"))
  (princ (strcat
           "\n  proj_x(v)  = ("
           (rtos pv1 2 4) ", "
           (rtos pv2 2 4) ", "
           (rtos pv3 2 4) ")"))
  (princ (strcat
           "\n  v - proj_x(v) = ("
           (rtos w1 2 4) ", "
           (rtos w2 2 4) ", "
           (rtos w3 2 4) ")"))

  ;
  
  (princ "\n\nGeometric picture: v is decomposed into a component along x and a perpendicular component.")
; Zoom
  (command "_.ZOOM" "E")
  
  (princ)
)

;=====================================================================
;  END OF FILE: VP-PROJ-MATRIX-VIS_Rev1.lsp
;=====================================================================
