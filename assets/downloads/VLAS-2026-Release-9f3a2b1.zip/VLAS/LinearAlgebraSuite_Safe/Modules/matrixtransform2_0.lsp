;;; ==========================================
;;; MATRIXTRANSFORM 2.0
;;; Visualize A*v for 2x2 or 3x3 matrices
;;; Features (all optional, toggled at runtime):
;;;  - v and A*v (core, always drawn)
;;;  - Columns of A (A*e1, A*e2, A*e3)
;;;  - Parallelogram / parallelepiped from columns
;;;  - Unit square/cube and its image under A
;;;  - Determinant and area/volume scaling
;;;  - Optional "animation" mode (step-by-step pauses)
;;; 
;;; Layers:
;;;  MT-ORIG         - original vector v
;;;  MT-TRANS        - transformed vector A*v
;;;  MT-COL1/2/3     - columns of A
;;;  MT-UNIT         - unit square/cube
;;;  MT-UNIT-TRANS   - transformed unit square/cube
;;;  MT-PARA         - parallelogram/parallelepiped
;;;  MT-LABEL        - all text labels
;;;  MT-DET          - determinant text
;;; ==========================================

(defun mt2-ensure-layer (name color / tbl)
  (setq tbl (tblsearch "LAYER" name))
  (if tbl
    name
    (progn
      (entmakex
        (list
          (cons 0 "LAYER")
          (cons 2 name)
          (cons 70 0)
          (cons 62 color)
        )
      )
      name
    )
  )
)

(defun mt2-make-line (p1 p2 layerName)
  (entmakex
    (list
      (cons 0 "LINE")
      (cons 8 layerName)
      (cons 10 p1)
      (cons 11 p2)
      (cons 62 256)
    )
  )
)



(defun mt2-make-3dface (p1 p2 p3 p4 layerName)
  (entmakex
    (list
      (cons 0 "3DFACE")
      (cons 8 layerName)
      (cons 62 256)   ; BYLAYER � color comes from launcher
      (cons 10 p1)
      (cons 11 p2)
      (cons 12 p3)
      (cons 13 p4)
      (cons 70 0)
    )
  )
)


(defun mt2-vadd (a b)
  (list (+ (car a) (car b))
        (+ (cadr a) (cadr b))
        (+ (caddr a) (caddr b))))

(defun mt2-vsub (a b)
  (list (- (car a) (car b))
        (- (cadr a) (cadr b))
        (- (caddr a) (caddr b))))

(defun mt2-vscale (s v)
  (list (* s (car v))
        (* s (cadr v))
        (* s (caddr v))))

(defun mt2-dot2 (r c)
  (+ (* (car r)   (car c))
     (* (cadr r)  (cadr c))))

(defun mt2-dot3 (r c)
  (+ (* (car r)   (car c))
     (* (cadr r)  (cadr c))
     (* (caddr r) (caddr c))))

(defun mt2-cross (a b)
  (list
    (- (* (cadr a) (caddr b)) (* (caddr a) (cadr b)))
    (- (* (caddr a) (car b)) (* (car a) (caddr b)))
    (- (* (car a) (cadr b)) (* (cadr a) (car b)))
  )
)

(defun mt2-mag (v)
  (sqrt (+ (* (car v) (car v))
           (* (cadr v) (cadr v))
           (* (caddr v) (caddr v)))))

(defun mt2-unit (v / m)
  (setq m (mt2-mag v))
  (if (> m 0.0)
    (mt2-vscale (/ 1.0 m) v)
    '(0 0 0)
  )
)

(defun mt2-pause-if (doPause msg)
  (if (= doPause "Yes")
    (progn
      (if msg (prompt msg))
      (getstring "\nPress ENTER to continue...")
    )
  )
)

;;; determinant for 2x2
(defun mt2-det2 (a11 a12 a21 a22)
  (- (* a11 a22) (* a12 a21)))

;;; determinant for 3x3
(defun mt2-det3 (a11 a12 a13 a21 a22 a23 a31 a32 a33)
  (+ (* a11 (- (* a22 a33) (* a23 a32)))
     (* (- a12) (- (* a21 a33) (* a23 a31)))
     (* a13 (- (* a21 a32) (* a22 a31)))))

;;; Draw unit square in 2D (z=0)
(defun mt2-draw-unit-square (origin layerName)
  (setq o origin)
  (setq ex (mt2-vadd o '(1 0 0)))
  (setq ey (mt2-vadd o '(0 1 0)))
  (setq exy (mt2-vadd o '(1 1 0)))
  (mt2-make-line o   ex  layerName)
  (mt2-make-line ex  exy layerName)
  (mt2-make-line exy ey layerName)
  (mt2-make-line ey  o  layerName)
)

;;; Draw transformed unit square from A*e1, A*e2
(defun mt2-draw-trans-square (origin Ae1 Ae2 layerName)
  (setq o origin)
  (setq p1 (mt2-vadd o Ae1))
  (setq p2 (mt2-vadd o (mt2-vadd Ae1 Ae2)))
  (setq p3 (mt2-vadd o Ae2))
  (mt2-make-line o   p1 layerName)
  (mt2-make-line p1  p2 layerName)
  (mt2-make-line p2  p3 layerName)
  (mt2-make-line p3  o  layerName)
)

;;; Draw unit cube in 3D
(defun mt2-draw-unit-cube (origin layerName / o ex ey ez exy exz eyz exyz)
  (setq o    origin)
  (setq ex   (mt2-vadd o '(1 0 0)))
  (setq ey   (mt2-vadd o '(0 1 0)))
  (setq ez   (mt2-vadd o '(0 0 1)))
  (setq exy  (mt2-vadd o '(1 1 0)))
  (setq exz  (mt2-vadd o '(1 0 1)))
  (setq eyz  (mt2-vadd o '(0 1 1)))
  (setq exyz (mt2-vadd o '(1 1 1)))

  ;; bottom square
  (mt2-make-line o   ex   layerName)
  (mt2-make-line ex  exy  layerName)
  (mt2-make-line exy ey   layerName)
  (mt2-make-line ey  o    layerName)
  ;; top square
  (mt2-make-line ez  exz  layerName)
  (mt2-make-line exz exyz layerName)
  (mt2-make-line exyz eyz layerName)
  (mt2-make-line eyz ez   layerName)
  ;; verticals
  (mt2-make-line o   ez   layerName)
  (mt2-make-line ex  exz  layerName)
  (mt2-make-line exy exyz layerName)
  (mt2-make-line ey  eyz  layerName)
)

;;; Draw transformed unit cube from Ae1, Ae2, Ae3
(defun mt2-draw-trans-cube (origin Ae1 Ae2 Ae3 layerName / o e1 e2 e3 e12 e13 e23 top)
  (setq o   origin)
  (setq e1  (mt2-vadd o Ae1))
  (setq e2  (mt2-vadd o Ae2))
  (setq e3  (mt2-vadd o Ae3))
  (setq e12 (mt2-vadd e1 Ae2))
  (setq e13 (mt2-vadd e1 Ae3))
  (setq e23 (mt2-vadd e2 Ae3))
  (setq top (mt2-vadd o (mt2-vadd Ae1 (mt2-vadd Ae2 Ae3))))

  ;; bottom
  (mt2-make-line o   e1  layerName)
  (mt2-make-line e1  e12 layerName)
  (mt2-make-line e12 e2  layerName)
  (mt2-make-line e2  o   layerName)
  ;; top
  (mt2-make-line e3  e13 layerName)
  (mt2-make-line e13 top layerName)
  (mt2-make-line top e23 layerName)
  (mt2-make-line e23 e3  layerName)
  ;; verticals
  (mt2-make-line o   e3  layerName)
  (mt2-make-line e1  e13 layerName)
  (mt2-make-line e12 top layerName)
  (mt2-make-line e2  e23 layerName)
)

;;; Draw parallelogram (2D) from Ae1, Ae2
(defun mt2-draw-parallelogram (origin Ae1 Ae2 layerName / o p1 p2 p3)
  (setq o  origin)
  (setq p1 (mt2-vadd o Ae1))
  (setq p3 (mt2-vadd o Ae2))
  (setq p2 (mt2-vadd p1 Ae2))
  (mt2-make-3dface o p1 p2 p3 layerName)
)

;;; Draw parallelepiped (3D) from Ae1, Ae2, Ae3
(defun mt2-draw-parallelepiped (origin Ae1 Ae2 Ae3 layerName / o e1 e2 e3 e12 e13 e23 top)
  (setq o   origin)
  (setq e1  (mt2-vadd o Ae1))
  (setq e2  (mt2-vadd o Ae2))
  (setq e3  (mt2-vadd o Ae3))
  (setq e12 (mt2-vadd e1 Ae2))
  (setq e13 (mt2-vadd e1 Ae3))
  (setq e23 (mt2-vadd e2 Ae3))
  (setq top (mt2-vadd o (mt2-vadd Ae1 (mt2-vadd Ae2 Ae3))))

  ;; 6 faces
  (mt2-make-3dface o   e1  e12 e2  layerName)
  (mt2-make-3dface o   e1  e13 e3  layerName)
  (mt2-make-3dface o   e2  e23 e3  layerName)
  (mt2-make-3dface top e12 e1  e13 layerName)
  (mt2-make-3dface top e12 e2  e23 layerName)
  (mt2-make-3dface top e13 e3  e23 layerName)
)

;;; ============================================================
;;; MT2-SAFE LABEL ENGINE (VLAS Standard)
;;; ============================================================

(defun mt2-make-text (pt h txt lay / pz)
  ;; Safe Z-offset for readability in 2D/3D
  (setq pz (list (car pt) (cadr pt) (+ (caddr pt) 0.02)))

  (entmakex
    (list
      (cons 0 "TEXT")
      (cons 8 lay)          ; BYLAYER color
      (cons 62 256)         ; 256 = BYLAYER
      (cons 10 pz)
      (cons 40 h)
      (cons 1 txt)
      (cons 7 (getvar "TEXTSTYLE"))
      (cons 50 0.0)
      (cons 51 0.0)
    )
  )
)

(defun mt2-label-vector (pt txt lay / vec dx dy off p mag)
  ;; Vector name label (v, A�v, A�e1, etc.)
  ;; Use perpendicular offset logic (same as components) for consistent placement
  
  ;; Extract vector from point (relative to origin at 0,0,0)
  (setq vec (list (car pt) (cadr pt) (caddr pt)))
  
  ;; Perpendicular offset in XY plane
  (setq dx (- (cadr vec)))
  (setq dy (car vec))
  (setq mag (sqrt (+ (* dx dx) (* dy dy))))

  ;; Normalize and scale offset (larger than components for separation)
  (if (> mag 0.01)
    (setq off (mapcar '(lambda (x) (* x (/ 0.55 mag))) (list dx dy 0)))
    (setq off '(0.55 0 0)) ; fallback for axis-aligned vectors
  )

  ;; Final label position
  (setq p (mapcar '+ pt off))

  ;; Draw label
  (mt2-make-text p 0.15 txt lay)
)

(defun mt2-label-components (vec basePt lay / p txt offset)
  ;; vec = (x y z)
  ;; basePt = anchor point at vector tip
  ;; lay = layer (color BYLAYER)
  ;; Place component label above (+Y) and left (-X) of vector label
  ;; Using same offset magnitude (0.55) as vector label, in 45-degree angle

  ;; Offset magnitude same as vector label (0.55), applied diagonally (-X, +Y)
  ;; 0.55 / sqrt(2) ? 0.389 per axis for 45-degree offset
  (setq offset (/ 0.55 (sqrt 2)))
  (setq p (list (- (car basePt) offset) (+ (cadr basePt) offset) (+ (caddr basePt) 0.0)))

  ;; Build comma-delimited string
  (setq txt
        (strcat "("
                (rtos (car vec)   2 3) ", "
                (rtos (cadr vec)  2 3)
                (if (= (length vec) 3)
                  (strcat ", " (rtos (caddr vec) 2 3))
                  "")
                ")"))

  ;; Draw label
  (mt2-make-text p 0.125 txt lay)
)


;;; ==========================================
;;; Main command
;;; ==========================================

(defun c:MATRIXTRANSFORM2_0
  ( / dim
       originChoice origin
       a11 a12 a21 a22
       a13 a23 a31 a32 a33
       v1 v2 v3
       v av
       e1 e2 e3
       Ae1 Ae2 Ae3
       endV endAV
       layV layAV layC1 layC2 layC3 layUnit layUnitT layPara layLabel layDet
       txtHeight
       optCols optPara optUnit optDet optAnim
       offset detA scaleTextPos)

  (prompt "\nMATRIXTRANSFORM 2.0: A*v + columns, unit shapes, determinant.")

  ;; Dimension
  (initget "2D 3D")
  (setq dim (getkword "\nMatrix dimension? [2D/3D] <2D>: "))
  (if (null dim) (setq dim "2D"))

  ;; Origin
  (initget "Yes No")
  (setq originChoice (getkword "\nSpecify custom origin? [Yes/No] <No>: "))
  (if (null originChoice) (setq originChoice "No"))

  (setq origin
    (if (= originChoice "Yes")
      (getpoint "\nPick origin point: ")
      '(0.0 0.0 0.0)
    )
  )

  ;; Text height
  (setq txtHeight (getreal "\nEnter label text height <0.4>: "))
  (if (null txtHeight) (setq txtHeight 0.4))

  ;; Options (all default Yes except animation)
  (initget "Yes No")
  (setq optCols (getkword "\nDraw columns of A? [Yes/No] <Yes>: "))
  (if (null optCols) (setq optCols "Yes"))

  (initget "Yes No")
  (setq optPara (getkword "\nDraw parallelogram/parallelepiped? [Yes/No] <Yes>: "))
  (if (null optPara) (setq optPara "Yes"))

  (initget "Yes No")
  (setq optUnit (getkword "\nDraw unit shape and its image? [Yes/No] <Yes>: "))
  (if (null optUnit) (setq optUnit "Yes"))

  (initget "Yes No")
  (setq optDet (getkword "\nShow determinant and scaling? [Yes/No] <Yes>: "))
  (if (null optDet) (setq optDet "Yes"))

  (initget "Yes No")
  (setq optAnim (getkword "\nAnimation mode (pause between steps)? [Yes/No] <No>: "))
  (if (null optAnim) (setq optAnim "No"))

  ;; SAFE?REV layer bindings � layers are created in the launcher
(setq layV      "LA-MT-ORIG")
(setq layAV     "LA-MT-TRANS")
(setq layC1     "LA-MT-COL")
(setq layC2     "LA-MT-COL")
(setq layC3     "LA-MT-COL")
(setq layUnit   "LA-MT-UNIT")
(setq layUnitT  "LA-MT-UNIT-TRANS")
(setq layPara   "LA-MT-PARA")
(setq layLabel  "LA-MT-LABEL")
(setq layDet    "LA-MT-DET")

  ;; Basis vectors (standard)
  (setq e1 '(1 0 0))
  (setq e2 '(0 1 0))
  (setq e3 '(0 0 1))

  ;; --- 2D case ---
  (if (= dim "2D")
    (progn
      (prompt "\nEnter 2x2 matrix A (row by row):")
      (setq a11 (getreal "\n A11: "))
      (setq a12 (getreal "  A12: "))
      (setq a21 (getreal "  A21: "))
      (setq a22 (getreal "  A22: "))

      (prompt "\nEnter vector v (2D):")
      (setq v1 (getreal "\n v1 (x): "))
      (setq v2 (getreal "  v2 (y): "))
      (setq v3 0.0)
      (setq v  (list v1 v2 v3))

      ;; A*v
      (setq av
        (list
          (mt2-dot2 (list a11 a12) (list v1 v2))
          (mt2-dot2 (list a21 a22) (list v1 v2))
          0.0
        )
      )

      ;; Columns of A as A*e1, A*e2
      (setq Ae1
        (list
          (mt2-dot2 (list a11 a12) (list 1 0))
          (mt2-dot2 (list a21 a22) (list 1 0))
          0.0
        )
      )
      (setq Ae2
        (list
          (mt2-dot2 (list a11 a12) (list 0 1))
          (mt2-dot2 (list a21 a22) (list 0 1))
          0.0
        )
      )
      (setq Ae3 '(0 0 0)) ; unused in 2D
    )
  )

  ;; --- 3D case ---
  (if (= dim "3D")
    (progn
      (prompt "\nEnter 3x3 matrix A (row by row):")
      (setq a11 (getreal "\n A11: "))
      (setq a12 (getreal "  A12: "))
      (setq a13 (getreal "  A13: "))
      (setq a21 (getreal "  A21: "))
      (setq a22 (getreal "  A22: "))
      (setq a23 (getreal "  A23: "))
      (setq a31 (getreal "  A31: "))
      (setq a32 (getreal "  A32: "))
      (setq a33 (getreal "  A33: "))

      (prompt "\nEnter vector v (3D):")
      (setq v1 (getreal "\n v1 (x): "))
      (setq v2 (getreal "  v2 (y): "))
      (setq v3 (getreal "  v3 (z): "))
      (setq v  (list v1 v2 v3))

      ;; A*v
      (setq av
        (list
          (mt2-dot3 (list a11 a12 a13) (list v1 v2 v3))
          (mt2-dot3 (list a21 a22 a23) (list v1 v2 v3))
          (mt2-dot3 (list a31 a32 a33) (list v1 v2 v3))
        )
      )

      ;; Columns of A as A*e1, A*e2, A*e3
      (setq Ae1
        (list
          (mt2-dot3 (list a11 a12 a13) (list 1 0 0))
          (mt2-dot3 (list a21 a22 a23) (list 1 0 0))
          (mt2-dot3 (list a31 a32 a33) (list 1 0 0))
        )
      )
      (setq Ae2
        (list
          (mt2-dot3 (list a11 a12 a13) (list 0 1 0))
          (mt2-dot3 (list a21 a22 a23) (list 0 1 0))
          (mt2-dot3 (list a31 a32 a33) (list 0 1 0))
        )
      )
      (setq Ae3
        (list
          (mt2-dot3 (list a11 a12 a13) (list 0 0 1))
          (mt2-dot3 (list a21 a22 a23) (list 0 0 1))
          (mt2-dot3 (list a31 a32 a33) (list 0 0 1))
        )
      )
    )
  )

  ;; Endpoints for v and A*v
(setq endV  (mt2-vadd origin v))
(setq endAV (mt2-vadd origin av))

;; --- Step 1: Draw v and A*v ---
(mt2-make-line origin endV  layV)
(mt2-make-line origin endAV layAV)

;; Vector labels (color = BYLAYER)
(mt2-label-vector endV  "v"   layV)
(mt2-label-vector endAV "A�v" layAV)

;; Component labels (stacked, offset, Z?lifted)
(mt2-label-components v  endV  layV)
(mt2-label-components av endAV layAV)

(mt2-pause-if optAnim "\n[v and A*v drawn]")

  
  ;; --- Step 2: Columns of A ---
(if (= optCols "Yes")
  (progn

    ;; A�e1
    (setq endAe1 (mt2-vadd origin Ae1))
    (mt2-make-line origin endAe1 layC1)
    (mt2-label-vector     endAe1 "A�e1" layC1)
    (mt2-label-components Ae1    endAe1 layC1)

    ;; A�e2
    (setq endAe2 (mt2-vadd origin Ae2))
    (mt2-make-line origin endAe2 layC2)
    (mt2-label-vector     endAe2 "A�e2" layC2)
    (mt2-label-components Ae2    endAe2 layC2)

    ;; A�e3 (3D only)
    (if (= dim "3D")
      (progn
        (setq endAe3 (mt2-vadd origin Ae3))
        (mt2-make-line origin endAe3 layC3)
        (mt2-label-vector     endAe3 "A�e3" layC3)
        (mt2-label-components Ae3    endAe3 layC3)
      )
    )

    (mt2-pause-if optAnim "\n[Columns of A drawn]")
  )
)
(setq shapeZoff (* txtHeight 0.75))

  ;; --- Step 3: Unit square/cube and its image ---
(if (= optUnit "Yes")
  (progn
    (if (= dim "2D")
      (progn
        (mt2-draw-unit-square origin layUnit)
        (mt2-draw-trans-square origin Ae1 Ae2 layUnitT)

        ;; Labels for unit square and its image
        (mt2-label-vector
  (mt2-vadd origin (list 0.2 0.2 shapeZoff))
  "Unit Sq"
  layUnit)

(mt2-label-vector
  (mt2-vadd origin (list 0.4 0.4 shapeZoff))
  "A(Unit Sq)"
  layUnitT)

      )
      (progn
        (mt2-draw-unit-cube origin layUnit)
        (mt2-draw-trans-cube origin Ae1 Ae2 Ae3 layUnitT)

        ;; Labels for unit cube and its image
        (mt2-label-vector
  (mt2-vadd origin (list 0.2 0.2 shapeZoff))
  "Unit Cube"
  layUnit)

(mt2-label-vector
  (mt2-vadd origin (list 0.4 0.4 shapeZoff))
  "A(Unit Cube)"
  layUnitT)

      )
    )
    (mt2-pause-if optAnim "\n[Unit shape and its image drawn]")
  )
)


  ;; --- Step 4: Parallelogram/parallelepiped from columns ---
(if (= optPara "Yes")
  (progn
    (if (= dim "2D")
      (progn
        (mt2-draw-parallelogram origin Ae1 Ae2 layPara)
        (mt2-label-vector (mt2-vadd origin '(0.3 0.3 0)) "Para(A)" layPara)
      )
      (progn
        (mt2-draw-parallelepiped origin Ae1 Ae2 Ae3 layPara)
        (mt2-label-vector (mt2-vadd origin '(0.3 0.3 0.3)) "Para(A)" layPara)
      )
    )
    (mt2-pause-if optAnim "\n[Parallelogram/parallelepiped drawn]")
  )
)


  ;; --- Step 5: Determinant and scaling ---
(if (= optDet "Yes")
  (progn
    ;; Compute determinant
    (if (= dim "2D")
      (setq detA (mt2-det2 a11 a12 a21 a22))
      (setq detA (mt2-det3 a11 a12 a13 a21 a22 a23 a31 a32 a33))
    )

    ;; Command-line message
    (if (= dim "2D")
      (prompt
        (strcat
          "\n det(A) = " (rtos detA 2 4)
          "  (area scaling = |det(A)| = " (rtos (abs detA) 2 4) ")"
        )
      )
      (prompt
        (strcat
          "\n det(A) = " (rtos detA 2 4)
          "  (volume scaling = |det(A)| = " (rtos (abs detA) 2 4) ")"
        )
      )
    )

    ;; Label near origin (yellow ACI 2)
    (setq scaleTextPos (mt2-vadd origin (list (* txtHeight 2.0) (* txtHeight 2.0) 0.0)))
    (mt2-label-vector
      scaleTextPos
      (if (= dim "2D")
        (strcat "det(A)=" (rtos detA 2 4) ", area=" (rtos (abs detA) 2 4))
        (strcat "det(A)=" (rtos detA 2 4) ", vol="  (rtos (abs detA) 2 4))
      )
      layDet
    )

    (mt2-pause-if optAnim "\n[Determinant and scaling displayed]")
  )
)

(command "_.zoom" "_all")
  (prompt "\nMATRIXTRANSFORM 2.0: Done.")
  (princ)
)
