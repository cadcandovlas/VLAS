;=====================================================================
;  FILE: VP-PROJ-SUBSPACE_Rev1.lsp
;  TOOL: VPPS - Projection onto a Subspace
;  SUITE: cadcando Visual Linear Algebra System (VLAS)
;=====================================================================
;  DESCRIPTION:
;    Projection of v onto span{u1,...,uk}, k = 1..3
;    Uses LA_LABEL_ENGINE_Rev1b/c for labeling.
;
;  ARCHITECTURE:
;    - Layers are created by the Launcher (SAFE-REV).
;    - This module only:
;        * collects input
;        * computes proj and perp
;        * draws geometry on existing layers
;        * calls Label Engine with lane indices
;=====================================================================

(defun C:VPPS ( / vx vy vz
                  k uList u1 u2 u3
                  a11 a12 a22
                  b1 b2
                  c1 c2
                  proj perp
                  i ui
                  idx-v idx-u1 idx-u2 idx-u3 idx-proj idx-perp
                  deg-k2 det
                )

  (princ "\nLinear Algebra Tool: Projection onto a Subspace")
  (princ "\nVP-PROJ-SUBSPACE_Rev1 - Projection of v onto span{u1,...,uk}")

  ;; ------------------------------------------------------------
  ;; Input: v
  ;; ------------------------------------------------------------
  (princ "\nEnter vector v:")
  (setq vx (getreal "\n  v_x: "))
  (setq vy (getreal "\n  v_y: "))
  (setq vz (getreal "\n  v_z: "))

  ;; ------------------------------------------------------------
  ;; Input: k
  ;; ------------------------------------------------------------
  (setq k (getint "\nEnter number of spanning vectors k (1�3): "))
  (if (or (< k 1) (> k 3))
    (progn
      (princ "\nERROR: k must be 1, 2, or 3.")
      (princ)
      (exit)
    )
  )

  ;; ------------------------------------------------------------
  ;; Input: basis vectors u1..uk
  ;; ------------------------------------------------------------
  (setq uList nil)

  (if (>= k 1)
    (progn
      (princ "\nEnter basis vector u1:")
      (setq u1 (list
                 (getreal "\n  u1_x: ")
                 (getreal "\n  u1_y: ")
                 (getreal "\n  u1_z: ")))
      (setq uList (append uList (list u1)))
    )
  )

  (if (>= k 2)
    (progn
      (princ "\nEnter basis vector u2:")
      (setq u2 (list
                 (getreal "\n  u2_x: ")
                 (getreal "\n  u2_y: ")
                 (getreal "\n  u2_z: ")))
      (setq uList (append uList (list u2)))
    )
  )

  (if (= k 3)
    (progn
      (princ "\nEnter basis vector u3:")
      (setq u3 (list
                 (getreal "\n  u3_x: ")
                 (getreal "\n  u3_y: ")
                 (getreal "\n  u3_z: ")))
      (setq uList (append uList (list u3)))
    )
  )

  ;; ------------------------------------------------------------
  ;; Lane assignment (fixed, SAFE-REV)
  ;; ------------------------------------------------------------
  (setq idx-v    1)  ;; v
  (setq idx-u1   2)  ;; u1
  (setq idx-u2   3)  ;; u2
  (setq idx-u3   4)  ;; u3
  (setq idx-proj 5)  ;; proj(v)
  (setq idx-perp 6)  ;; perp = v - proj

  ;; ------------------------------------------------------------
  ;; Compute projection of v onto span{u1..uk}, k = 1..3
  ;; ------------------------------------------------------------
  (setq deg-k2 nil)

  (cond

    ;; k = 1: proj = ((u1�v)/(u1�u1)) u1
    ((= k 1)
      (setq u1 (nth 0 uList))
      (setq a11 (+ (* (car u1) (car u1))
                   (* (cadr u1) (cadr u1))
                   (* (caddr u1) (caddr u1))))
      (setq b1  (+ (* (car u1) vx)
                   (* (cadr u1) vy)
                   (* (caddr u1) vz)))
      (setq c1  (/ b1 a11))
      (setq proj (list (* c1 (car u1))
                       (* c1 (cadr u1))
                       (* c1 (caddr u1))))
      (setq perp (list
                   (- vx (car proj))
                   (- vy (cadr proj))
                   (- vz (caddr proj))))
    )

    ;; k = 2: solve 2x2 system G c = b explicitly
    ((= k 2)
      (setq u1 (nth 0 uList))
      (setq u2 (nth 1 uList))

      ;; Gram matrix entries
      (setq a11 (+ (* (car u1) (car u1))
                   (* (cadr u1) (cadr u1))
                   (* (caddr u1) (caddr u1))))
      (setq a12 (+ (* (car u1) (car u2))
                   (* (cadr u1) (cadr u2))
                   (* (caddr u1) (caddr u2))))
      (setq a22 (+ (* (car u2) (car u2))
                   (* (cadr u2) (cadr u2))
                   (* (caddr u2) (caddr u2))))

      ;; RHS
      (setq b1  (+ (* (car u1) vx)
                   (* (cadr u1) vy)
                   (* (caddr u1) vz)))
      (setq b2  (+ (* (car u2) vx)
                   (* (cadr u2) vy)
                   (* (caddr u2) vz)))

      ;; det
      (setq det (- (* a11 a22) (* a12 a12)))

      ;; If det = 0, u1 and u2 are dependent ? regularize u2 slightly
      (if (= det 0)
        (progn
          (princ "\nWarning: u1 and u2 are linearly dependent. Adjusting u2 slightly.")
          (setq deg-k2 T)
          ;; bump u2
          (setq u2 (list
                     (+ (car u2) 0.0001)
                     (+ (cadr u2) 0.0002)
                     (+ (caddr u2) 0.0003)))
          ;; recompute Gram entries
          (setq a12 (+ (* (car u1) (car u2))
                       (* (cadr u1) (cadr u2))
                       (* (caddr u1) (caddr u2))))
          (setq a22 (+ (* (car u2) (car u2))
                       (* (cadr u2) (cadr u2))
                       (* (caddr u2) (caddr u2))))
          (setq det (- (* a11 a22) (* a12 a12)))
        )
      )

      ;; coefficients
      (setq c1  (/ (- (* b1 a22) (* b2 a12)) det))
      (setq c2  (/ (- (* b2 a11) (* b1 a12)) det))

      ;; proj = c1 u1 + c2 u2
      (setq proj (list
                   (+ (* c1 (car u1)) (* c2 (car u2)))
                   (+ (* c1 (cadr u1)) ( * c2 (cadr u2)))
                   (+ (* c1 (caddr u1)) (* c2 (caddr u2)))))

      ;; perp = v - proj
      (setq perp (list
                   (- vx (car proj))
                   (- vy (cadr proj))
                   (- vz (caddr proj))))
    )

    ;; k = 3: span is all of R^3 ? proj = v, perp = 0
    ((= k 3)
      (setq proj (list vx vy vz))
      (setq perp (list 0.0 0.0 0.0))
    )
  )

  ;; ------------------------------------------------------------
  ;; Draw geometry (Launcher-created layers)
  ;; ------------------------------------------------------------

  ;; v
  (setvar "CLAYER" "LA-VPPS-V")
  (command "._3DPOLY" "0,0,0"
           (strcat (rtos vx 2 6) ","
                   (rtos vy 2 6) ","
                   (rtos vz 2 6))
           "")

  ;; each u_i
  (setvar "CLAYER" "LA-VPPS-U")
  (setq i 0)
  (while (< i k)
    (setq ui (nth i uList))
    (command "._3DPOLY" "0,0,0"
             (strcat (rtos (car ui) 2 6) ","
                     (rtos (cadr ui) 2 6) ","
                     (rtos (caddr ui) 2 6))
             "")
    (setq i (1+ i))
  )

  ;; proj
  (setvar "CLAYER" "LA-VPPS-PROJ")
  (command "._3DPOLY" "0,0,0"
           (strcat (rtos (car proj) 2 6) ","
                   (rtos (cadr proj) 2 6) ","
                   (rtos (caddr proj) 2 6))
           "")

  ;; perp
  (setvar "CLAYER" "LA-VPPS-PERP")
  (command "._3DPOLY"
           (strcat (rtos (car proj) 2 6) ","
                   (rtos (cadr proj) 2 6) ","
                   (rtos (caddr proj) 2 6))
           (strcat (rtos (+ (car proj) (car perp)) 2 6) ","
                   (rtos (+ (cadr proj) (cadr perp)) 2 6) ","
                   (rtos (+ (caddr proj) (caddr perp)) 2 6))
           "")

  ;; ------------------------------------------------------------
  ;; Labels (using Label Engine)
  ;; ------------------------------------------------------------

  ;; v
  (LA:LABEL-VECTOR (list vx vy vz) vx vy vz idx-v)

  ;; u1
  (if (>= k 1)
    (LA:LABEL-VECTOR u1 (car u1) (cadr u1) (caddr u1) idx-u1)
  )

  ;; u2
  (if (>= k 2)
    (LA:LABEL-VECTOR u2 (car u2) (cadr u2) (caddr u2) idx-u2)
  )

  ;; u3
  (if (= k 3)
    (LA:LABEL-VECTOR u3 (car u3) (cadr u3) (caddr u3) idx-u3)
  )

  ;; proj
  (LA:LABEL-VECTOR proj (car proj) (cadr proj) (caddr proj) idx-proj)

  ;; perp
  (LA:LABEL-VECTOR perp (car perp) (cadr perp) (caddr perp) idx-perp)
;; Zoom
  (command "_.ZOOM" "E")
  (princ)
)

;=====================================================================
;  END OF FILE: VP-PROJ-SUBSPACE_Rev1.lsp
;=====================================================================
