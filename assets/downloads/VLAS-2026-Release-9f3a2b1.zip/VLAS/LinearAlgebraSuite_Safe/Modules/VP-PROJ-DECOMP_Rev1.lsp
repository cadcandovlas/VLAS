;=====================================================================
;  VP-PROJ-DECOMP_Rev1  �  Projection Decomposition (v = v_parallel + v_perp)
;  LinearAlgebraSuite_Safe
;
;  File:        VP-PROJ-DECOMP_Rev1.lsp
;  Revision:    Rev1 (2026)
;  Status:      SAFE?REV / Production?Grade
;
;  Author:      Chris A. LaFollette
;  Copyright:   � 2026 Chris A. LaFollette
;
;  Description:
;     Computes and visualizes the decomposition of a 3D vector v into its
;     parallel and perpendicular components relative to a direction vector u:
;         v = v_parallel + v_perp
;     Draws v, u, v_parallel, v_perp, and ASCII?safe labels. All geometry
;     and behavior correspond to the stable Rev1 SAFE?REV implementation.
;
;  SAFE?SUITE Notes:
;     - ASCII?only labels (v, u, v_parallel, v_perp)
;     - No Smart Label Engine; labels are diagram?anchored and local
;     - No persistent UCS or view modifications
;     - No layer creation here; required layers must be provided by the
;       SAFE?REV launcher/template
;     - Early exit if u is zero or near?zero magnitude
;
;  Required Layers (provided by launcher/template):
;     VPDC-V           (Continuous)        � original vector v
;     VPDC-U           (Continuous)        � direction vector u
;     VPDC-PAR         (Continuous)        � v_parallel
;     VPDC-PERP        (DASHED)            � v_perp
;     VPDC-LABEL       (Continuous)        � text labels
;     VPDC-CONST       (Continuous)        � construction lines
;
;  Baseline Linetype Settings:
;     LTSCALE    = 5
;     CELTSCALE  = 1
;     PSLTSCALE  = 1
;
;  Legal:
;     Redistribution, modification, or inclusion in other software is
;     prohibited without written permission from the author. This file is
;     part of the LinearAlgebraSuite_Safe SAFE?REV collection and is
;     included in the 2026 copyright deposit.
;
;=====================================================================


(defun VPDC:announce ( / )
  (prompt
    "\n=== VPDC � Projection Decomposition (v = v? + v?) ==="
  )
  (princ)
)

;; ------------------------------------------------------------
;; Utility: get a 3D vector from user
;; ------------------------------------------------------------
(defun VPDC:get-vector (label / x y z)
  (prompt (strcat "\nEnter components of " label ":"))
  (setq x (getreal (strcat "\n  " label "_x: "))
        y (getreal (strcat "\n  " label "_y: "))
        z (getreal (strcat "\n  " label "_z: "))
  )
  (list x y z)
)

;; ------------------------------------------------------------
;; Utility: dot product and scalar helpers
;; ------------------------------------------------------------
(defun VPDC:dot (a b)
  (+ (* (car a)   (car b))
     (* (cadr a)  (cadr b))
     (* (caddr a) (caddr b)))
)

(defun VPDC:scale (s v)
  (list (* s (car v))
        (* s (cadr v))
        (* s (caddr v)))
)

(defun VPDC:add (a b)
  (list (+ (car a)   (car b))
        (+ (cadr a)  (cadr b))
        (+ (caddr a) (caddr b)))
)

(defun VPDC:sub (a b)
  (list (- (car a)   (car b))
        (- (cadr a)  (cadr b))
        (- (caddr a) (caddr b)))
)

(defun VPDC:mag (v)
  (sqrt (+ (* (car v)   (car v))
           (* (cadr v)  (cadr v))
           (* (caddr v) (caddr v))))
)

;; ------------------------------------------------------------
;; Draw a vector from origin on a given layer
;; ------------------------------------------------------------
(defun VPDC:draw-vector (v layer / )
  (setvar "CLAYER" layer)
  (command "._LINE" '(0 0 0) v "")
)

;; ------------------------------------------------------------
;; Label wrapper � uses LA_LABEL_ENGINE_Rev1b (smart)
;; idx mapping:
;;   1 = v
;;   2 = u
;;   3 = v_parallel
;;   4 = v_perp
;; ------------------------------------------------------------
;; ------------------------------------------------------------
;; Label wrapper � FIXED for Quadrant?1 vertical alignment
;; ------------------------------------------------------------
(defun VPDC:label-vector (tip v idx / params h zLift newTip)

  ;; Get text height (h) from engine
  (setq params (LA:label-params (car v) (cadr v) (caddr v)))
  (setq h (car params))

  ;; FIX: Always lift v_perp (idx 4) by one lane
  ;; This solves the Q1 |v1| / |v4| stacking and x/y/z overlap.
  ;; FIX: Quadrant?1 vertical separation for VPDC indices
(setq zLift
  (cond
    ((= idx 4) (* 8.0 h))   ;; v_perp gets highest lift
    ((= idx 3) (* 4.0 h))   ;; v_parallel gets middle lift
    (T 0.0)                 ;; v (idx 1) stays at base
  )
)

  ;; Apply lift to the tip
  (setq newTip
        (list (car tip)
              (cadr tip)
              (+ (caddr tip) zLift)))

  ;; Pass through to Label Engine
  (LA:LABEL-VECTOR newTip (car v) (cadr v) (caddr v) idx)
)

;; ------------------------------------------------------------
;; Labeling mode ONLY � style handled by Label Engine
;; ------------------------------------------------------------
(defun VPDC:get-label-settings ( / mode)
  (setq mode (getint "\nLabeling mode [1 = label v only / 5 = label everything] <5>: "))
  (if (not mode) (setq mode 5))
  (setq *LA_label_mode* mode)
)


;; ------------------------------------------------------------
;; Main command
;; ------------------------------------------------------------
(defun C:VPDC ( / v u uMag projScale vpar vperp origin)

  (VPDC:announce)

  ;; Get input vectors
  (setq v (VPDC:get-vector "v"))
  (setq u (VPDC:get-vector "u"))

  ;; Guard against zero u
  (setq uMag (VPDC:mag u))
  (if (< uMag 1e-6)
    (progn
      (prompt "\n[VPDC ERROR] Direction vector u is too small. Aborting.")
      (princ)
      (exit)
    )
  )

  ;; Compute projection and perpendicular components
  (setq projScale (/ (VPDC:dot v u) (VPDC:dot u u)))
  (setq vpar  (VPDC:scale projScale u))
  (setq vperp (VPDC:sub v vpar))

  ;; Label settings (mode + style)
  (VPDC:get-label-settings)

  (setq origin '(0 0 0))

  ;; Draw geometry
  ;; v
  (VPDC:draw-vector v "LA-VPDC-V")
  ;; u
  (VPDC:draw-vector u "LA-VPDC-U")
  ;; v_parallel
  (VPDC:draw-vector vpar "LA-VPDC-PAR")
  ;; v_perp (from tip of v_parallel to tip of v)
  (setvar "CLAYER" "LA-VPDC-PERP")
  (command "._LINE" vpar v "")

  ;; Construction line from origin to v_parallel (for visual clarity)
  (setvar "CLAYER" "LA-VPDC-CONST")
  (command "._LINE" origin vpar "")

  

  (cond
    ((= *LA_label_mode* 1)
     ;; Label v only
     (VPDC:label-vector v v 1)
    )
    ((= *LA_label_mode* 5)
     ;; Label everything: v, u, v_parallel, v_perp
     (VPDC:label-vector v     v     1)
     (VPDC:label-vector u     u     2)
     (VPDC:label-vector vpar  vpar  3)
     (VPDC:label-vector v     vperp 4) ;; tip at v, vector = v_perp
    )
    (T
     ;; Fallback: label everything
     (VPDC:label-vector v     v     1)
     (VPDC:label-vector u     u     2)
     (VPDC:label-vector vpar  vpar  3)
     (VPDC:label-vector v     vperp 4)
    )
  )

  (prompt "\nDecomposition drawn: v = v? + v?.")
  
  (command "_.ZOOM" "A")
  
  (princ)
)

;=====================================================================
;  END OF FILE: VP-PROJ-DECOMP_Rev1.lsp
;=====================================================================
