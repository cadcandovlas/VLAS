;=====================================================================
;  cadcando Visual Linear Algebra System (VLAS)
;  VEC3D � Rev4b (SAFE?REV)
;  Author: Chris A. LaFollette
;  Licensed for individual educational use after purchase.
;  Redistribution or modification without permission prohibited.
;
;  Revision 4b Notes:
;    � Rev4a projection lab retained
;    � LA-VEC3D-PERP now uses dashed linetype
;    � LTSCALE / CELTSCALE set for visible dashes
;    � Dynamic text height and lane offset based on |v|
;    � REGEN after labels to avoid outline-only flicker
;=====================================================================

(if (not *VLAS-env-ready*)
  (progn
    (princ "\nVLAS environment not initialized. Run TRANSFORM_LAUNCHER_MINI_MENU_FULL first.")
    (exit)
  )
)

;; ------------------------------------------------------------
;;  Utility: Ensure layer exists (launcher provides VLAS-make-layer)
;; ------------------------------------------------------------
(defun VEC3D-ensure-layer (name color / )
  (if (not (tblsearch "LAYER" name))
    (VLAS-make-layer name color nil)
  )
)

;; ------------------------------------------------------------
;;  Utility: Ensure dashed linetype for perpendicular layer
;; ------------------------------------------------------------
(defun VEC3D-ensure-perp-linetype ( / ltRec )
  ;; Load HIDDEN if not present
  (if (not (tblsearch "LTYPE" "HIDDEN"))
    (command "._-LINETYPE" "_LOAD" "HIDDEN" "acad.lin" "")
  )
  ;; Assign HIDDEN to LA-VEC3D-PERP if layer exists
  (if (setq ltRec (tblsearch "LAYER" "LA-VEC3D-PERP"))
    (command "._-LAYER" "_L" "HIDDEN" "LA-VEC3D-PERP" "")
  )
)

;; ------------------------------------------------------------
;;  Axis drawing (suite standard)
;; ------------------------------------------------------------
(defun VEC3D-draw-axes ( / )
  (setvar "CLAYER" "LA-VEC3D-AXIS")

  ;; X axis
  (command "._LINE" '(0 0 0) '(1 0 0) "")
  (setvar "CLAYER" "LA-VEC3D-AXIS-LABEL")
  (command "._TEXT" "J" "ML" '(1.1 0 0) 0.2 0 "X")

  ;; Y axis
  (setvar "CLAYER" "LA-VEC3D-AXIS")
  (command "._LINE" '(0 0 0) '(0 1 0) "")
  (setvar "CLAYER" "LA-VEC3D-AXIS-LABEL")
  (command "._TEXT" "J" "ML" '(0 1.1 0) 0.2 0 "Y")

  ;; Z axis
  (setvar "CLAYER" "LA-VEC3D-AXIS")
  (command "._LINE" '(0 0 0) '(0 0 1) "")
  (setvar "CLAYER" "LA-VEC3D-AXIS-LABEL")
  (command "._TEXT" "J" "ML" '(0 0 1.1) 0.2 0 "Z")
)

;; ------------------------------------------------------------
;;  Dynamic label parameters based on |v|
;; ------------------------------------------------------------
(defun VEC3D-label-params (vx vy vz / mag baseH baseOff h off)
  (setq mag (sqrt (+ (* vx vx) (* vy vy) (* vz vz))))
  (setq baseH   0.20)   ;; base text height
  (setq baseOff 0.30)   ;; base lane offset

  ;; scale factor: gentle, clamped
  (cond
    ((< mag 0.5) (setq h (* baseH 0.5)
                       off (* baseOff 0.5)))
    ((> mag 20.0) (setq h (* baseH 2.0)
                        off (* baseOff 2.0)))
    (T (setq h baseH
             off baseOff))
  )
  (list h off)
)

;; ------------------------------------------------------------
;;  4-line stacked label: |v|, x, y, z (perpendicular lane, dynamic)
;; ------------------------------------------------------------
(defun VEC3D-stack-label (tip vx vy vz / ang perpUnit params h off
                               baseX baseY baseZ
                               mag magStr xStr yStr zStr
                               magPt xPt yPt zPt)

  ;; Angle of vector projection in XY
  (setq ang (angle '(0 0 0) (list vx vy 0)))

  ;; Perpendicular unit vector in XY
  (setq perpUnit (list (- (sin ang)) (cos ang) 0.0))

  ;; Dynamic text height and offset
  (setq params (VEC3D-label-params vx vy vz))
  (setq h   (car params))
  (setq off (cadr params))

  ;; Base label point = tip + perpendicular offset
  (setq baseX (+ (car tip)  (* off (car  perpUnit))))
  (setq baseY (+ (cadr tip) (* off (cadr perpUnit))))
  (setq baseZ (+ (caddr tip) (* off (caddr perpUnit))))

  ;; Values
  (setq mag    (sqrt (+ (* vx vx) (* vy vy) (* vz vz))))
  (setq magStr (strcat "|v| = " (rtos mag 2 3)))
  (setq xStr   (strcat "x = " (rtos vx 2 2)))
  (setq yStr   (strcat "y = " (rtos vy 2 2)))
  (setq zStr   (strcat "z = " (rtos vz 2 2)))

  ;; Vertical spacing scaled with h
  (setq magPt (list baseX (+ baseY (* 2.25 h)) baseZ))  ; top
  (setq xPt   (list baseX (+ baseY (* 0.75 h)) baseZ))
  (setq yPt   (list baseX (- baseY (* 0.75 h)) baseZ))
  (setq zPt   (list baseX (- baseY (* 2.25 h)) baseZ))  ; bottom

  (setvar "CLAYER" "LA-VEC3D-LABEL")

  (command "._TEXT" "J" "ML" magPt h 0 magStr)
  (command "._TEXT" "J" "ML" xPt   h 0 xStr)
  (command "._TEXT" "J" "ML" yPt   h 0 yStr)
  (command "._TEXT" "J" "ML" zPt   h 0 zStr)

  ;; Avoid outline-only flicker
  (command "._REGEN")
)

;; ------------------------------------------------------------
;;  Small vector utilities for projection mode
;; ------------------------------------------------------------
(defun VEC3D-dot (a b)
  (+ (* (car a) (car b))
     (* (cadr a) (cadr b))
     (* (caddr a) (caddr b)))
)

(defun VEC3D-scale (s v)
  (list (* s (car v)) (* s (cadr v)) (* s (caddr v)))
)

(defun VEC3D-sub (a b)
  (list (- (car a) (car b))
        (- (cadr a) (cadr b))
        (- (caddr a) (caddr b)))
)

;; ------------------------------------------------------------
;;  Base VEC3D command (Rev3c behavior + dynamic labels)
;; ------------------------------------------------------------
(defun c:VEC3D ( / vx vy vz vec base tip )

  ;; Layers
  (VEC3D-ensure-layer "LA-VEC3D-VECTOR"      5)  ; blue
  (VEC3D-ensure-layer "LA-VEC3D-TAIL"        5)  ; blue
  (VEC3D-ensure-layer "LA-VEC3D-LABEL"       7)  ; white
  (VEC3D-ensure-layer "LA-VEC3D-AXIS"        2)  ; yellow
  (VEC3D-ensure-layer "LA-VEC3D-AXIS-LABEL"  7)  ; white
  (VEC3D-ensure-layer "LA-VEC3D-PROJ"        3)  ; cyan
  (VEC3D-ensure-layer "LA-VEC3D-PERP"        8)  ; gray

  ;; Ensure dashed linetype for perpendicular layer
  (VEC3D-ensure-perp-linetype)

  ;; Draw axes once per session
  (if (not VEC3D-axes-drawn)
    (progn
      (VEC3D-draw-axes)
      (setq VEC3D-axes-drawn T)
    )
  )

  ;; Get vector
  (setq vx (getreal "\nEnter X component: "))
  (setq vy (getreal "\nEnter Y component: "))
  (setq vz (getreal "\nEnter Z component: "))
  (setq vec (list vx vy vz))
  (setq base '(0 0 0))
  (setq tip vec)

  ;; Tail dot
  (setvar "CLAYER" "LA-VEC3D-TAIL")
  (command "._CIRCLE" base 0.05)

  ;; Vector line
  (setvar "CLAYER" "LA-VEC3D-VECTOR")
  (command "._LINE" base tip "")

  ;; Label v? using the label engine
(LA:LABEL-VECTOR tip vx vy vz 1)

(princ "\nVector drawn. Enter VEC3D again to draw another.")
(princ)
)

;; ------------------------------------------------------------
;;  Projection lab: VEC3DPROJ (Rev4b)
;; ------------------------------------------------------------
(defun c:VEC3DPROJ ( / vx vy vz v mode ux uy uz u proj perp
                        base tip projTip )

  ;; Layers
  (VEC3D-ensure-layer "LA-VEC3D-VECTOR"      5)  ; blue
  (VEC3D-ensure-layer "LA-VEC3D-TAIL"        5)
  (VEC3D-ensure-layer "LA-VEC3D-LABEL"       7)
  (VEC3D-ensure-layer "LA-VEC3D-AXIS"        2)
  (VEC3D-ensure-layer "LA-VEC3D-AXIS-LABEL"  7)
  (VEC3D-ensure-layer "LA-VEC3D-PROJ"        3)  ; cyan
  (VEC3D-ensure-layer "LA-VEC3D-PERP"        8)  ; gray

  ;; Ensure dashed linetype for perpendicular layer
  (VEC3D-ensure-perp-linetype)

  ;; Linetype scale for visible dashes
  (setvar "LTSCALE" 1.0)
  (setvar "CELTSCALE" 1.0)

  ;; Axes once
  (if (not VEC3D-axes-drawn)
    (progn
      (VEC3D-draw-axes)
      (setq VEC3D-axes-drawn T)
    )
  )

  ;; Vector v
  (setq vx (getreal "\nEnter X component of v: "))
  (setq vy (getreal "\nEnter Y component of v: "))
  (setq vz (getreal "\nEnter Z component of v: "))
  (setq v (list vx vy vz))
  (setq base '(0 0 0))
  (setq tip v)

  ;; Draw v?
(setvar "CLAYER" "LA-VEC3D-TAIL")
(command "._CIRCLE" base 0.05)
(setvar "CLAYER" "LA-VEC3D-VECTOR")
(command "._LINE" base tip "")

;; Label v? using the label engine
(LA:LABEL-VECTOR tip vx vy vz 1)

;; Mode

  (setq mode
    (getint
      "\nProjection mode [1=onto vector u / 2=onto XY / 3=onto YZ / 4=onto ZX]: "
    )
  )

  (cond
    ;; 1) Projection onto vector u
    ((= mode 1)
      (setq ux (getreal "\nEnter X component of u: "))
      (setq uy (getreal "\nEnter Y component of u: "))
      (setq uz (getreal "\nEnter Z component of u: "))
      (setq u (list ux uy uz))

      (if (equal (VEC3D-dot u u) 0.0 1e-12)
        (progn
          (princ "\nVector u has zero length. Cannot project.")
        )
        (progn
          (setq proj (VEC3D-scale
                       (/ (VEC3D-dot v u) (VEC3D-dot u u))
                       u))
          (setq perp (VEC3D-sub v proj))

          (setq projTip proj)

          ;; Draw projection vector
          (setvar "CLAYER" "LA-VEC3D-PROJ")
          (command "._LINE" base projTip "")

          ;; Dashed perpendicular from v to proj(v)
          (setvar "CLAYER" "LA-VEC3D-PERP")
          (command "._LINE" tip projTip "")

         
          ;; Label proj(v) as v?
(LA:LABEL-VECTOR projTip
                 (car proj) (cadr proj) (caddr proj)
                 2)

(princ "\nProjection of v onto u drawn.")

        )
      )
    )

    ;; 2) Projection onto XY plane
    ((= mode 2)
      (setq proj (list vx vy 0.0))
      (setq perp (list 0.0 0.0 vz))
      (setq projTip proj)

      (setvar "CLAYER" "LA-VEC3D-PROJ")
      (command "._LINE" base projTip "")

      (setvar "CLAYER" "LA-VEC3D-PERP")
      (command "._LINE" tip projTip "")

      ;; Label proj(v) as v?
(LA:LABEL-VECTOR projTip
                 (car proj) (cadr proj) (caddr proj)
                 2)

(princ "\nProjection of v onto XY plane drawn.")

    )

    ;; 3) Projection onto YZ plane
    ((= mode 3)
      (setq proj (list 0.0 vy vz))
      (setq perp (list vx 0.0 0.0))
      (setq projTip proj)

      (setvar "CLAYER" "LA-VEC3D-PROJ")
      (command "._LINE" base projTip "")

      (setvar "CLAYER" "LA-VEC3D-PERP")
      (command "._LINE" tip projTip "")

      ;; Label proj(v) as v?
(LA:LABEL-VECTOR projTip
                 (car proj) (cadr proj) (caddr proj)
                 2)

      (princ "\nProjection of v onto YZ plane drawn.")
    )

    ;; 4) Projection onto ZX plane
    ((= mode 4)
      (setq proj (list vx 0.0 vz))
      (setq perp (list 0.0 vy 0.0))
      (setq projTip proj)

      (setvar "CLAYER" "LA-VEC3D-PROJ")
      (command "._LINE" base projTip "")

      (setvar "CLAYER" "LA-VEC3D-PERP")
      (command "._LINE" tip projTip "")

      ;; Label proj(v) as v?
(LA:LABEL-VECTOR projTip
                 (car proj) (cadr proj) (caddr proj)
                 2)

(princ "\nProjection of v onto ZX plane drawn.")

    )

    (T
      (princ "\nUnknown mode. No projection drawn.")
    )
  )

  (princ)
)

;=====================================================================
;  END OF FILE: VEC3D_Rev4b.lsp
;  Part of the cadcando Visual Linear Algebra System (VLAS).
;  SAFE?REV compliant.
;=====================================================================
