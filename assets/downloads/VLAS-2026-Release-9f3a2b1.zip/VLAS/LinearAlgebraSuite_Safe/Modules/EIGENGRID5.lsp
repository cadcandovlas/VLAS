;=====================================================================
;  EIGENGRID5_Rev1  �  Eigenbasis Grid Visualization (Safe Suite)
;  Visual Linear Algebra Suite (VLAS)
;
;  Description:
;     Draws the eigenbasis grid for a real 2x2 matrix A when A has
;     two real eigenvalues and a real eigenbasis.  The grid is drawn
;     along eigenvector directions and scaled by eigenvalues.
;     Automatically rejects matrices with complex eigenvalues.
;
;  Status: PRODUCTION RELEASE
;  Revision: Rev1 (April 2026)
;
;  Author: Chris A. LaFollette
;  Suite Architecture and Safe?Suite Framework by: C.A. LaFollette
;
;  Notes:
;     - No UCS or VIEWTWIST modifications persist after execution.
;     - All labels are WCS?anchored and upright.
;     - Complex eigenvalues trigger Safe?Suite early exit.
;     - Fully compatible with acad3D.dwt and all visual styles.
;
;  Copyright (c) 2026
;  All rights reserved.  Redistribution or modification of this file
;  is prohibited without written permission from the author.
;=====================================================================


(defun C:EIGENGRID5 ( / oldLTS oldCELTS oldPSLTS oldLayer )

  ;; Save user settings
  (setq oldLTS   (getvar "LTSCALE"))
  (setq oldCELTS (getvar "CELTSCALE"))
  (setq oldPSLTS (getvar "PSLTSCALE"))
  (setq oldLayer (getvar "CLAYER"))

  ;; Apply Safe Suite baseline
  (setvar "LTSCALE"   5)
  (setvar "CELTSCALE" 1)
  (setvar "PSLTSCALE" 1)
  (command "REGEN")

  ;; Required layers check
  (if (and
        (tblsearch "LAYER" "EG-GRID")
        (tblsearch "LAYER" "EG-IMAGE")
        (tblsearch "LAYER" "EG-LABEL")
      )
    (EIGENGRID5-MAIN)
    (prompt
      "\nSAFE ERROR: Required layers EG-GRID, EG-IMAGE, EG-LABEL not found. Run the launcher/template first."
    )
  )

  ;; Restore user settings
  (setvar "LTSCALE"   oldLTS)
  (setvar "CELTSCALE" oldCELTS)
  (setvar "PSLTSCALE" oldPSLTS)
  (setvar "CLAYER"    oldLayer)
  (command "REGEN")

  (princ)
)

(defun C:EG () (C:EIGENGRID5))

;---------------------------------------------------------------
; Main driver
;---------------------------------------------------------------

(defun EIGENGRID5-MAIN ( / origin spacing extent
                           a11 a12 a21 a22
                           tr det disc sqrtDisc lam1 lam2
                           v1 v2 gridLines tGridLines *EG5-DEGENERATE* )

  (prompt "\nEIGENGRID5_Rev1a � Eigenbasis Grid Visualization (Safe Suite)")

  ;; Origin
  (setq origin (getpoint "\nPick origin <UCS origin>: "))
  (if (null origin)
    (setq origin (trans '(0 0 0) 1 0))
  )

  ;; Spacing
  (setq spacing (getreal "\nGrid spacing <1.0>: "))
  (if (or (null spacing) (<= spacing 0.0))
    (setq spacing 1.0)
  )

  ;; Extent
  (setq extent (getint "\nGrid extent <10>: "))
  (if (or (null extent) (<= extent 0))
    (setq extent 10)
  )

  ;; Matrix input
  (prompt "\nEnter matrix A = [[a11 a12] [a21 a22]]")
  (setq a11 (getreal "\nEnter a11: "))
  (setq a12 (getreal "\nEnter a12: "))
  (setq a21 (getreal "\nEnter a21: "))
  (setq a22 (getreal "\nEnter a22: "))

  ;; Eigenvalues
  (setq tr  (+ a11 a22))
  (setq det (- (* a11 a22) (* a12 a21)))
  (setq disc (- (* tr tr) (* 4.0 det)))

  (if (< disc 0.0)
    (progn
      (prompt
        "\nSAFE NOTICE: Matrix has complex eigenvalues � no real eigenbasis grid is drawn."
      )
      (exit)
    )
  )

  (setq sqrtDisc (sqrt disc))
  (setq lam1 (/ (+ tr sqrtDisc) 2.0))
  (setq lam2 (/ (- tr sqrtDisc) 2.0))

  ;; Eigenvectors
  (setq v1 (EIGENGRID5-EIGENVEC a11 a12 a21 a22 lam1))
  (setq v2 (EIGENGRID5-EIGENVEC a11 a12 a21 a22 lam2))

  ;; Build eigenbasis grid
  (setq gridLines (EIGENGRID5-BUILD-GRID origin spacing extent v1 v2))

  ;; Transform grid (with degeneracy detection)
  (setq *EG5-DEGENERATE* nil)
  (setq tGridLines
        (EIGENGRID5-TRANSFORM-GRID origin gridLines lam1 lam2 v1 v2
                                   '*EG5-DEGENERATE*))

  ;; Draw original grid
  (EIGENGRID5-DRAW-GRID gridLines "EG-GRID")

  ;; Draw transformed grid only if eigenbasis is usable
  (if *EG5-DEGENERATE*
    (prompt
      "\nSAFE NOTICE: Matrix does not produce a usable real eigenbasis grid (degenerate eigenvectors). Transformed grid not drawn."
    )
    (EIGENGRID5-DRAW-GRID tGridLines "EG-IMAGE")
  )

  ;; Labels (diagram-anchored, ASCII-only)
  (EIGENGRID5-LABEL origin lam1 lam2 extent)

  ;; Optional: axis arrows
  (EIGENGRID5-AXES origin v1 v2 extent)

  ;; Optional: spacing labels
  (EIGENGRID5-SPACING-LABELS origin v1 v2 spacing extent)

  (princ)
)

;---------------------------------------------------------------
; ZERO test
;---------------------------------------------------------------

(defun EIGENGRID5-ZERO (x)
  (< (abs x) 1e-8)
)

;---------------------------------------------------------------
; Normalize vector
;---------------------------------------------------------------

(defun EIGENGRID5-NORM2D (x y / n)
  (setq n (sqrt (+ (* x x) (* y y))))
  (if (EIGENGRID5-ZERO n)
    (list 1.0 0.0)
    (list (/ x n) (/ y n))
  )
)

;---------------------------------------------------------------
; Eigenvector solver
;---------------------------------------------------------------

(defun EIGENGRID5-EIGENVEC (a11 a12 a21 a22 lam / m11 m12 m21 m22 vx vy)

  (setq m11 (- a11 lam))
  (setq m22 (- a22 lam))
  (setq m12 a12)
  (setq m21 a21)

  (cond
    ((and (EIGENGRID5-ZERO m12) (EIGENGRID5-ZERO m21))
     (if (EIGENGRID5-ZERO m11)
       (setq vx 1.0 vy 0.0)
       (setq vx 0.0 vy 1.0)
     )
    )
    ((not (EIGENGRID5-ZERO m12))
     (setq vx 1.0 vy (/ (- m11) m12))
    )
    ((not (EIGENGRID5-ZERO m21))
     (setq vx 1.0 vy (/ (- m21) m22))
    )
    (T (setq vx 1.0 vy 0.0))
  )

  (EIGENGRID5-NORM2D vx vy)
)

;---------------------------------------------------------------
; Build eigenbasis grid
;---------------------------------------------------------------

(defun EIGENGRID5-BUILD-GRID (origin spacing extent v1 v2 / gridLines i j)

  (setq gridLines '())

  (defun EG5-ADDLINE (p1 p2)
    (setq gridLines (cons (list p1 p2) gridLines))
  )

  ;; Lines parallel to v1
  (setq j (- extent))
  (while (<= j extent)
    (setq p1 (EIGENGRID5-POINT origin (- extent) (* j spacing) v1 v2))
    (setq p2 (EIGENGRID5-POINT origin extent (* j spacing) v1 v2))
    (EG5-ADDLINE p1 p2)
    (setq j (1+ j))
  )

  ;; Lines parallel to v2
  (setq i (- extent))
  (while (<= i extent)
    (setq p1 (EIGENGRID5-POINT origin (* i spacing) (- extent) v1 v2))
    (setq p2 (EIGENGRID5-POINT origin (* i spacing) extent v1 v2))
    (EG5-ADDLINE p1 p2)
    (setq i (1+ i))
  )

  gridLines
)

;---------------------------------------------------------------
; Point builder
;---------------------------------------------------------------

(defun EIGENGRID5-POINT (origin alpha beta v1 v2)
  (list
    (+ (car origin)  (* alpha (car v1))  (* beta (car v2)))
    (+ (cadr origin) (* alpha (cadr v1)) (* beta (cadr v2)))
    (caddr origin)
  )
)

;---------------------------------------------------------------
; Transform grid
;---------------------------------------------------------------

(defun EIGENGRID5-TRANSFORM-GRID
       (origin gridLines lam1 lam2 v1 v2 flagSym / result)

  (setq result '())

  (defun EG5-XFORM (p / dx dy v1x v1y v2x v2y denom i j)

    (setq dx (- (car p)  (car origin)))
    (setq dy (- (cadr p) (cadr origin)))

    (setq v1x (car v1)  v1y (cadr v1))
    (setq v2x (car v2)  v2y (cadr v2))

    (setq denom (- (* v1x v2y) (* v2x v1y)))

    (if (EIGENGRID5-ZERO denom)
      (progn
        (set flagSym T)
        origin
      )
      (progn
        (setq i (/ (- (* dx v2y) (* dy v2x)) denom))
        (setq j (/ (- (* dy v1x) (* dx v1y)) denom))
        (EIGENGRID5-POINT origin (* i lam1) (* j lam2) v1 v2)
      )
    )
  )

  (foreach line gridLines
    (setq p1 (car line))
    (setq p2 (cadr line))
    (setq q1 (EG5-XFORM p1))
    (setq q2 (EG5-XFORM p2))
    (setq result (cons (list q1 q2) result))
  )

  result
)

;---------------------------------------------------------------
; Draw grid
;---------------------------------------------------------------

(defun EIGENGRID5-DRAW-GRID (gridLines layer)
  (setvar "CLAYER" layer)
  (foreach line gridLines
    (command "LINE" (car line) (cadr line) "")
  )
)

;---------------------------------------------------------------
; Labels (dynamic scaling, forced WCS orientation)
;---------------------------------------------------------------

;---------------------------------------------------------------
; Labels (dynamic scaling, WCS?anchored, upright)
;---------------------------------------------------------------

;---------------------------------------------------------------
; Labels (dynamic scaling, WCS-anchored, upright)
;---------------------------------------------------------------

(defun EIGENGRID5-LABEL (origin lam1 lam2 extent / h dy p)

  ;; Dynamic label height
  (setq h (* extent 0.05))
  (if (< h 0.15) (setq h 0.15))
  (setq dy (* 1.5 h))

  (setvar "CLAYER" "EG-LABEL")

  ;; Base point is the WCS origin you picked for the grid
  ;; We just offset from that in WCS directions (X right, Y up).

  ;; Title
  (setq p (list (+ (car origin) h)
                (+ (cadr origin) h)
                (caddr origin)))
  (command "TEXT" "J" "BL" p h 0 "Eigenbasis Grid")

  ;; Transformed Grid label
  (setq p (list (car p)
                (+ (cadr p) dy)
                (caddr p)))
  (command "TEXT" "J" "BL" p h 0 "Transformed Grid")

  ;; lambda1
  (setq p (list (car p)
                (+ (cadr p) dy)
                (caddr p)))
  (command "TEXT" "J" "BL" p h 0
           (strcat "lambda1 = " (rtos lam1 2 4)))

  ;; lambda2
  (setq p (list (car p)
                (+ (cadr p) dy)
                (caddr p)))
  (command "TEXT" "J" "BL" p h 0
           (strcat "lambda2 = " (rtos lam2 2 4)))
)



    
;;---------------------------------------------------------------
;; Optional: Axis arrows
;---------------------------------------------------------------

(defun EIGENGRID5-AXES (origin v1 v2 extent / p1 p2)

  (setvar "CLAYER" "EG-LABEL")

  ;; Arrow for v1
  (setq p1 origin)
  (setq p2 (list
             (+ (car origin) (* extent (car v1)))
             (+ (cadr origin) (* extent (cadr v1)))
             (caddr origin)))
  (command "LINE" p1 p2 "")

  ;; Arrow for v2
  (setq p2 (list
             (+ (car origin) (* extent (car v2)))
             (+ (cadr origin) (* extent (cadr v2)))
             (caddr origin)))
  (command "LINE" p1 p2 "")
)

;---------------------------------------------------------------
; Optional: Spacing labels
;---------------------------------------------------------------

(defun EIGENGRID5-SPACING-LABELS (origin v1 v2 spacing extent / i p h)

  ;; Dynamic label height
  (setq h (* extent 0.04))
  (if (< h 0.12) (setq h 0.12))

  (setvar "CLAYER" "EG-LABEL")

  ;; Labels along v1 direction
  (setq i 1)
  (while (<= i extent)
    (setq p (EIGENGRID5-POINT origin (* i spacing) 0 v1 v2))
    (command "TEXT" p h 0.0 (itoa i))
    (setq i (1+ i))
  )

  ;; Labels along v2 direction
  (setq i 1)
  (while (<= i extent)
    (setq p (EIGENGRID5-POINT origin 0 (* i spacing) v1 v2))
    (command "TEXT" p h 0.0 (itoa i))
    (setq i (1+ i))
  )
)

;=====================================================================
;  End of EIGENGRID5_Rev1  �  Eigenbasis Grid Visualization
;  Visual Linear Algebra Suite (VLAS)
;=====================================================================


(princ "\nEIGENGRID5_Rev1a loaded. Commands: EIGENGRID5 or EG")
(princ)
