;;; ============================================================
;;; VP-PROJ-LINE_Rev2.lsp
;;; Vector Projection onto a Line (Rev2 � Normalized u)
;;; Command: VPPL
;;; ============================================================

(defun C:VPPL ( / vx vy vz ux uy uz v u
                   magu unorm dot scalar proj perp)

  (prompt "\nVP-PROJ-LINE_Rev2 - Projection of v onto line u")

  ;; ----------------------------
  ;; Load Label Engine
  ;; ----------------------------
  (load "LA_LABEL_ENGINE_Rev1b" nil)

  ;; ----------------------------
  ;; Input vector v
  ;; ----------------------------
  (prompt "\nEnter vector v:")
  (setq vx (getreal "\n  v_x: "))
  (setq vy (getreal "\n  v_y: "))
  (setq vz (getreal "\n  v_z: "))
  (setq v (list vx vy vz))

  ;; ----------------------------
  ;; Input direction vector u
  ;; ----------------------------
  (prompt "\nEnter direction vector u (defines the line):")
  (setq ux (getreal "\n  u_x: "))
  (setq uy (getreal "\n  u_y: "))
  (setq uz (getreal "\n  u_z: "))
  (setq u (list ux uy uz))

  ;; ----------------------------
  ;; Normalize u (Rev2 enhancement)
  ;; ----------------------------
  (setq magu (sqrt (+ (* ux ux) (* uy uy) (* uz uz))))

  (if (<= magu 1e-9)
    (progn
      (prompt "\nERROR: Direction vector u has zero length.")
      (exit)
    )
  )

  (setq unorm (list (/ ux magu) (/ uy magu) (/ uz magu)))

  ;; ----------------------------
  ;; Projection math (same as Rev1, but using normalized u)
  ;; ----------------------------
  (setq dot (+ (* vx (car unorm))
               (* vy (cadr unorm))
               (* vz (caddr unorm))))

  (setq scalar dot)

  (setq proj (list (* scalar (car unorm))
                   (* scalar (cadr unorm))
                   (* scalar (caddr unorm))))

  (setq perp (list (- vx (car proj))
                   (- vy (cadr proj))
                   (- vz (caddr proj))))

  ;; ============================================================
  ;; GEOMETRY BLOCK (unchanged from Rev1)
  ;; ============================================================

  ;; Draw vector v
  (entmakex
    (list '(0 . "LINE")
          (cons 10 '(0 0 0))
          (cons 11 v)
          '(62 . 3))) ;; green

  ;; Draw direction vector u (normalized)
  (entmakex
    (list '(0 . "LINE")
          (cons 10 '(0 0 0))
          (cons 11 unorm)
          '(62 . 5))) ;; blue

  ;; Draw projection vector
  (entmakex
    (list '(0 . "LINE")
          (cons 10 '(0 0 0))
          (cons 11 proj)
          '(62 . 1))) ;; red

  ;; Draw perpendicular component
  (entmakex
    (list '(0 . "LINE")
          (cons 10 proj)
          (cons 11 v)
          '(62 . 2))) ;; yellow

  ;; ============================================================
;; LABEL ENGINE CALLS (matching LA:LABEL-VECTOR signature)
;; ============================================================

;; Label v
(LA:LABEL-VECTOR v vx vy vz 1)

;; Label u-hat (normalized u)
(LA:LABEL-VECTOR unorm (car unorm) (cadr unorm) (caddr unorm) 2)

;; Label projection
(LA:LABEL-VECTOR proj (car proj) (cadr proj) (caddr proj) 3)

;; Label perpendicular component
(LA:LABEL-VECTOR perp (car perp) (cadr perp) (caddr perp) 4)

  ;; Zoom
  (command "_.ZOOM" "E")

  (princ)
)
