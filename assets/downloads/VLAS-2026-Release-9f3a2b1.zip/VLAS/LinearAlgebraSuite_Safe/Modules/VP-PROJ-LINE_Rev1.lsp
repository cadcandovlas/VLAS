;=====================================================================
;  VP-PROJ-LINE_Rev1  �  Projection of v onto a Line (Safe Suite)
;  LinearAlgebraSuite_Safe
;
;  File:        VP-PROJ-LINE_Rev1.lsp
;  Revision:    Rev1 (2026)
;  Status:      SAFE?REV / Production?Grade
;  Timestamp:   03/19/2026   1:52 PM
;
;  Author:      Chris A. LaFollette
;  Copyright:   � 2026 Chris A. LaFollette
;
;  Description:
;     Computes and visualizes the projection of a 3D vector v onto a line
;     defined by a direction vector u. Draws v, u, the projection of v
;     onto u, and the perpendicular component. All labels are ASCII?safe
;     and diagram?anchored. Rev1 uses normalized u for stable geometry.
;
;  SAFE?SUITE Notes:
;     - ASCII?only labels (v, u, proj_u(v), perp)
;     - No Smart Label Engine; labels are diagram?anchored and local
;     - No persistent UCS or view modifications
;     - No layer creation here; required layers must be provided by the
;       SAFE?REV launcher/template
;     - Early exit if u has zero or near?zero magnitude
;
;  Required Layers (provided by launcher/template):
;     VPL-VEC        (Continuous)        � original vector v
;     VPL-U          (Continuous)        � direction vector u
;     VPL-PROJ       (Continuous)        � projection of v onto u
;     VPL-PERP       (DASHED)            � perpendicular component
;     VPL-LABEL      (Continuous)        � text labels
;
;  Baseline Linetype Settings:
;     LTSCALE    = 5
;     CELTSCALE  = 1
;     PSLTSCALE  = 1
;
;  Legal:
;     Redistribution, modification, or inclusion in other software is
;     prohibited without written permission from the author. This file is
;     part of the LinearAlgebraSuite_Safe SAFE?REV collection and is
;     included in the 2026 copyright deposit.
;
;=====================================================================

(defun C:VPPL ( / vx vy vz ux uy uz v u
                   magu unorm dot scalar proj perp)

  (prompt "\nVP-PROJ-LINE_Rev2 - Projection of v onto line u")

  ;; ----------------------------
  ;; Load Label Engine
  ;; ----------------------------
  (load "LA_LABEL_ENGINE_Rev1b" nil)

  ;; ----------------------------
  ;; Input vector v
  ;; ----------------------------
  (prompt "\nEnter vector v:")
  (setq vx (getreal "\n  v_x: "))
  (setq vy (getreal "\n  v_y: "))
  (setq vz (getreal "\n  v_z: "))
  (setq v (list vx vy vz))

  ;; ----------------------------
  ;; Input direction vector u
  ;; ----------------------------
  (prompt "\nEnter direction vector u (defines the line):")
  (setq ux (getreal "\n  u_x: "))
  (setq uy (getreal "\n  u_y: "))
  (setq uz (getreal "\n  u_z: "))
  (setq u (list ux uy uz))

  ;; ----------------------------
  ;; Normalize u (Rev2 enhancement)
  ;; ----------------------------
  (setq magu (sqrt (+ (* ux ux) (* uy uy) (* uz uz))))

  (if (<= magu 1e-9)
    (progn
      (prompt "\nERROR: Direction vector u has zero length.")
      (exit)
    )
  )

  (setq unorm (list (/ ux magu) (/ uy magu) (/ uz magu)))

  ;; ----------------------------
  ;; Projection math (same as Rev1, but using normalized u)
  ;; ----------------------------
  (setq dot (+ (* vx (car unorm))
               (* vy (cadr unorm))
               (* vz (caddr unorm))))

  (setq scalar dot)

  (setq proj (list (* scalar (car unorm))
                   (* scalar (cadr unorm))
                   (* scalar (caddr unorm))))

  (setq perp (list (- vx (car proj))
                   (- vy (cadr proj))
                   (- vz (caddr proj))))

  ;; ============================================================
  ;; GEOMETRY BLOCK (unchanged from Rev1)
  ;; ============================================================

  ;; Draw vector v
  (entmakex
    (list '(0 . "LINE")
          (cons 10 '(0 0 0))
          (cons 11 v)
          '(62 . 3))) ;; green

  ;; Draw direction vector u (normalized)
  (entmakex
    (list '(0 . "LINE")
          (cons 10 '(0 0 0))
          (cons 11 unorm)
          '(62 . 5))) ;; blue

  ;; Draw projection vector
  (entmakex
    (list '(0 . "LINE")
          (cons 10 '(0 0 0))
          (cons 11 proj)
          '(62 . 1))) ;; red

  ;; Draw perpendicular component
  (entmakex
    (list '(0 . "LINE")
          (cons 10 proj)
          (cons 11 v)
          '(62 . 2))) ;; yellow

  ;; ============================================================
;; LABEL ENGINE CALLS (matching LA:LABEL-VECTOR signature)
;; ============================================================

;; Label v
(LA:LABEL-VECTOR v vx vy vz 1)

;; Label u-hat (normalized u)
(LA:LABEL-VECTOR unorm (car unorm) (cadr unorm) (caddr unorm) 2)

;; Label projection
(LA:LABEL-VECTOR proj (car proj) (cadr proj) (caddr proj) 3)

;; Label perpendicular component
(LA:LABEL-VECTOR perp (car perp) (cadr perp) (caddr perp) 4)

  ;; Zoom
  (command "_.ZOOM" "E")

  (princ)
)
