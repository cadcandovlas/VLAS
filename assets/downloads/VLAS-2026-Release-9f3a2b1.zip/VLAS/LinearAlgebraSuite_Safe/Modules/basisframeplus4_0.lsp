;=====================================================================
;  cadcando Visual Linear Algebra System (VLAS)
;  BASISFRAMEPLUS4_0 � SAFE-REV + Smart Label Engine + Color-Matched Labels
;  Author: Chris A. LaFollette
;  Licensed for individual educational use after purchase.
;  Redistribution or modification without permission prohibited.
;=====================================================================

(if (not *VLAS-env-ready*)
  (progn
    (princ "\nVLAS environment not initialized. Run TRANSFORM_LAUNCHER_MINI_MENU_FULL first.")
    (exit)
  )
)

;;; ================================================================
;;;  BASISFRAMEPLUS4_0 � SAFE-REV
;;;  Core: clean vectors + labels
;;;  Options:
;;;    - Arrowheads
;;;    - Origin marker (circle/cross)
;;;    - Smart label offset (split-difference)
;;;    - Magnitudes
;;;    - Orthogonality / orthonormality checks
;;;    - Normal vector (e1 � e2)
;;;    - Coordinate planes (3DFACE)
;;;    - Parallelepiped (3DFACE + LINE edges)
;;;    - World axes + axis labels
;;; ================================================================

;;; ---------- Helpers: geometry ----------

(defun BASISFRAMEPLUS4_0-make-line (p1 p2 layerName)
  (entmakex
    (list (cons 0 "LINE")
          (cons 8 layerName)
          (cons 10 p1)
          (cons 11 p2)
          (cons 62 256)))
)

(defun BASISFRAMEPLUS4_0-make-text (p h text layerName / styleName)
  (setq styleName (getvar "TEXTSTYLE"))
  (entmakex
    (list (cons 0 "TEXT")
          (cons 8 layerName)
          (cons 10 p)
          (cons 40 h)
          (cons 1 text)
          (cons 7 styleName)))
)

(defun BASISFRAMEPLUS4_0-make-circle (center radius layerName)
  (entmakex
    (list (cons 0 "CIRCLE")
          (cons 8 layerName)
          (cons 10 center)
          (cons 40 radius)))
)

(defun BASISFRAMEPLUS4_0-make-cross (center size layerName / cx cy cz h)
  (setq cx (car center)
        cy (cadr center)
        cz (caddr center)
        h  (/ size 2.0))
  (BASISFRAMEPLUS4_0-make-line (list (- cx h) cy cz)
                   (list (+ cx h) cy cz)
                   layerName)
  (BASISFRAMEPLUS4_0-make-line (list cx (- cy h) cz)
                   (list cx (+ cy h) cz)
                   layerName)
)

(defun BASISFRAMEPLUS4_0-vadd (a b)
  (list (+ (car a) (car b))
        (+ (cadr a) (cadr b))
        (+ (caddr a) (caddr b))))

(defun BASISFRAMEPLUS4_0-vscale (s v)
  (list (* s (car v))
        (* s (cadr v))
        (* s (caddr v))))

(defun BASISFRAMEPLUS4_0-dot (a b)
  (+ (* (car a) (car b))
     (* (cadr a) (cadr b))
     (* (caddr a) (caddr b))))

(defun BASISFRAMEPLUS4_0-mag (v)
  (sqrt (BASISFRAMEPLUS4_0-dot v v)))

(defun BASISFRAMEPLUS4_0-cross (a b)
  (list
    (- (* (cadr a) (caddr b)) (* (caddr a) (cadr b)))
    (- (* (caddr a) (car b)) (* (car a) (caddr b)))
    (- (* (car a) (cadr b)) (* (cadr a) (car b)))))

(defun BASISFRAMEPLUS4_0-unit (v / m)
  (setq m (BASISFRAMEPLUS4_0-mag v))
  (if (> m 0.0) (BASISFRAMEPLUS4_0-vscale (/ 1.0 m) v) '(0 0 0))
)

;;; ---------- Smart label engine (split-difference) ----------

(defun BASISFRAMEPLUS4_0-smart-label-offset (v txtHeight / u ux uy uz z xy
                                   zLift xyDir xyLen xyUnit xyShift)
  (setq u  (BASISFRAMEPLUS4_0-unit v)
        ux (car u)
        uy (cadr u)
        uz (caddr u)
        z  (abs uz)
        xy (- 1.0 z))

  (setq zLift (list 0.0 0.0 (* txtHeight 0.6)))

  (setq xyDir (list (- uy) ux 0.0))
  (setq xyLen (BASISFRAMEPLUS4_0-mag xyDir))
  (if (> xyLen 1e-6)
    (setq xyUnit (BASISFRAMEPLUS4_0-vscale (/ 1.0 xyLen) xyDir))
    (setq xyUnit '(1 0 0))
  )
  (setq xyShift (BASISFRAMEPLUS4_0-vscale (* txtHeight 0.6) xyUnit))

  (BASISFRAMEPLUS4_0-vadd
    (BASISFRAMEPLUS4_0-vscale z zLift)
    (BASISFRAMEPLUS4_0-vscale xy xyShift))
)

(defun BASISFRAMEPLUS4_0-smart-label-point (origin tip v txtHeight useOffset?)
  (if (= useOffset? "Yes")
    (BASISFRAMEPLUS4_0-vadd tip (BASISFRAMEPLUS4_0-smart-label-offset v txtHeight))
    tip)
)

;;; ---------- 3DFACE helpers (draw last) ----------

(defun BASISFRAMEPLUS4_0-make-3dface (p1 p2 p3 p4 layerName)
  (entmakex
    (list
      (cons 0 "3DFACE")
      (cons 8 layerName)
      (cons 62 256)     ;; BYENTITY color (required for 3DFACE transparency)
      (cons 440 153)   ;; 60% transparency (153 = 255 * (1 - 0.40))
      (cons 10 p1)
      (cons 11 p2)
      (cons 12 p3)
      (cons 13 p4)
      (cons 70 0)
    )
  )
)


(defun BASISFRAMEPLUS4_0-draw-plane-3dface (origin v1 v2 layerName)
  (BASISFRAMEPLUS4_0-make-3dface
    origin
    (BASISFRAMEPLUS4_0-vadd origin v1)
    (BASISFRAMEPLUS4_0-vadd origin (BASISFRAMEPLUS4_0-vadd v1 v2))
    (BASISFRAMEPLUS4_0-vadd origin v2)
    layerName)
)

(defun BASISFRAMEPLUS4_0-draw-parallelepiped-edges (origin e1 e2 e3 layerName / o e1p e2p e3p e12 e13 e23 top)
  (setq o   origin
        e1p (BASISFRAMEPLUS4_0-vadd o e1)
        e2p (BASISFRAMEPLUS4_0-vadd o e2)
        e3p (BASISFRAMEPLUS4_0-vadd o e3)
        e12 (BASISFRAMEPLUS4_0-vadd e1p e2)
        e13 (BASISFRAMEPLUS4_0-vadd e1p e3)
        e23 (BASISFRAMEPLUS4_0-vadd e2p e3)
        top (BASISFRAMEPLUS4_0-vadd o (BASISFRAMEPLUS4_0-vadd e1 (BASISFRAMEPLUS4_0-vadd e2 e3))))

  ;; edges as LINE on LA-BF-BOX
  (foreach pair
    (list (list o e1p) (list o e2p) (list o e3p)
          (list e1p e12) (list e2p e12)
          (list e1p e13) (list e3p e13)
          (list e2p e23) (list e3p e23)
          (list e12 top) (list e13 top) (list e23 top))
    (BASISFRAMEPLUS4_0-make-line (car pair) (cadr pair) layerName))
)

(defun BASISFRAMEPLUS4_0-draw-parallelepiped-faces (origin e1 e2 e3 layerName / o e1p e2p e3p e12 e13 e23 top)
  (setq o   origin
        e1p (BASISFRAMEPLUS4_0-vadd o e1)
        e2p (BASISFRAMEPLUS4_0-vadd o e2)
        e3p (BASISFRAMEPLUS4_0-vadd o e3)
        e12 (BASISFRAMEPLUS4_0-vadd e1p e2)
        e13 (BASISFRAMEPLUS4_0-vadd e1p e3)
        e23 (BASISFRAMEPLUS4_0-vadd e2p e3)
        top (BASISFRAMEPLUS4_0-vadd o (BASISFRAMEPLUS4_0-vadd e1 (BASISFRAMEPLUS4_0-vadd e2 e3))))

  (BASISFRAMEPLUS4_0-make-3dface o   e1p e12 e2p layerName)
  (BASISFRAMEPLUS4_0-make-3dface o   e1p e13 e3p layerName)
  (BASISFRAMEPLUS4_0-make-3dface o   e2p e23 e3p layerName)
  (BASISFRAMEPLUS4_0-make-3dface top e12 e1p e13 layerName)
  (BASISFRAMEPLUS4_0-make-3dface top e12 e2p e23 layerName)
  (BASISFRAMEPLUS4_0-make-3dface top e13 e3p e23 layerName)
)

;;; ---------- Main Command ----------

(defun c:BASISFRAMEPLUS4_0
  ( / originChoice origin
     e1 e2 e3 end1 end2 end3
     txtHeight
     optArrow optOrigin optLabelOffset optMagnitudes
     optOrtho optOrthon optNormal optPlanes optBox optAxisLabels
     mag1 mag2 mag3 maxLen axisScale
     xAxisStart xAxisEnd yAxisStart yAxisEnd zAxisStart zAxisEnd
     otext1 otext2 otext3 normal normalEnd)

  (prompt "\nBASISFRAMEPLUS4_0 � SAFE-REV + Smart Labels + Color-Matched Labels")

  ;; Origin
  (initget "Yes No")
  (setq originChoice (getkword "\nSpecify custom origin? [Yes/No] <No>: "))
  (if (null originChoice) (setq originChoice "No"))
  (setq origin (if (= originChoice "Yes")
                 (getpoint "\nPick origin: ")
                 '(0 0 0)))

  ;; Basis vectors
  (prompt "\nEnter e1:")
  (setq e1 (list (getreal "\n e1_x: ")
                 (getreal "  e1_y: ")
                 (getreal "  e1_z: ")))
  (setq end1 (BASISFRAMEPLUS4_0-vadd origin e1))

  (prompt "\nEnter e2:")
  (setq e2 (list (getreal "\n e2_x: ")
                 (getreal "  e2_y: ")
                 (getreal "  e2_z: ")))
  (setq end2 (BASISFRAMEPLUS4_0-vadd origin e2))

  (prompt "\nEnter e3:")
  (setq e3 (list (getreal "\n e3_x: ")
                 (getreal "  e3_y: ")
                 (getreal "  e3_z: ")))
  (setq end3 (BASISFRAMEPLUS4_0-vadd origin e3))

  ;; Options
  (initget "Yes No")
  (setq optArrow (getkword "\nArrowheads? [Yes/No] <No>: "))
  (if (null optArrow) (setq optArrow "No"))

  (initget "Circle Cross None")
  (setq optOrigin (getkword "\nOrigin marker? [Circle/Cross/None] <None>: "))
  (if (null optOrigin) (setq optOrigin "None"))

  (initget "Yes No")
  (setq optLabelOffset (getkword "\nUse smart label offset? [Yes/No] <Yes>: "))
  (if (null optLabelOffset) (setq optLabelOffset "Yes"))

  (initget "Yes No")
  (setq optMagnitudes (getkword "\nShow magnitudes? [Yes/No] <No>: "))
  (if (null optMagnitudes) (setq optMagnitudes "No"))

  (initget "Yes No")
  (setq optOrtho (getkword "\nCheck orthogonality? [Yes/No] <No>: "))
  (if (null optOrtho) (setq optOrtho "No"))

  (initget "Yes No")
  (setq optOrthon (getkword "\nCheck orthonormality? [Yes/No] <No>: "))
  (if (null optOrthon) (setq optOrthon "No"))

  (initget "Yes No")
  (setq optNormal (getkword "\nDraw normal vector? [Yes/No] <No>: "))
  (if (null optNormal) (setq optNormal "No"))

  (initget "Yes No")
  (setq optPlanes (getkword "\nDraw coordinate planes? [Yes/No] <No>: "))
  (if (null optPlanes) (setq optPlanes "No"))

  (initget "Yes No")
  (setq optBox (getkword "\nDraw parallelepiped? [Yes/No] <No>: "))
  (if (null optBox) (setq optBox "No"))

  (initget "Yes No")
  (setq optAxisLabels (getkword "\nShow axis labels? [Yes/No] <No>: "))
  (if (null optAxisLabels) (setq optAxisLabels "No"))

  ;; Text height
  (setq txtHeight (getreal "\nLabel text height <0.5>: "))
  (if (null txtHeight) (setq txtHeight 0.5))

  ;; Magnitudes + axis scale
  (setq mag1 (BASISFRAMEPLUS4_0-mag e1)
        mag2 (BASISFRAMEPLUS4_0-mag e2)
        mag3 (BASISFRAMEPLUS4_0-mag e3))
  (setq maxLen (max mag1 (max mag2 mag3)))
  (if (= maxLen 0.0) (setq maxLen 1.0))
  (setq axisScale (* 1.5 maxLen))

  ;; ---------------------------------------------------------------
  ;; World axes (yellow) � LINES FIRST
  ;; ---------------------------------------------------------------
  (setq xAxisStart (BASISFRAMEPLUS4_0-vadd origin (list (- axisScale) 0 0)))
  (setq xAxisEnd   (BASISFRAMEPLUS4_0-vadd origin (list axisScale 0 0)))
  (setq yAxisStart (BASISFRAMEPLUS4_0-vadd origin (list 0 (- axisScale) 0)))
  (setq yAxisEnd   (BASISFRAMEPLUS4_0-vadd origin (list 0 axisScale 0)))
  (setq zAxisStart (BASISFRAMEPLUS4_0-vadd origin (list 0 0 (- axisScale))))
  (setq zAxisEnd   (BASISFRAMEPLUS4_0-vadd origin (list 0 0 axisScale)))

  (BASISFRAMEPLUS4_0-make-line xAxisStart xAxisEnd "LA-BF-AXIS")
  (BASISFRAMEPLUS4_0-make-line yAxisStart yAxisEnd "LA-BF-AXIS")
  (BASISFRAMEPLUS4_0-make-line zAxisStart zAxisEnd "LA-BF-AXIS")

  (if (= optAxisLabels "Yes")
    (progn
      (BASISFRAMEPLUS4_0-make-text xAxisEnd txtHeight "x-axis" "LA-BF-AXIS")
      (BASISFRAMEPLUS4_0-make-text yAxisEnd txtHeight "y-axis" "LA-BF-AXIS")
      (BASISFRAMEPLUS4_0-make-text zAxisEnd txtHeight "z-axis" "LA-BF-AXIS")))

  ;; ---------------------------------------------------------------
  ;; Origin marker � LINES/CIRCLE
  ;; ---------------------------------------------------------------
  (cond
    ((= optOrigin "Circle")
     (BASISFRAMEPLUS4_0-make-circle origin (/ txtHeight 2.0) "LA-BF-ORIGIN"))
    ((= optOrigin "Cross")
     (BASISFRAMEPLUS4_0-make-cross origin txtHeight "LA-BF-ORIGIN"))
  )

  ;; ---------------------------------------------------------------
  ;; Basis vectors � LINES
  ;; ---------------------------------------------------------------
  (BASISFRAMEPLUS4_0-make-line origin end1 "LA-BF-VECTOR")
  (BASISFRAMEPLUS4_0-make-line origin end2 "LA-BF-VECTOR")
  (BASISFRAMEPLUS4_0-make-line origin end3 "LA-BF-VECTOR")

  ;; ---------------------------------------------------------------
  ;; Smart label positions (color-matched) � TEXT
  ;; ---------------------------------------------------------------
  (setq otext1 (BASISFRAMEPLUS4_0-smart-label-point origin end1 e1 txtHeight optLabelOffset))
  (setq otext2 (BASISFRAMEPLUS4_0-smart-label-point origin end2 e2 txtHeight optLabelOffset))
  (setq otext3 (BASISFRAMEPLUS4_0-smart-label-point origin end3 e3 txtHeight optLabelOffset))

  (BASISFRAMEPLUS4_0-make-text otext1 txtHeight "e1" "LA-BF-LABEL-E1")
  (BASISFRAMEPLUS4_0-make-text otext2 txtHeight "e2" "LA-BF-LABEL-E2")
  (BASISFRAMEPLUS4_0-make-text otext3 txtHeight "e3" "LA-BF-LABEL-E3")

  ;; Magnitudes � TEXT
  (if (= optMagnitudes "Yes")
    (progn
      (BASISFRAMEPLUS4_0-make-text (BASISFRAMEPLUS4_0-vadd otext1 (list 0 (* txtHeight 1.2) 0))
                       txtHeight (strcat "|e1|=" (rtos mag1 2 3)) "LA-BF-MAG")
      (BASISFRAMEPLUS4_0-make-text (BASISFRAMEPLUS4_0-vadd otext2 (list 0 (* txtHeight 1.2) 0))
                       txtHeight (strcat "|e2|=" (rtos mag2 2 3)) "LA-BF-MAG")
      (BASISFRAMEPLUS4_0-make-text (BASISFRAMEPLUS4_0-vadd otext3 (list 0 (* txtHeight 1.2) 0))
                       txtHeight (strcat "|e3|=" (rtos mag3 2 3)) "LA-BF-MAG")))

  ;; Normal vector � LINE + TEXT
  (if (= optNormal "Yes")
    (progn
      (setq normal (BASISFRAMEPLUS4_0-cross e1 e2))
      (setq normalEnd (BASISFRAMEPLUS4_0-vadd origin normal))
      (BASISFRAMEPLUS4_0-make-line origin normalEnd "LA-BF-NORMAL")
      (BASISFRAMEPLUS4_0-make-text (BASISFRAMEPLUS4_0-vadd normalEnd (list 0 (* txtHeight 0.5) 0))
                       txtHeight "n" "LA-BF-NORMAL")))

  ;; ---------------------------------------------------------------
  ;; 3DFACE GEOMETRY � DRAW LAST TO AVOID VIEW ROTATION
  ;; ---------------------------------------------------------------

  ;; Coordinate planes (3DFACE)
  (if (= optPlanes "Yes")
    (progn
      (BASISFRAMEPLUS4_0-draw-plane-3dface origin e1 e2 "LA-BF-PLANE")
      (BASISFRAMEPLUS4_0-draw-plane-3dface origin e1 e3 "LA-BF-PLANE")
      (BASISFRAMEPLUS4_0-draw-plane-3dface origin e2 e3 "LA-BF-PLANE")))

  ;; Parallelepiped (LINE edges + 3DFACE faces)
  (if (= optBox "Yes")
    (progn
      (BASISFRAMEPLUS4_0-draw-parallelepiped-edges origin e1 e2 e3 "LA-BF-BOX")
      (BASISFRAMEPLUS4_0-draw-parallelepiped-faces origin e1 e2 e3 "LA-BF-BOX")))

  (prompt "\nBASISFRAMEPLUS4_0 complete.")
  (princ)
)
