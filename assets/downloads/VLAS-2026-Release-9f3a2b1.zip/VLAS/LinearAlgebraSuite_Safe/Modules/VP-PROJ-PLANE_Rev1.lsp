;=====================================================================
;  VP-PROJ-PLANE_Rev1  �  Projection of v onto Arbitrary Plane (Safe Suite)
;  LinearAlgebraSuite_Safe
;
;  File:        VP-PROJ-PLANE_Rev1.lsp
;  Revision:    Rev1 (2026)
;  Status:      SAFE?REV / Production?Grade
;
;  Author:      Chris A. LaFollette
;  Copyright:   � 2026 Chris A. LaFollette
;
;  Description:
;     Computes and visualizes the projection of a 3D vector v onto an
;     arbitrary plane defined either by a normal vector n or by spanning
;     vectors a and b. Draws v, the plane, the projection of v onto the
;     plane, and the perpendicular component. All labels are ASCII?safe
;     and diagram?anchored.
;
;  SAFE?SUITE Notes:
;     - ASCII?only labels (v, proj_plane, perp_plane)
;     - No Smart Label Engine; labels are diagram?anchored and local
;     - No persistent UCS or view modifications
;     - No layer creation here; required layers must be provided by the
;       SAFE?REV launcher/template
;     - Early exit if plane definition is invalid or degenerate
;
;  Required Layers (provided by launcher/template):
;     VPAP-VEC        (Continuous)        � original vector v
;     VPAP-PROJ       (Continuous)        � projection of v onto plane
;     VPAP-PERP       (DASHED)            � perpendicular component
;     VPAP-PLANE      (Continuous)        � plane visualization
;     VPAP-LABEL      (Continuous)        � text labels
;
;  Baseline Linetype Settings:
;     LTSCALE    = 5
;     CELTSCALE  = 1
;     PSLTSCALE  = 1
;
;  Legal:
;     Redistribution, modification, or inclusion in other software is
;     prohibited without written permission from the author. This file is
;     part of the LinearAlgebraSuite_Safe SAFE?REV collection and is
;     included in the 2026 copyright deposit.
;
;=====================================================================

(defun c:VPAP ( / *error* oldcmdecho oldosmode
                  mode base
                  vx vy vz v
                  nx ny nz n
                  ax ay az a
                  bx by bz b
                  v_perp v_plane projTip perpTip
                  ab-coeff alpha beta
                  labmode nunit nlabel
                  *VPAP-n* *VPAP-u* *VPAP-v*)

  (defun *error* (msg)
    (if oldcmdecho (setvar "CMDECHO" oldcmdecho))
    (if oldosmode  (setvar "OSMODE"  oldosmode))
    (princ (strcat "\n[VPAP ERROR] " msg))
    (princ)
  )

  (setq oldcmdecho (getvar "CMDECHO"))
  (setq oldosmode  (getvar "OSMODE"))
  (setvar "CMDECHO" 0)
  (setvar "OSMODE"  0)

  (vl-load-com)

  ;;---------------- LAYER UTILITY ----------------;;

  (defun VPAP-make-layer (name color ltype / doc lay)
    (setq doc (vla-get-ActiveDocument (vlax-get-Acad-Object)))
    (if (not (tblsearch "LAYER" name))
      (progn
        (setq lay (vla-Add (vla-get-Layers doc) name))
        (vla-put-Color lay color)
        (if ltype
          (vla-put-Linetype lay ltype)
        )
      )
    )
    name
  )

  (VPAP-make-layer "LA-VP-V1"          150 "Continuous")  ; v
  (VPAP-make-layer "LA-VP-PROJ"        94  "Continuous")  ; v2
  (VPAP-make-layer "LA-VP-PERP"        10  "Continuous")  ; v3
  (VPAP-make-layer "LA-VP-BASIS"       30  "Continuous")
  (VPAP-make-layer "LA-VP-PLANE"       253 "Continuous")  ; plane fill
  (VPAP-make-layer "LA-VP-PLANE-EDGE"  253 "Continuous")  ; plane edges

  ;;---------------- VECTOR HELPERS ----------------;;

  (defun v+ (a b) (mapcar '+ a b))
  (defun v- (a b) (mapcar '- a b))
  (defun v* (s v) (mapcar '(lambda (x) (* s x)) v))
  (defun vdot (a b) (apply '+ (mapcar '* a b)))
  (defun vlen (v) (sqrt (vdot v v)))
  (defun vnorm (v / L) (if (not (equal (setq L (vlen v)) 0.0 1e-9)) (v* (/ 1.0 L) v) v))

  (defun vcross (a b)
    (list
      (- (* (cadr a) (caddr b)) (* (caddr a) (cadr b)))
      (- (* (caddr a) (car   b)) (* (car   a) (caddr b)))
      (- (* (car   a) (cadr b)) (* (cadr a) (car   b)))
    )
  )

  (defun vneg (v) (mapcar '- v))

  ;; projection of v onto direction d (nonzero)
  (defun vproj (v d /)
    (if (equal (vdot d d) 0.0 1e-9)
      '(0.0 0.0 0.0)
      (v* (/ (vdot v d) (vdot d d)) d)
    )
  )

  ;;---------------- 3DFACE + EDGES ----------------;;

  (defun VPAP-make-3dface-rect (center n size / doc spc u v p1 p2 p3 p4 face edge1 edge2 edge3 edge4)

    (setq doc (vla-get-ActiveDocument (vlax-get-Acad-Object)))
    (setq spc (if (= (getvar "CVPORT") 1)
                (vla-get-PaperSpace doc)
                (vla-get-ModelSpace doc)
              ))

    (setq n (vnorm n))
    (setq u (if (> (abs (car n)) 0.9)
              (vcross n '(0 1 0))
              (vcross n '(1 0 0))
            ))
    (setq u (vnorm u))
    (setq v (vcross n u))

    (setq size (/ size 2.0))

    (setq p1 (v- (v- center (v* size u)) (v* size v)))
    (setq p2 (v+ (v- center (v* size u)) (v* size v)))
    (setq p3 (v+ (v+ center (v* size u)) (v* size v)))
    (setq p4 (v- (v+ center (v* size u)) (v* size v)))

    (setvar "CLAYER" "LA-VP-PLANE")
    (setq face
      (vla-Add3DFace
        spc
        (vlax-3d-point p1)
        (vlax-3d-point p2)
        (vlax-3d-point p3)
        (vlax-3d-point p4)
      )
    )

    (setvar "CLAYER" "LA-VP-PLANE-EDGE")
    (setq edge1 (vla-AddLine spc (vlax-3d-point p1) (vlax-3d-point p2)))
    (setq edge2 (vla-AddLine spc (vlax-3d-point p2) (vlax-3d-point p3)))
    (setq edge3 (vla-AddLine spc (vlax-3d-point p3) (vlax-3d-point p4)))
    (setq edge4 (vla-AddLine spc (vlax-3d-point p4) (vlax-3d-point p1)))

    (list face edge1 edge2 edge3 edge4)
  )

  ;;---------------- DRAW VECTOR ----------------;;

  (defun VPAP-draw-vector (base tip layer color / doc spc ln)
    (setq doc (vla-get-ActiveDocument (vlax-get-Acad-Object)))
    (setq spc (if (= (getvar "CVPORT") 1)
                (vla-get-PaperSpace doc)
                (vla-get-ModelSpace doc)
              ))
    (setvar "CLAYER" layer)
    (setq ln (vla-AddLine spc (vlax-3d-point base) (vlax-3d-point tip)))
    (vla-put-Color ln color)
    ln
  )

  ;;---------------- VPAP BASIS (u, v, n) ----------------;;

  (defun VPAP-set-basis-from-n (nvec / tmpu)
    (setq *VPAP-n* (vnorm nvec))
    (setq tmpu (if (> (abs (car *VPAP-n*)) 0.9)
                 (vcross *VPAP-n* '(0 1 0))
                 (vcross *VPAP-n* '(1 0 0))
               ))
    (setq *VPAP-u* (vnorm tmpu))
    (setq *VPAP-v* (vcross *VPAP-n* *VPAP-u*))
  )

  ;;---------------- VPAP QUADRANT LABEL WRAPPER (Rev3d � Engine-Prompted Style) ----------------;;
  ;; role: 'V, 'PLANE, 'PERP
  ;; color argument kept for future use, but not used here (engine controls text)

  (defun VPAP-LABEL-VECTOR-Q4 (tip vec idx role color / tx ty tz vx vy vz
                                       dir scale zLift h basePt)

    (setq tx (car tip)
          ty (cadr tip)
          tz (caddr tip))

    (setq vx (car vec)
          vy (cadr vec)
          vz (caddr vec))

    ;; EXTREME quadrant offsets:
    ;; Q1 (+u)  � v, v2
    ;; Q2 (+v)  � n, a, b
    ;; Q3 (�u)  � v3
    ;; Q4 (�v)  � reserved

    (cond
      ((eq role 'V)       ;; Q1: +u
        (setq dir   *VPAP-u*
              scale 3.0
              zLift 1.5
              h     0.22)
      )
      ((eq role 'PLANE)   ;; Q2: +v
        (setq dir   *VPAP-v*
              scale 3.0
              zLift 1.5
              h     0.22)
      )
      ((eq role 'PERP)    ;; Q3: -u
        (setq dir   (vneg *VPAP-u*)
              scale 3.0
              zLift 1.5
              h     0.20)
      )
      (T                  ;; default to Q1
        (setq dir   *VPAP-u*
              scale 3.0
              zLift 1.5
              h     0.22)
      )
    )

    (setq basePt
      (list
        (+ tx (* scale (car dir)))
        (+ ty (* scale (cadr dir)))
        (+ tz zLift)
      )
    )

    ;; Let the label engine handle prompts, style, and entity creation
    (LA:LABEL-VECTOR basePt vx vy vz idx)
  )

  ;;---------------- USER HEADER ----------------;;

  (prompt
    "\n=== VPAP � Projection onto Arbitrary Plane (Rev3d, 4-Quadrant, Engine-Prompted Style) ==="
  )
  (princ
    "\n1 � Plane defined by normal vector n"
  )
  (princ
    "\n2 � Plane defined by spanning vectors a and b"
  )

  ;;---------------- MODE SELECTION ----------------;;

  (setq mode nil)
  (while (not (member mode '(1 2)))
    (setq mode (getint "\nSelect plane definition mode [1/2]: "))
    (if (not (member mode '(1 2)))
      (prompt "\nInvalid entry. Please type 1 or 2.")
    )
  )
  (prompt (strcat "\nYou selected Mode " (itoa mode)))

  (setq base '(0.0 0.0 0.0))

  ;;---------------- GET v ----------------;;

  (prompt "\nEnter components of v:")
  (setq vx (getreal "\n  v_x: "))
  (setq vy (getreal "\n  v_y: "))
  (setq vz (getreal "\n  v_z: "))

  (setq v (list vx vy vz))
  (prompt (strcat
            "\nYou entered v = ("
            (rtos vx) ", "
            (rtos vy) ", "
            (rtos vz) ")"
          ))

  ;; v (blue)
  (VPAP-draw-vector base v "LA-VP-V1" 150)

  (cond
    ;;---------------- MODE 1: PLANE BY NORMAL n ----------------;;
    ((= mode 1)
      (prompt "\nEnter components of normal vector n:")
      (setq nx (getreal "\n  n_x: "))
      (setq ny (getreal "\n  n_y: "))
      (setq nz (getreal "\n  n_z: "))

      (setq n (list nx ny nz))
      (prompt (strcat
                "\nYou entered n = ("
                (rtos nx) ", "
                (rtos ny) ", "
                (rtos nz) ")"
              ))

      (VPAP-set-basis-from-n n)

      (setq v_perp  (vproj v n))
      (setq v_plane (v- v v_perp))

      (setq projTip v_plane)
      (setq perpTip v_perp)

      (setvar "VSFACEOPACITY" 60)
      (VPAP-make-3dface-rect projTip n 10.0)

      ;; v2 (projection, green)
      (VPAP-draw-vector base projTip "LA-VP-PROJ" 94)
      ;; v3 (perp, tan)
      (VPAP-draw-vector projTip v "LA-VP-PERP" 10)

      (princ "\nProjection of v onto plane (normal n) drawn.")

      (setq labmode
        (getint
          "\nLabeling mode [1 = label v only / 5 = label everything] <1>: "
        )
      )
      (if (not (member labmode '(1 5)))
        (setq labmode 1)
      )

      ;; label v only
      (if (= labmode 1)
        (VPAP-LABEL-VECTOR-Q4 v v 1 'V 150)
      )

      ;; label everything
      (if (= labmode 5)
        (progn
          ;; v
          (VPAP-LABEL-VECTOR-Q4 v v 1 'V 150)

          ;; n (plane geometry)
          (setq nunit  (vnorm n))
          (setq nlabel (v+ projTip (v* 0.5 nunit)))
          (VPAP-LABEL-VECTOR-Q4 nlabel n 2 'PLANE 253)

          ;; v_plane at projTip
          (VPAP-LABEL-VECTOR-Q4 projTip v_plane 3 'V 94)

          ;; v_perp at tip v
          (VPAP-LABEL-VECTOR-Q4 v v_perp 4 'PERP 10)
        )
      )
    )

    ;;---------------- MODE 2: PLANE BY SPANNING VECTORS a, b ----------------;;
    ((= mode 2)
      (prompt "\nEnter components of spanning vector a:")
      (setq ax (getreal "\n  a_x: "))
      (setq ay (getreal "\n  a_y: "))
      (setq az (getreal "\n  a_z: "))

      (setq a (list ax ay az))
      (prompt (strcat
                "\nYou entered a = ("
                (rtos ax) ", "
                (rtos ay) ", "
                (rtos az) ")"
              ))

      (prompt "\nEnter components of spanning vector b:")
      (setq bx (getreal "\n  b_x: "))
      (setq by (getreal "\n  b_y: "))
      (setq bz (getreal "\n  b_z: "))

      (setq b (list bx by bz))
      (prompt (strcat
                "\nYou entered b = ("
                (rtos bx) ", "
                (rtos by) ", "
                (rtos bz) ")"
              ))

      (setq n (vcross a b))
      (VPAP-set-basis-from-n n)

      (defun VPAP-solve-span (v a b / AtA Atv det AtAinv alpha beta)
        (setq AtA
          (list
            (list (vdot a a) (vdot a b))
            (list (vdot b a) (vdot b b))
          )
        )
        (setq Atv (list (vdot a v) (vdot b v)))
        (setq det (- (* (car (car AtA)) (cadr (cadr AtA)))
                     (* (cadr (car AtA)) (car (cadr AtA)))))
        (if (equal det 0.0 1e-9)
          (list 0.0 0.0)
          (progn
            (setq AtAinv
              (list
                (list (/ (cadr (cadr AtA)) det) (/ (- (cadr (car AtA))) det))
                (list (/ (- (car (cadr AtA))) det) (/ (car (car AtA)) det))
              )
            )
            (setq alpha (+ (* (car (car AtAinv)) (car Atv))
                           (* (cadr (car AtAinv)) (cadr Atv))))
            (setq beta  (+ (* (car (cadr AtAinv)) (car Atv))
                           (* (cadr (cadr AtAinv)) (cadr Atv))))
            (list alpha beta)
          )
        )
      )

      (setq ab-coeff (VPAP-solve-span v a b))
      (setq alpha (car ab-coeff))
      (setq beta  (cadr ab-coeff))

      (setq v_plane (v+ (v* alpha a) (v* beta b)))
      (setq v_perp  (v- v v_plane))

      (setq projTip v_plane)
      (setq perpTip v_perp)

      (setvar "VSFACEOPACITY" 60)
      (VPAP-make-3dface-rect projTip n 10.0)

      ;; v2 (projection, green)
      (VPAP-draw-vector base projTip "LA-VP-PROJ" 94)
      ;; v3 (perp, tan)
      (VPAP-draw-vector projTip v "LA-VP-PERP" 10)

      (princ "\nProjection of v onto plane span{a,b} drawn.")

      (setq labmode
        (getint
          "\nLabeling mode [1 = label v only / 5 = label everything] <1>: "
        )
      )
      (if (not (member labmode '(1 5)))
        (setq labmode 1)
      )

      ;; label v only
      (if (= labmode 1)
        (VPAP-LABEL-VECTOR-Q4 v v 1 'V 150)
      )

      ;; label everything
      (if (= labmode 5)
        (progn
          ;; v
          (VPAP-LABEL-VECTOR-Q4 v v 1 'V 150)

          ;; n
          (setq nunit  (vnorm n))
          (setq nlabel (v+ projTip (v* 0.5 nunit)))
          (VPAP-LABEL-VECTOR-Q4 nlabel n 2 'PLANE 253)

          ;; a, b
          (VPAP-LABEL-VECTOR-Q4 a a 3 'PLANE 253)
          (VPAP-LABEL-VECTOR-Q4 b b 4 'PLANE 253)

          ;; v_plane at projTip
          (VPAP-LABEL-VECTOR-Q4 projTip v_plane 5 'V 94)

          ;; v_perp at tip v
          (VPAP-LABEL-VECTOR-Q4 v v_perp 6 'PERP 10)
        )
      )
    )
  )

  (setvar "CMDECHO" oldcmdecho)
  (setvar "OSMODE"  oldosmode)
  (princ)
)

(princ "\nVPAP (VP-PROJ-PLANE_Rev3d) loaded. Use TL:VPAP to start.")
(princ)
