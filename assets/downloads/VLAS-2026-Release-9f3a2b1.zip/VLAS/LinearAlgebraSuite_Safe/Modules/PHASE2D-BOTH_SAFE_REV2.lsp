;=====================================================================
;  cadcando Visual Linear Algebra System (VLAS)
;  Module: PHASE2D-BOTH
;  Purpose: 2D Linear System Phase Portraits (Stable + Unstable)
;  Author: Chris A. LaFollette
;
;  Legal Notice:
;  This module is part of the cadcando Visual Linear Algebra System.
;  Redistribution, modification, or inclusion in other software is
;  prohibited without written permission from the author.
;  Educational use within accredited institutions is permitted.
;  All rights reserved.
;=====================================================================

;;; ------------------------------------------------------------
;;; Environment guard (same pattern as TDTRACE_SAFE_B)
;;; ------------------------------------------------------------

(if (not *VLAS-env-ready*)
  (progn
    (princ "\nVLAS environment not initialized. Run TRANSFORM_LAUNCHER_MINI_MENU_FULL first.")
    (exit)
  )
)

;;; ------------------------------------------------------------
;;; TDTRACE-safe helpers (LEFT PANEL)
;;; Reused from TDTRACE_SAFE_B (unchanged behavior)
;;; ------------------------------------------------------------

(defun TDTRACE-MKLINE (p1 p2 layer)
  (entmake
    (list
      (cons 0 "LINE")
      (cons 8 "LA-TD-CURVES")   ;; base layer tag
      (cons 8 layer)
      (cons 10 p1)
      (cons 11 p2)
    )
  )
)

(defun TDTRACE-MKTEXT (pt h rot str layer)
  (entmake
    (list
      (cons 0 "TEXT")
      (cons 8 layer)
      (cons 10 pt)
      (cons 40 h)
      (cons 50 rot)
      (cons 1 str)
    )
  )
)

(defun TDTRACE-DRAW-AXES ( / L )
  (setq L 10.0)
  (TDTRACE-MKLINE (list (- L) 0.0 0.0) (list L 0.0 0.0) "TD-AXES")
  (TDTRACE-MKLINE (list 0.0 (- L) 0.0) (list 0.0 L 0.0) "TD-AXES")
)

(defun TDTRACE-DRAW-CURVE-HARDCODED ( / )
  ;; (full 96?segment curve from TDTRACE_SAFE_B)
  ;; t = -12.00 to -11.75
  (TDTRACE-MKLINE (list -12.00 36.0000 0.0) (list -11.75 34.5156 0.0) "LA-TD-CURVES")
  ;; t = -11.75 to -11.50
  (TDTRACE-MKLINE (list -11.75 34.5156 0.0) (list -11.50 33.0625 0.0) "LA-TD-CURVES")
  ;; t = -11.50 to -11.25
  (TDTRACE-MKLINE (list -11.50 33.0625 0.0) (list -11.25 31.6406 0.0) "LA-TD-CURVES")
  ;; t = -11.25 to -11.00
  (TDTRACE-MKLINE (list -11.25 31.6406 0.0) (list -11.00 30.2500 0.0) "LA-TD-CURVES")
  ;; t = -11.00 to -10.75
  (TDTRACE-MKLINE (list -11.00 30.2500 0.0) (list -10.75 28.8906 0.0) "LA-TD-CURVES")
  ;; t = -10.75 to -10.50
  (TDTRACE-MKLINE (list -10.75 28.8906 0.0) (list -10.50 27.5625 0.0) "LA-TD-CURVES")
  ;; t = -10.50 to -10.25
  (TDTRACE-MKLINE (list -10.50 27.5625 0.0) (list -10.25 26.2656 0.0) "LA-TD-CURVES")
  ;; t = -10.25 to -10.00
  (TDTRACE-MKLINE (list -10.25 26.2656 0.0) (list -10.00 25.0000 0.0) "LA-TD-CURVES")
  ;; t = -10.00 to -9.75
  (TDTRACE-MKLINE (list -10.00 25.0000 0.0) (list -9.75 23.7656 0.0) "LA-TD-CURVES")
  ;; t = -9.75 to -9.50
  (TDTRACE-MKLINE (list -9.75 23.7656 0.0) (list -9.50 22.5625 0.0) "LA-TD-CURVES")
  ;; t = -9.50 to -9.25
  (TDTRACE-MKLINE (list -9.50 22.5625 0.0) (list -9.25 21.3906 0.0) "LA-TD-CURVES")
  ;; t = -9.25 to -9.00
  (TDTRACE-MKLINE (list -9.25 21.3906 0.0) (list -9.00 20.2500 0.0) "LA-TD-CURVES")
  ;; t = -9.00 to -8.75
  (TDTRACE-MKLINE (list -9.00 20.2500 0.0) (list -8.75 19.1406 0.0) "LA-TD-CURVES")
  ;; t = -8.75 to -8.50
  (TDTRACE-MKLINE (list -8.75 19.1406 0.0) (list -8.50 18.0625 0.0) "LA-TD-CURVES")
  ;; t = -8.50 to -8.25
  (TDTRACE-MKLINE (list -8.50 18.0625 0.0) (list -8.25 17.0156 0.0) "LA-TD-CURVES")
  ;; t = -8.25 to -8.00
  (TDTRACE-MKLINE (list -8.25 17.0156 0.0) (list -8.00 16.0000 0.0) "LA-TD-CURVES")
  ;; t = -8.00 to -7.75
  (TDTRACE-MKLINE (list -8.00 16.0000 0.0) (list -7.75 15.0156 0.0) "LA-TD-CURVES")
  ;; t = -7.75 to -7.50
  (TDTRACE-MKLINE (list -7.75 15.0156 0.0) (list -7.50 14.0625 0.0) "LA-TD-CURVES")
  ;; t = -7.50 to -7.25
  (TDTRACE-MKLINE (list -7.50 14.0625 0.0) (list -7.25 13.1406 0.0) "LA-TD-CURVES")
  ;; t = -7.25 to -7.00
  (TDTRACE-MKLINE (list -7.25 13.1406 0.0) (list -7.00 12.2500 0.0) "LA-TD-CURVES")
  ;; t = -7.00 to -6.75
  (TDTRACE-MKLINE (list -7.00 12.2500 0.0) (list -6.75 11.3906 0.0) "LA-TD-CURVES")
  ;; t = -6.75 to -6.50
  (TDTRACE-MKLINE (list -6.75 11.3906 0.0) (list -6.50 10.5625 0.0) "LA-TD-CURVES")
  ;; t = -6.50 to -6.25
  (TDTRACE-MKLINE (list -6.50 10.5625 0.0) (list -6.25 9.7656 0.0) "LA-TD-CURVES")
  ;; t = -6.25 to -6.00
  (TDTRACE-MKLINE (list -6.25 9.7656 0.0) (list -6.00 9.0000 0.0) "LA-TD-CURVES")
  ;; t = -6.00 to -5.75
  (TDTRACE-MKLINE (list -6.00 9.0000 0.0) (list -5.75 8.2656 0.0) "LA-TD-CURVES")
  ;; t = -5.75 to -5.50
  (TDTRACE-MKLINE (list -5.75 8.2656 0.0) (list -5.50 7.5625 0.0) "LA-TD-CURVES")
  ;; t = -5.50 to -5.25
  (TDTRACE-MKLINE (list -5.50 7.5625 0.0) (list -5.25 6.8906 0.0) "LA-TD-CURVES")
  ;; t = -5.25 to -5.00
  (TDTRACE-MKLINE (list -5.25 6.8906 0.0) (list -5.00 6.2500 0.0) "LA-TD-CURVES")
  ;; t = -5.00 to -4.75
  (TDTRACE-MKLINE (list -5.00 6.2500 0.0) (list -4.75 5.6406 0.0) "LA-TD-CURVES")
  ;; t = -4.75 to -4.50
  (TDTRACE-MKLINE (list -4.75 5.6406 0.0) (list -4.50 5.0625 0.0) "LA-TD-CURVES")
  ;; t = -4.50 to -4.25
  (TDTRACE-MKLINE (list -4.50 5.0625 0.0) (list -4.25 4.5156 0.0) "LA-TD-CURVES")
  ;; t = -4.25 to -4.00
  (TDTRACE-MKLINE (list -4.25 4.5156 0.0) (list -4.00 4.0000 0.0) "LA-TD-CURVES")
  ;; t = -4.00 to -3.75
  (TDTRACE-MKLINE (list -4.00 4.0000 0.0) (list -3.75 3.5156 0.0) "LA-TD-CURVES")
  ;; t = -3.75 to -3.50
  (TDTRACE-MKLINE (list -3.75 3.5156 0.0) (list -3.50 3.0625 0.0) "LA-TD-CURVES")
  ;; t = -3.50 to -3.25
  (TDTRACE-MKLINE (list -3.50 3.0625 0.0) (list -3.25 2.6406 0.0) "LA-TD-CURVES")
  ;; t = -3.25 to -3.00
  (TDTRACE-MKLINE (list -3.25 2.6406 0.0) (list -3.00 2.2500 0.0) "LA-TD-CURVES")
  ;; t = -3.00 to -2.75
  (TDTRACE-MKLINE (list -3.00 2.2500 0.0) (list -2.75 1.8906 0.0) "LA-TD-CURVES")
  ;; t = -2.75 to -2.50
  (TDTRACE-MKLINE (list -2.75 1.8906 0.0) (list -2.50 1.5625 0.0) "LA-TD-CURVES")
  ;; t = -2.50 to -2.25
  (TDTRACE-MKLINE (list -2.50 1.5625 0.0) (list -2.25 1.2656 0.0) "LA-TD-CURVES")
  ;; t = -2.25 to -2.00
  (TDTRACE-MKLINE (list -2.25 1.2656 0.0) (list -2.00 1.0000 0.0) "LA-TD-CURVES")
  ;; t = -2.00 to -1.75
  (TDTRACE-MKLINE (list -2.00 1.0000 0.0) (list -1.75 0.7656 0.0) "LA-TD-CURVES")
  ;; t = -1.75 to -1.50
  (TDTRACE-MKLINE (list -1.75 0.7656 0.0) (list -1.50 0.5625 0.0) "LA-TD-CURVES")
  ;; t = -1.50 to -1.25
  (TDTRACE-MKLINE (list -1.50 0.5625 0.0) (list -1.25 0.3906 0.0) "LA-TD-CURVES")
  ;; t = -1.25 to -1.00
  (TDTRACE-MKLINE (list -1.25 0.3906 0.0) (list -1.00 0.2500 0.0) "LA-TD-CURVES")
  ;; t = -1.00 to -0.75
  (TDTRACE-MKLINE (list -1.00 0.2500 0.0) (list -0.75 0.1406 0.0) "LA-TD-CURVES")
  ;; t = -0.75 to -0.50
  (TDTRACE-MKLINE (list -0.75 0.1406 0.0) (list -0.50 0.0625 0.0) "LA-TD-CURVES")
  ;; t = -0.50 to -0.25
  (TDTRACE-MKLINE (list -0.50 0.0625 0.0) (list -0.25 0.0156 0.0) "LA-TD-CURVES")
  ;; t = -0.25 to 0.00
  (TDTRACE-MKLINE (list -0.25 0.0156 0.0) (list 0.00 0.0000 0.0) "LA-TD-CURVES")
  ;; t = 0.00 to 0.25
  (TDTRACE-MKLINE (list 0.00 0.0000 0.0) (list 0.25 0.0156 0.0) "LA-TD-CURVES")
  ;; t = 0.25 to 0.50
  (TDTRACE-MKLINE (list 0.25 0.0156 0.0) (list 0.50 0.0625 0.0) "LA-TD-CURVES")
  ;; t = 0.50 to 0.75
  (TDTRACE-MKLINE (list 0.50 0.0625 0.0) (list 0.75 0.1406 0.0) "LA-TD-CURVES")
  ;; t = 0.75 to 1.00
  (TDTRACE-MKLINE (list 0.75 0.1406 0.0) (list 1.00 0.2500 0.0) "LA-TD-CURVES")
  ;; t = 1.00 to 1.25
  (TDTRACE-MKLINE (list 1.00 0.2500 0.0) (list 1.25 0.3906 0.0) "LA-TD-CURVES")
  ;; t = 1.25 to 1.50
  (TDTRACE-MKLINE (list 1.25 0.3906 0.0) (list 1.50 0.5625 0.0) "LA-TD-CURVES")
  ;; t = 1.50 to 1.75
  (TDTRACE-MKLINE (list 1.50 0.5625 0.0) (list 1.75 0.7656 0.0) "LA-TD-CURVES")
  ;; t = 1.75 to 2.00
  (TDTRACE-MKLINE (list 1.75 0.7656 0.0) (list 2.00 1.0000 0.0) "LA-TD-CURVES")
  ;; t = 2.00 to 2.25
  (TDTRACE-MKLINE (list 2.00 1.0000 0.0) (list 2.25 1.2656 0.0) "LA-TD-CURVES")
  ;; t = 2.25 to 2.50
  (TDTRACE-MKLINE (list 2.25 1.2656 0.0) (list 2.50 1.5625 0.0) "LA-TD-CURVES")
  ;; t = 2.50 to 2.75
  (TDTRACE-MKLINE (list 2.50 1.5625 0.0) (list 2.75 1.8906 0.0) "LA-TD-CURVES")
  ;; t = 2.75 to 3.00
  (TDTRACE-MKLINE (list 2.75 1.8906 0.0) (list 3.00 2.2500 0.0) "LA-TD-CURVES")
  ;; t = 3.00 to 3.25
  (TDTRACE-MKLINE (list 3.00 2.2500 0.0) (list 3.25 2.6406 0.0) "LA-TD-CURVES")
  ;; t = 3.25 to 3.50
  (TDTRACE-MKLINE (list 3.25 2.6406 0.0) (list 3.50 3.0625 0.0) "LA-TD-CURVES")
  ;; t = 3.50 to 3.75
  (TDTRACE-MKLINE (list 3.50 3.0625 0.0) (list 3.75 3.5156 0.0) "LA-TD-CURVES")
  ;; t = 3.75 to 4.00
  (TDTRACE-MKLINE (list 3.75 3.5156 0.0) (list 4.00 4.0000 0.0) "LA-TD-CURVES")
  ;; t = 4.00 to 4.25
  (TDTRACE-MKLINE (list 4.00 4.0000 0.0) (list 4.25 4.5156 0.0) "LA-TD-CURVES")
  ;; t = 4.25 to 4.50
  (TDTRACE-MKLINE (list 4.25 4.5156 0.0) (list 4.50 5.0625 0.0) "LA-TD-CURVES")
  ;; t = 4.50 to 4.75
  (TDTRACE-MKLINE (list 4.50 5.0625 0.0) (list 4.75 5.6406 0.0) "LA-TD-CURVES")
  ;; t = 4.75 to 5.00
  (TDTRACE-MKLINE (list 4.75 5.6406 0.0) (list 5.00 6.2500 0.0) "LA-TD-CURVES")
  ;; t = 5.00 to 5.25
  (TDTRACE-MKLINE (list 5.00 6.2500 0.0) (list 5.25 6.8906 0.0) "LA-TD-CURVES")
  ;; t = 5.25 to 5.50
  (TDTRACE-MKLINE (list 5.25 6.8906 0.0) (list 5.50 7.5625 0.0) "LA-TD-CURVES")
  ;; t = 5.50 to 5.75
  (TDTRACE-MKLINE (list 5.50 7.5625 0.0) (list 5.75 8.2656 0.0) "LA-TD-CURVES")
  ;; t = 5.75 to 6.00
  (TDTRACE-MKLINE (list 5.75 8.2656 0.0) (list 6.00 9.0000 0.0) "LA-TD-CURVES")
  ;; t = 6.00 to 6.25
  (TDTRACE-MKLINE (list 6.00 9.0000 0.0) (list 6.25 9.7656 0.0) "LA-TD-CURVES")
  ;; t = 6.25 to 6.50
  (TDTRACE-MKLINE (list 6.25 9.7656 0.0) (list 6.50 10.5625 0.0) "LA-TD-CURVES")
  ;; t = 6.50 to 6.75
  (TDTRACE-MKLINE (list 6.50 10.5625 0.0) (list 6.75 11.3906 0.0) "LA-TD-CURVES")
  ;; t = 6.75 to 7.00
  (TDTRACE-MKLINE (list 6.75 11.3906 0.0) (list 7.00 12.2500 0.0) "LA-TD-CURVES")
  ;; t = 7.00 to 7.25
  (TDTRACE-MKLINE (list 7.00 12.2500 0.0) (list 7.25 13.1406 0.0) "LA-TD-CURVES")
  ;; t = 7.25 to 7.50
  (TDTRACE-MKLINE (list 7.25 13.1406 0.0) (list 7.50 14.0625 0.0) "LA-TD-CURVES")
  ;; t = 7.50 to 7.75
  (TDTRACE-MKLINE (list 7.50 14.0625 0.0) (list 7.75 15.0156 0.0) "LA-TD-CURVES")
  ;; t = 7.75 to 8.00
  (TDTRACE-MKLINE (list 7.75 15.0156 0.0) (list 8.00 16.0000 0.0) "LA-TD-CURVES")
  ;; t = 8.00 to 8.25
  (TDTRACE-MKLINE (list 8.00 16.0000 0.0) (list 8.25 17.0156 0.0) "LA-TD-CURVES")
  ;; t = 8.25 to 8.50
  (TDTRACE-MKLINE (list 8.25 17.0156 0.0) (list 8.50 18.0625 0.0) "LA-TD-CURVES")
  ;; t = 8.50 to 8.75
  (TDTRACE-MKLINE (list 8.50 18.0625 0.0) (list 8.75 19.1406 0.0) "LA-TD-CURVES")
  ;; t = 8.75 to 9.00
  (TDTRACE-MKLINE (list 8.75 19.1406 0.0) (list 9.00 20.2500 0.0) "LA-TD-CURVES")
  ;; t = 9.00 to 9.25
  (TDTRACE-MKLINE (list 9.00 20.2500 0.0) (list 9.25 21.3906 0.0) "LA-TD-CURVES")
  ;; t = 9.25 to 9.50
  (TDTRACE-MKLINE (list 9.25 21.3906 0.0) (list 9.50 22.5625 0.0) "LA-TD-CURVES")
  ;; t = 9.50 to 9.75
  (TDTRACE-MKLINE (list 9.50 22.5625 0.0) (list 9.75 23.7656 0.0) "LA-TD-CURVES")
  ;; t = 9.75 to 10.00
  (TDTRACE-MKLINE (list 9.75 23.7656 0.0) (list 10.00 25.0000 0.0) "LA-TD-CURVES")
  ;; t = 10.00 to 10.25
  (TDTRACE-MKLINE (list 10.00 25.0000 0.0) (list 10.25 26.2656 0.0) "LA-TD-CURVES")
  ;; t = 10.25 to 10.50
  (TDTRACE-MKLINE (list 10.25 26.2656 0.0) (list 10.50 27.5625 0.0) "LA-TD-CURVES")
  ;; t = 10.50 to 10.75
  (TDTRACE-MKLINE (list 10.50 27.5625 0.0) (list 10.75 28.8906 0.0) "LA-TD-CURVES")
  ;; t = 10.75 to 11.00
  (TDTRACE-MKLINE (list 10.75 28.8906 0.0) (list 11.00 30.2500 0.0) "LA-TD-CURVES")
  ;; t = 11.00 to 11.25
  (TDTRACE-MKLINE (list 11.00 30.2500 0.0) (list 11.25 31.6406 0.0) "LA-TD-CURVES")
  ;; t = 11.25 to 11.50
  (TDTRACE-MKLINE (list 11.25 31.6406 0.0) (list 11.50 33.0625 0.0) "LA-TD-CURVES")
  ;; t = 11.50 to 11.75
  (TDTRACE-MKLINE (list 11.50 33.0625 0.0) (list 11.75 34.5156 0.0) "LA-TD-CURVES")
  ;; t = 11.75 to 12.00
  (TDTRACE-MKLINE (list 11.75 34.5156 0.0) (list 12.00 36.0000 0.0) "LA-TD-CURVES")
)

(defun TDTRACE-PLOT-POINT (tr det / dx)
  (setq dx 0.1)
  (TDTRACE-MKLINE (list (- tr dx) det 0.0) (list (+ tr dx) det 0.0) "TD-POINT")
  (TDTRACE-MKLINE (list tr (- det dx) 0.0) (list tr (+ det dx) 0.0) "TD-POINT")
)

(defun TDTRACE-CLASSIFY (tr det disc)
  (cond
    ((< det 0.0) "Saddle (det < 0)")
    ((= det 0.0) "Degenerate (det = 0)")
    ((< disc 0.0)
     (cond
       ((= tr 0.0) "Center (disc < 0, tr = 0)")
       ((> tr 0.0) "Unstable Spiral (disc < 0, tr > 0)")
       (T          "Stable Spiral (disc < 0, tr < 0)")
     )
    )
    ((> disc 0.0)
     (if (> tr 0.0)
       "Unstable Node (disc > 0, tr > 0)"
       "Stable Node (disc > 0, tr < 0)"
     )
    )
    (T "Unknown")
  )
)

(defun TDTRACE-LABEL (tr det class / h dy p)
  (setq h 0.25)
  (setq dy (* 1.5 h))

  (setq p (list 0.5 0.5 0.0))
  (TDTRACE-MKTEXT p h 0.0 "Trace�Determinant Plane" "TD-LABEL")

  (setq p (list 0.5 (+ 0.5 dy) 0.0))
  (TDTRACE-MKTEXT p h 0.0 (strcat "tr(A) = " (rtos tr 2 4)) "TD-LABEL")

  (setq p (list 0.5 (+ 0.5 (* 2 dy)) 0.0))
  (TDTRACE-MKTEXT p h 0.0 (strcat "det(A) = " (rtos det 2 4)) "TD-LABEL")

  (setq p (list 0.5 (+ 0.5 (* 3 dy)) 0.0))
  (TDTRACE-MKTEXT p h 0.0 class "TD-LABEL")
)

;;; ------------------------------------------------------------
;;; PHASE2D-BOTH legacy helpers (RIGHT PANEL)
;;; Reused from original PHASE2D-BOTH_SAFE_REV2
;;; ------------------------------------------------------------

(defun P2B-MKLINE (pt1 pt2 layname)
  (entmake
    (list
      (cons 0 "LINE")
      (cons 8 layname)
      (cons 10 pt1)
      (cons 11 pt2))))

(defun P2B-MKTEXT (pt height rot str layname)
  (entmake
    (list
      (cons 0 "TEXT")
      (cons 8 layname)
      (cons 10 pt)
      (cons 40 height)
      (cons 50 rot)
      (cons 1 str))))

(defun P2B-LEN2 (vec)
  (+ (* (car vec) (car vec))
     (* (cadr vec) (cadr vec))))

(defun P2B-NORM (vec / len2 scale_factor)
  (setq len2 (P2B-LEN2 vec))
  (if (= len2 0.0)
    vec
    (progn
      (setq scale_factor (/ 1.0 (sqrt len2)))
      (list (* scale_factor (car vec))
            (* scale_factor (cadr vec))))))

(defun P2B-SCALE (scalar vec)
  (list (* scalar (car vec))
        (* scalar (cadr vec))))

(defun P2B-DRAW-PHASE (type ev1 ev2 tr det x_offset /)
  (P2B-DRAW-PHASE-AXES x_offset)
  (P2B-DRAW-PHASE-EIG type ev1 ev2 x_offset)
  (P2B-DRAW-PHASE-TRAJ type x_offset)
  (P2B-DRAW-PHASE-LABELS tr det type x_offset))

(defun P2B-DRAW-PHASE-AXES (x_offset / L)
  (setq L 4.0)
  (P2B-MKLINE (list (+ x_offset (- L)) 0 0)
              (list (+ x_offset L) 0 0)
              "PH2-AXES")
  (P2B-MKLINE (list x_offset (- L) 0)
              (list x_offset L 0)
              "PH2-AXES")
  (P2B-MKTEXT (list (+ x_offset 4.2) 0.1 0) 0.25 0 "x" "PH2-AXES")
  (P2B-MKTEXT (list (+ x_offset 0.1) 4.2 0) 0.25 0 "y" "PH2-AXES"))

(defun P2B-DRAW-PHASE-EIG (type ev1 ev2 x_offset / scale_len p1 p2)
  (setq scale_len 3.5)
  (if (or (equal type "UNODE")
          (equal type "SNODE")
          (equal type "SADDLE")
          (equal type "DEGEN"))
    (progn
      ;; First eigenvector
      (if ev1
        (progn
          (setq p1 (P2B-SCALE (- scale_len) ev1))
          (setq p2 (P2B-SCALE scale_len ev1))
          (P2B-MKLINE
            (list (+ x_offset (car p1)) (cadr p1) 0)
            (list (+ x_offset (car p2)) (cadr p2) 0)
            "PH2-EIG")
          ;; Tail dot for eigenvector 1
          (P2B-DRAW-TAIL-DOT
            (list (+ x_offset (car p2)) (cadr p2) 0)
            "PH2-EIG")
        )
      )

      ;; Second eigenvector
      (if ev2
        (progn
          (setq p1 (P2B-SCALE (- scale_len) ev2))
          (setq p2 (P2B-SCALE scale_len ev2))
          (P2B-MKLINE
            (list (+ x_offset (car p1)) (cadr p1) 0)
            (list (+ x_offset (car p2)) (cadr p2) 0)
            "PH2-EIG")
          ;; Tail dot for eigenvector 2
          (P2B-DRAW-TAIL-DOT
            (list (+ x_offset (car p2)) (cadr p2) 0)
            "PH2-EIG")
        )
      )

      (P2B-MKTEXT (list (+ x_offset 2.5) 2.5 0)
                  0.25 0 "Eigen-directions" "PH2-EIG")
    )
  )
)

;; ------------------------------------------------------------
;; Tail dot helper for trajectories
;; ------------------------------------------------------------
(defun P2B-DRAW-TAIL-DOT (pt layer / radius)
  (setq radius 0.08) ;; small, consistent size
  (entmakex
    (list
      '(0 . "CIRCLE")
      (cons 8 layer)
      (cons 10 pt)
      (cons 40 radius)
    )
  )
)



(defun P2B-DRAW-PHASE-TRAJ (type x_offset)

  (cond

    ;; Saddle
((equal type "SADDLE")

  ;; Arm 1 (upper right)
  (P2B-MKLINE (list (+ x_offset 0.5) 0.5 0)
              (list (+ x_offset 1.5) 1.0 0) "PH2-TRAJ")
  (P2B-DRAW-TAIL-DOT (list (+ x_offset 0.5) 0.5 0) "PH2-TRAJ")
  (P2B-MKLINE (list (+ x_offset 1.5) 1.0 0)
              (list (+ x_offset 3.0) 1.2 0) "PH2-TRAJ")

  ;; Arm 2 (lower left)
  (P2B-MKLINE (list (+ x_offset -0.5) -0.5 0)
              (list (+ x_offset -1.5) -1.0 0) "PH2-TRAJ")
  (P2B-DRAW-TAIL-DOT (list (+ x_offset -0.5) -0.5 0) "PH2-TRAJ")
  (P2B-MKLINE (list (+ x_offset -1.5) -1.0 0)
              (list (+ x_offset -3.0) -1.2 0) "PH2-TRAJ")

  ;; Arm 3 (lower right)
  (P2B-MKLINE (list (+ x_offset 0.5) -0.5 0)
              (list (+ x_offset 1.5) -1.0 0) "PH2-TRAJ")
  (P2B-DRAW-TAIL-DOT (list (+ x_offset 0.5) -0.5 0) "PH2-TRAJ")
  (P2B-MKLINE (list (+ x_offset 1.5) -1.0 0)
              (list (+ x_offset 3.0) -1.2 0) "PH2-TRAJ")

  ;; Arm 4 (upper left)
  (P2B-MKLINE (list (+ x_offset -0.5) 0.5 0)
              (list (+ x_offset -1.5) 1.0 0) "PH2-TRAJ")
  (P2B-DRAW-TAIL-DOT (list (+ x_offset -0.5) 0.5 0) "PH2-TRAJ")
  (P2B-MKLINE (list (+ x_offset -1.5) 1.0 0)
              (list (+ x_offset -3.0) 1.2 0) "PH2-TRAJ")
)


    ;; Stable node
    ((equal type "SNODE")
     (P2B-MKLINE (list (+ x_offset 3.0) 1.0 0)
                 (list (+ x_offset 1.5) 0.5 0) "PH2-TRAJ")
     (P2B-DRAW-TAIL-DOT (list (+ x_offset 3.0) 1.0 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 1.5) 0.5 0)
                 (list (+ x_offset 0.5) 0.2 0) "PH2-TRAJ")

     (P2B-MKLINE (list (+ x_offset 3.0) -1.0 0)
                 (list (+ x_offset 1.5) -0.5 0) "PH2-TRAJ")
     (P2B-DRAW-TAIL-DOT (list (+ x_offset 3.0) -1.0 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 1.5) -0.5 0)
                 (list (+ x_offset 0.5) -0.2 0) "PH2-TRAJ"))

    ;; Unstable node
    ((equal type "UNODE")
     (P2B-MKLINE (list (+ x_offset 0.5) 0.2 0)
                 (list (+ x_offset 1.5) 0.5 0) "PH2-TRAJ")
     (P2B-DRAW-TAIL-DOT (list (+ x_offset 0.5) 0.2 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 1.5) 0.5 0)
                 (list (+ x_offset 3.0) 1.0 0) "PH2-TRAJ")

     (P2B-MKLINE (list (+ x_offset 0.5) -0.2 0)
                 (list (+ x_offset 1.5) -0.5 0) "PH2-TRAJ")
     (P2B-DRAW-TAIL-DOT (list (+ x_offset 0.5) -0.2 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 1.5) -0.5 0)
                 (list (+ x_offset 3.0) -1.0 0) "PH2-TRAJ"))

    ;; Stable spiral
    ((equal type "SSPIRAL")
     (P2B-MKLINE (list (+ x_offset 3.0) 0.0 0)
                 (list (+ x_offset 2.0) 1.0 0) "PH2-TRAJ")
     (P2B-DRAW-TAIL-DOT (list (+ x_offset 3.0) 0.0 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 2.0) 1.0 0)
                 (list (+ x_offset 0.8) 0.6 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 0.8) 0.6 0)
                 (list (+ x_offset 0.2) 0.2 0) "PH2-TRAJ"))

    ;; Unstable spiral
    ((equal type "USPIRAL")
     (P2B-MKLINE (list (+ x_offset 0.2) 0.2 0)
                 (list (+ x_offset 0.8) 0.6 0) "PH2-TRAJ")
     (P2B-DRAW-TAIL-DOT (list (+ x_offset 0.2) 0.2 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 0.8) 0.6 0)
                 (list (+ x_offset 2.0) 1.0 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 2.0) 1.0 0)
                 (list (+ x_offset 3.0) 0.0 0) "PH2-TRAJ"))

    ;; Center
    ((equal type "CENTER")
     (P2B-MKLINE (list (+ x_offset 2.0) 0.0 0)
                 (list (+ x_offset 1.4) 1.4 0) "PH2-TRAJ")
     (P2B-DRAW-TAIL-DOT (list (+ x_offset 2.0) 0.0 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 1.4) 1.4 0)
                 (list (+ x_offset 0.0) 2.0 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 0.0) 2.0 0)
                 (list (+ x_offset -1.4) 1.4 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset -1.4) 1.4 0)
                 (list (+ x_offset -2.0) 0.0 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset -2.0) 0.0 0)
                 (list (+ x_offset -1.4) -1.4 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset -1.4) -1.4 0)
                 (list (+ x_offset 0.0) -2.0 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 0.0) -2.0 0)
                 (list (+ x_offset 1.4) -1.4 0) "PH2-TRAJ")
     (P2B-MKLINE (list (+ x_offset 1.4) -1.4 0)
                 (list (+ x_offset 2.0) 0.0 0) "PH2-TRAJ"))))

(defun P2B-DRAW-PHASE-LABELS (tr det type x_offset / txt_height txt_pt)
  (setq txt_height 0.25)
  (setq txt_pt (list (+ x_offset -3.5) 3.5 0))
  (P2B-MKTEXT txt_pt txt_height 0 type "PH2-LABEL")
  (setq txt_pt (list (+ x_offset -3.5) 3.9 0))
  (P2B-MKTEXT txt_pt txt_height 0
              (strcat "trace = " (rtos tr 2 3)) "PH2-LABEL")
  (setq txt_pt (list (+ x_offset -3.5) 4.3 0))
  (P2B-MKTEXT txt_pt txt_height 0
              (strcat "det = " (rtos det 2 3)) "PH2-LABEL"))

;;; ------------------------------------------------------------
;;; MAIN COMMAND: PHASE2D-BOTH_SAFE_REV2
;;; ------------------------------------------------------------

(defun C:PHASE2D-BOTH_SAFE_REV2
  ( / a11 a12 a21 a22 tr det disc lam1 lam2 cls type
       ev1 ev2 x_offset td_class)

  (prompt "\nPHASE2D-BOTH_SAFE_REV2 � TD plane + phase portrait for x' = A x")

  ;; Matrix input
  (prompt "\nEnter matrix A = [[a11 a12] [a21 a22]]")
  (setq a11 (getreal "\nEnter a11: "))
  (setq a12 (getreal "\nEnter a12: "))
  (setq a21 (getreal "\nEnter a21: "))
  (setq a22 (getreal "\nEnter a22: "))

  ;; Invariants
  (setq tr  (+ a11 a22))
  (setq det (- (* a11 a22) (* a12 a21)))
  (setq disc (- (* tr tr) (* 4.0 det)))

  ;; TDTRACE-style classification string (for left labels)
  (setq td_class (TDTRACE-CLASSIFY tr det disc))

  ;; Phase-type classification (for right panel)
  (cond
    ((and (> disc 0.0) (> det 0.0) (> tr 0.0))
     (setq cls "Unstable node")
     (setq type "UNODE"))
    ((and (> disc 0.0) (> det 0.0) (< tr 0.0))
     (setq cls "Stable node")
     (setq type "SNODE"))
    ((and (> disc 0.0) (< det 0.0))
     (setq cls "Saddle")
     (setq type "SADDLE"))
    ((and (< disc 0.0) (> det 0.0) (> tr 0.0))
     (setq cls "Unstable spiral")
     (setq type "USPIRAL"))
    ((and (< disc 0.0) (> det 0.0) (< tr 0.0))
     (setq cls "Stable spiral")
     (setq type "SSPIRAL"))
    ((and (< disc 0.0) (> det 0.0) (= tr 0.0))
     (setq cls "Center")
     (setq type "CENTER"))
    ((and (= disc 0.0) (> det 0.0))
  (setq cls "Degenerate case")
  (setq type "DEGEN"))

    (t
     (setq cls "Unclassified")
     (setq type "OTHER"))
  )

  ;; Eigenvalues (real cases)
  (if (>= disc 0.0)
    (progn
      (setq lam1 (/ (+ tr (sqrt disc)) 2.0))
      (setq lam2 (/ (- tr (sqrt disc)) 2.0))))

  ;; Eigenvectors (real cases, with diagonal fallback)
  (if (>= disc 0.0)
    (progn
      (if (and (= a12 0.0) (= a21 0.0))
        (progn
          (setq ev1 (list 1.0 0.0))
          (setq ev2 (list 0.0 1.0)))
        (progn
          ;; ev1
          (if (/= a12 0.0)
            (setq ev1 (P2B-NORM (list 1.0 (/ (- lam1 a11) a12))))
            (setq ev1 (P2B-NORM (list (/ (- lam1 a22) a21) 1.0))))
          ;; ev2
          (if (/= a12 0.0)
            (setq ev2 (P2B-NORM (list 1.0 (/ (- lam2 a11) a12))))
            (setq ev2 (P2B-NORM (list (/ (- lam2 a22) a21) 1.0))))))))

  ;; LEFT PANEL: TD plane using TDTRACE_SAFE_B geometry
  (prompt "\n[PHASE2D-BOTH] Drawing trace�determinant plane...")
  (TDTRACE-DRAW-AXES)
  (TDTRACE-DRAW-CURVE-HARDCODED)
  (TDTRACE-PLOT-POINT tr det)
  (TDTRACE-LABEL tr det td_class)

  ;; RIGHT PANEL: phase portrait (offset)
(prompt "\n[PHASE2D-BOTH] Drawing phase portrait...")

;; Save user�s original point display settings
(setq oldPDMODE (getvar "PDMODE"))
(setq oldPDSIZE (getvar "PDSIZE"))

;; Set point style to small circles for tail dots
(setvar "PDMODE" 2)     ;; 2 = circle
(setvar "PDSIZE" 0.1)   ;; small, consistent size

;; Force AutoCAD to update the point display
(command "_.REGEN")

(setq x_offset 14.0)

;; Draw the phase portrait
(P2B-DRAW-PHASE type ev1 ev2 tr det x_offset)

;; Restore user�s original settings
(setvar "PDMODE" oldPDMODE)
(setvar "PDSIZE" oldPDSIZE)
(command "_.REGEN")


  (prompt "\n[PHASE2D-BOTH] Done.")
  (princ)
)

;=====================================================================
;  END OF FILE: PHASE2D-BOTH_SAFE_REV2.lsp
;  Part of the cadcando Visual Linear Algebra System (VLAS).
;=====================================================================

(princ "\nPHASE2D-BOTH_SAFE_REV2 loaded. Command: PHASE2D-BOTH_SAFE_REV2")
(princ)
