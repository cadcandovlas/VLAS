;=====================================================================
;  FILE: VP-PROJ-MATRIX-VIS_Rev1.lsp
;  TOOL: VPMV - Visual Projection Matrix onto span{x}
;  SUITE: cadcando Visual Linear Algebra System (VLAS)
;=====================================================================
;  DESCRIPTION:
;    Visualizes the action of the orthogonal projection matrix P onto
;    span{x} by:
;      - drawing x
;      - drawing a test vector v
;      - drawing proj_x(v) = P v
;      - drawing the perpendicular component v - proj_x(v)
;    Uses LA_LABEL_ENGINE_Rev1x for labeling.
;
;  ARCHITECTURE (SAFE-REV):
;    - NO layers are created here (Launcher owns all layers).
;    - Uses layers:
;        LA-VPM-AXIS
;        LA-VPM-VECTOR
;        LA-VPM-MATRIX   (reserved for future text use)
;=====================================================================

(defun C:VPMV ( / x1 x2 x3
                  v1 v2 v3
                  denom
                  p11 p12 p13
                  p21 p22 p23
                  p31 p32 p33
                  pv1 pv2 pv3
                  w1 w2 w3
                  idx-x idx-v idx-p idx-w
                  x-tip v-tip pv-tip w-tip
                )

  (princ "\nLinear Algebra Tool: Visual Projection Matrix onto span{x}")
  (princ "\nVP-PROJ-MATRIX-VIS_Rev1 - Visualizing P v = proj_x(v)")

  ;; ------------------------------------------------------------
  ;; Input: x (nonzero)
  ;; ------------------------------------------------------------
  (princ "\nEnter direction vector x (nonzero):")
  (setq x1 (getreal "\n  x_x: "))
  (setq x2 (getreal "\n  x_y: "))
  (setq x3 (getreal "\n  x_z: "))

  (setq denom (+ (* x1 x1) (* x2 x2) (* x3 x3)))
  (if (<= denom 1e-12)
    (progn
      (princ "\nERROR: x must be nonzero. Projection matrix is undefined.")
      (princ)
      (exit)
    )
  )

  ;; ------------------------------------------------------------
  ;; Input: test vector v
  ;; ------------------------------------------------------------
  (princ "\nEnter test vector v (to be projected onto span{x}):")
  (setq v1 (getreal "\n  v_x: "))
  (setq v2 (getreal "\n  v_y: "))
  (setq v3 (getreal "\n  v_z: "))

  ;; ------------------------------------------------------------
  ;; Compute P = (x x^T) / (x^T x)
  ;; ------------------------------------------------------------
  (setq p11 (/ (* x1 x1) denom))
  (setq p12 (/ (* x1 x2) denom))
  (setq p13 (/ (* x1 x3) denom))

  (setq p21 (/ (* x2 x1) denom))
  (setq p22 (/ (* x2 x2) denom))
  (setq p23 (/ (* x2 x3) denom))

  (setq p31 (/ (* x3 x1) denom))
  (setq p32 (/ (* x3 x2) denom))
  (setq p33 (/ (* x3 x3) denom))

  ;; ------------------------------------------------------------
  ;; Compute proj_x(v) = P v and w = v - proj_x(v)
  ;; ------------------------------------------------------------
  (setq pv1 (+ (* p11 v1) (* p12 v2) (* p13 v3)))
  (setq pv2 (+ (* p21 v1) (* p22 v2) (* p23 v3)))
  (setq pv3 (+ (* p31 v1) (* p32 v2) (* p33 v3)))

  (setq w1 (- v1 pv1))
  (setq w2 (- v2 pv2))
  (setq w3 (- v3 pv3))

  ;; ------------------------------------------------------------
  ;; Lane indices for Label Engine
  ;; ------------------------------------------------------------
  (setq idx-x 1)  ;; x
  (setq idx-v 2)  ;; v
  (setq idx-p 3)  ;; proj_x(v)
  (setq idx-w 4)  ;; v - proj_x(v)

  ;; ------------------------------------------------------------
  ;; Draw axes (optional, simple XYZ frame)
  ;; ------------------------------------------------------------
  (setvar "CLAYER" "LA-VPM-AXIS")
  (command "._3DPOLY" "0,0,0" "1,0,0" "")
  (command "._3DPOLY" "0,0,0" "0,1,0" "")
  (command "._3DPOLY" "0,0,0" "0,0,1" "")

  ;; ------------------------------------------------------------
  ;; Draw x, v, proj_x(v), and w with distinct layers
  ;; ------------------------------------------------------------

  ;; x
  (setvar "CLAYER" "LA-VPM-X")
  (command "._3DPOLY"
           "0,0,0"
           (strcat (rtos x1 2 6) ","
                   (rtos x2 2 6) ","
                   (rtos x3 2 6))
           "")

  ;; v
  (setvar "CLAYER" "LA-VPM-V")
  (command "._3DPOLY"
           "0,0,0"
           (strcat (rtos v1 2 6) ","
                   (rtos v2 2 6) ","
                   (rtos v3 2 6))
           "")

  ;; proj_x(v)
  (setvar "CLAYER" "LA-VPM-PROJ")
  (command "._3DPOLY"
           "0,0,0"
           (strcat (rtos pv1 2 6) ","
                   (rtos pv2 2 6) ","
                   (rtos pv3 2 6))
           "")

  ;; w = v - proj_x(v)
  (setvar "CLAYER" "LA-VPM-PERP")
  (command "._3DPOLY"
           (strcat (rtos pv1 2 6) ","
                   (rtos pv2 2 6) ","
                   (rtos pv3 2 6))
           (strcat (rtos v1 2 6) ","
                   (rtos v2 2 6) ","
                   (rtos v3 2 6))
           "")

  ;; ------------------------------------------------------------
  ;; Adaptive Z-lift for clustered vectors (Test 5 fix)
  ;; ------------------------------------------------------------
  (defun cluster-lift (pt idx / x y z base clustered lift)
    (setq x (car pt))
    (setq y (cadr pt))
    (setq z (caddr pt))

    ;; base lift per lane (0.10, 0.20, 0.30, 0.40)
    (setq base (* idx 0.10))

    ;; detect XY clustering (tight region around origin)
    (setq clustered
          (and (< (abs x) 0.25)
               (< (abs y) 0.25)))

    ;; if clustered, double the lift
    (setq lift (if clustered (* base 2.0) base))

    (list x y (+ z lift))
  )

  ;; ------------------------------------------------------------
  ;; Labels via Label Engine (with adaptive Z-lift)
  ;; ------------------------------------------------------------

  (setq x-tip  (cluster-lift (list x1  x2  x3) idx-x))
  (setq v-tip  (cluster-lift (list v1  v2  v3) idx-v))
  (setq pv-tip (cluster-lift (list pv1 pv2 pv3) idx-p))
  (setq w-tip  (cluster-lift (list v1  v2  v3) idx-w)) ;; w tip at v

  ;; x
  (LA:LABEL-VECTOR x-tip  x1  x2  x3  idx-x)

  ;; v
  (LA:LABEL-VECTOR v-tip  v1  v2  v3  idx-v)

  ;; proj_x(v)
  (LA:LABEL-VECTOR pv-tip pv1 pv2 pv3 idx-p)

  ;; w = v - proj_x(v)
  (LA:LABEL-VECTOR w-tip  w1  w2  w3  idx-w)

  ;; ------------------------------------------------------------
  ;; Brief textual summary
  ;; ------------------------------------------------------------
  (princ "\n\nSummary:")
  (princ (strcat
           "\n  x          = ("
           (rtos x1 2 4) ", "
           (rtos x2 2 4) ", "
           (rtos x3 2 4) ")"))
  (princ (strcat
           "\n  v          = ("
           (rtos v1 2 4) ", "
           (rtos v2 2 4) ", "
           (rtos v3 2 4) ")"))
  (princ (strcat
           "\n  proj_x(v)  = ("
           (rtos pv1 2 4) ", "
           (rtos pv2 2 4) ", "
           (rtos pv3 2 4) ")"))
  (princ (strcat
           "\n  v - proj_x(v) = ("
           (rtos w1 2 4) ", "
           (rtos w2 2 4) ", "
           (rtos w3 2 4) ")"))

  (princ "\n\nGeometric picture: v is decomposed into a component along x and a perpendicular component.")

  ;; Zoom
  (command "_.ZOOM" "E")
  
  (princ)
)

;=====================================================================
;  END OF FILE: VP-PROJ-MATRIX-VIS_Rev1.lsp
;=====================================================================

