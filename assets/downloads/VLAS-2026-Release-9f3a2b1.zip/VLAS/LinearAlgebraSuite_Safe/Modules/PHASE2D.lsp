;;; ============================================================
;;; PHASE2D � Qualitative Phase Portrait for x' = A x (2�2)
;;; LinearAlgebraSuite Module � Rev2 (2026)
;;;
;;; � 2026 Christopher A. LaFollette. All rights reserved.
;;;
;;; Command: PHASE2D
;;; Menu/Call: P2  (via TL:P2 ? (load "PHASE2D") (C:PHASE2DLAUNCH))
;;; ============================================================


;;; ------------------------------------------------------------
;;; SAFE-REV2 STYLE LAYER ENGINE (LOCAL STUB)
;;; ------------------------------------------------------------

(defun LA-PH2-SAFE-MAKE-LAYER (name color / rec)
  (setq rec (tblsearch "LAYER" name))
  (if rec
    (progn
      (entmod (subst (cons 62 color) (assoc 62 rec) rec))
      (command "._LAYER" "_ON" name "" "._LAYER" "_THAW" name "" "._LAYER" "_UNLOCK" name ""))
    (entmake
      (list
        (cons 0 "LAYER")
        (cons 2 name)
        (cons 70 0)
        (cons 62 color)))))

(defun LA-PH2-INIT-LAYERS ( / )
  ;; Classic PH2 layer names, SAFE-REV2 behavior
  (LA-PH2-SAFE-MAKE-LAYER "PH2-AXIS" 8)   ;; gray axes
  (LA-PH2-SAFE-MAKE-LAYER "PH2-EIG"  1)   ;; red eigenvectors
  (LA-PH2-SAFE-MAKE-LAYER "PH2-TRAJ" 5)   ;; blue trajectories
  (LA-PH2-SAFE-MAKE-LAYER "PH2-LBL"  7))  ;; white labels


;;; ------------------------------------------------------------
;;; BASIC DRAW PRIMITIVES
;;; ------------------------------------------------------------

(defun LA-PH2-MKLINE (p1 p2 layer)
  (entmake
    (list (cons 0 "LINE")
          (cons 8 layer)
          (cons 10 p1)
          (cons 11 p2))))

(defun LA-PH2-MKTEXT (pt h rot str layer)
  (entmake
    (list (cons 0 "TEXT")
          (cons 8 layer)
          (cons 10 pt)
          (cons 40 h)
          (cons 50 rot)
          (cons 1 str))))

(defun LA-PH2-DRAW-TAIL-DOT (pt layer / radius)
  (setq radius 0.08)
  (entmakex
    (list
      '(0 . "CIRCLE")
      (cons 8 layer)
      (cons 10 pt)
      (cons 40 radius))))


;;; ------------------------------------------------------------
;;; VECTOR HELPERS
;;; ------------------------------------------------------------

(defun LA-PH2-LEN2 (v)
  (+ (* (car v) (car v)) (* (cadr v) (cadr v))))

(defun LA-PH2-NORM (v / len2 k)
  (setq len2 (LA-PH2-LEN2 v))
  (if (= len2 0.0)
    v
    (progn
      (setq k (/ 1.0 (sqrt len2)))
      (list (* k (car v)) (* k (cadr v))))))

(defun LA-PH2-SCALE (s v)
  (list (* s (car v)) (* s (cadr v))))

(defun LA-PH2-ADD (v w)
  (list (+ (car v) (car w)) (+ (cadr v) (cadr w))))


;;; ------------------------------------------------------------
;;; AXES
;;; ------------------------------------------------------------

(defun LA-PH2-DRAW-AXES ( / L)
  (setq L 4.0)
  (LA-PH2-MKLINE (list (- L) 0 0) (list L 0 0) "PH2-AXIS")
  (LA-PH2-MKLINE (list 0 (- L) 0) (list 0 L 0) "PH2-AXIS")
  (LA-PH2-MKTEXT (list 4.2 0.1 0) 0.25 0 "x" "PH2-AXIS")
  (LA-PH2-MKTEXT (list 0.1 4.2 0) 0.25 0 "y" "PH2-AXIS"))


;;; ------------------------------------------------------------
;;; EIGENVECTORS
;;; ------------------------------------------------------------

(defun LA-PH2-DRAW-EIGENVECTORS (type ev1 ev2 / s p1 p2)
  (setq s 3.5)
  (if (or (equal type "UNODE") (equal type "SNODE")
          (equal type "SADDLE") (equal type "DEGEN"))
    (progn
      ;; First eigenvector
      (if ev1
        (progn
          (setq p1 (LA-PH2-SCALE (- s) ev1))
          (setq p2 (LA-PH2-SCALE s ev1))
          (LA-PH2-MKLINE
            (list (car p1) (cadr p1) 0)
            (list (car p2) (cadr p2) 0)
            "PH2-EIG")
          (LA-PH2-DRAW-TAIL-DOT
            (list (car p2) (cadr p2) 0)
            "PH2-EIG")))
      ;; Second eigenvector
      (if ev2
        (progn
          (setq p1 (LA-PH2-SCALE (- s) ev2))
          (setq p2 (LA-PH2-SCALE s ev2))
          (LA-PH2-MKLINE
            (list (car p1) (cadr p1) 0)
            (list (car p2) (cadr p2) 0)
            "PH2-EIG")
          (LA-PH2-DRAW-TAIL-DOT
            (list (car p2) (cadr p2) 0)
            "PH2-EIG")))
      (LA-PH2-MKTEXT '(2.5 2.5 0) 0.25 0 "Eigen-directions" "PH2-EIG"))))


;;; ------------------------------------------------------------
;;; TRAJECTORIES (ASCII TEMPLATES + TAIL DOTS)
;;; ------------------------------------------------------------

(defun LA-PH2-DRAW-TRAJ (type)

  (cond

    ;; Saddle
    ((equal type "SADDLE")
     (LA-PH2-DRAW-TAIL-DOT '(0.5 0.5 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(0.5 0.5 0) '(1.5 1.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(1.5 1.0 0) '(3.0 1.2 0) "PH2-TRAJ")
     (LA-PH2-DRAW-TAIL-DOT '(-0.5 -0.5 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(-0.5 -0.5 0) '(-1.5 -1.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(-1.5 -1.0 0) '(-3.0 -1.2 0) "PH2-TRAJ")
     (LA-PH2-DRAW-TAIL-DOT '(0.5 -0.5 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(0.5 -0.5 0) '(1.5 -1.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(1.5 -1.0 0) '(3.0 -1.2 0) "PH2-TRAJ")
     (LA-PH2-DRAW-TAIL-DOT '(-0.5 0.5 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(-0.5 0.5 0) '(-1.5 1.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(-1.5 1.0 0) '(-3.0 1.2 0) "PH2-TRAJ"))

    ;; Stable node
    ((equal type "SNODE")
     (LA-PH2-DRAW-TAIL-DOT '(3.0 1.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(3.0 1.0 0) '(1.5 0.5 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(1.5 0.5 0) '(0.5 0.2 0) "PH2-TRAJ")
     (LA-PH2-DRAW-TAIL-DOT '(3.0 -1.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(3.0 -1.0 0) '(1.5 -0.5 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(1.5 -0.5 0) '(0.5 -0.2 0) "PH2-TRAJ"))

    ;; Unstable node
    ((equal type "UNODE")
     (LA-PH2-DRAW-TAIL-DOT '(0.5 0.2 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(0.5 0.2 0) '(1.5 0.5 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(1.5 0.5 0) '(3.0 1.0 0) "PH2-TRAJ")
     (LA-PH2-DRAW-TAIL-DOT '(0.5 -0.2 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(0.5 -0.2 0) '(1.5 -0.5 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(1.5 -0.5 0) '(3.0 -1.0 0) "PH2-TRAJ"))

    ;; Stable spiral
    ((equal type "SSPIRAL")
     (LA-PH2-DRAW-TAIL-DOT '(3.0 0.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(3.0 0.0 0) '(2.0 1.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(2.0 1.0 0) '(0.8 0.6 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(0.8 0.6 0) '(0.2 0.2 0) "PH2-TRAJ"))

    ;; Unstable spiral
    ((equal type "USPIRAL")
     (LA-PH2-DRAW-TAIL-DOT '(0.2 0.2 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(0.2 0.2 0) '(0.8 0.6 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(0.8 0.6 0) '(2.0 1.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(2.0 1.0 0) '(3.0 0.0 0) "PH2-TRAJ"))

    ;; Center
    ((equal type "CENTER")
     (LA-PH2-DRAW-TAIL-DOT '(2.0 0.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(2.0 0.0 0) '(1.4 1.4 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(1.4 1.4 0) '(0.0 2.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(0.0 2.0 0) '(-1.4 1.4 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(-1.4 1.4 0) '(-2.0 0.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(-2.0 0.0 0) '(-1.4 -1.4 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(-1.4 -1.4 0) '(0.0 -2.0 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(0.0 -2.0 0) '(1.4 -1.4 0) "PH2-TRAJ")
     (LA-PH2-MKLINE '(1.4 -1.4 0) '(2.0 0.0 0) "PH2-TRAJ"))))


;;; ------------------------------------------------------------
;;; LABELS
;;; ------------------------------------------------------------

(defun LA-PH2-DRAW-LABELS (tr det cls / h p)
  (setq h 0.25)
  (setq p '(0.5 3.5 0))
  (LA-PH2-MKTEXT p h 0 cls "PH2-LBL")
  (setq p '(0.5 3.9 0))
  (LA-PH2-MKTEXT p h 0 (strcat "trace = " (rtos tr 2 3)) "PH2-LBL")
  (setq p '(0.5 4.3 0))
  (LA-PH2-MKTEXT p h 0 (strcat "det = " (rtos det 2 3)) "PH2-LBL"))


;;; ------------------------------------------------------------
;;; CORE ENGINE (classification + eigenvalues/eigenvectors)
;;; ------------------------------------------------------------

(defun LA-PH2-ENGINE (a11 a12 a21 a22 / tr det disc lam1 lam2 cls type ev1 ev2)

  (setq tr (+ a11 a22))
  (setq det (- (* a11 a22) (* a12 a21)))
  (setq disc (- (* tr tr) (* 4.0 det)))

  ;; classification
  (cond
    ((and (> disc 0.0) (> det 0.0) (> tr 0.0))
     (setq cls "Unstable node")
     (setq type "UNODE"))
    ((and (> disc 0.0) (> det 0.0) (< tr 0.0))
     (setq cls "Stable node")
     (setq type "SNODE"))
    ((and (> disc 0.0) (< det 0.0))
     (setq cls "Saddle")
     (setq type "SADDLE"))
    ((and (< disc 0.0) (> det 0.0) (> tr 0.0))
     (setq cls "Unstable spiral")
     (setq type "USPIRAL"))
    ((and (< disc 0.0) (> det 0.0) (< tr 0.0))
     (setq cls "Stable spiral")
     (setq type "SSPIRAL"))
    ((and (< disc 0.0) (> det 0.0) (= tr 0.0))
     (setq cls "Center")
     (setq type "CENTER"))
  ((and (= disc 0.0) (> det 0.0))
  (setq cls "Degenerate case")
  (setq type "DEGEN"))
(t
  (setq cls "Unclassified")
  (setq type "OTHER"))
)


  ;; eigenvalues (real cases)
  (if (>= disc 0.0)
    (progn
      (setq lam1 (/ (+ tr (sqrt disc)) 2.0))
      (setq lam2 (/ (- tr (sqrt disc)) 2.0))))

  ;; eigenvectors (real cases)
  (if (>= disc 0.0)
    (progn
      ;; diagonal matrix fallback (prevents divide-by-zero)
      (if (and (= a12 0.0) (= a21 0.0))
        (progn
          (setq ev1 (list 1.0 0.0))
          (setq ev2 (list 0.0 1.0)))
        (progn
          ;; ev1
          (if (/= a12 0.0)
            (setq ev1 (LA-PH2-NORM (list 1.0 (/ (- lam1 a11) a12))))
            (setq ev1 (LA-PH2-NORM (list (/ (- lam1 a22) a21) 1.0))))
          ;; ev2
          (if (/= a12 0.0)
            (setq ev2 (LA-PH2-NORM (list 1.0 (/ (- lam2 a11) a12))))
            (setq ev2 (LA-PH2-NORM (list (/ (- lam2 a22) a21) 1.0))))))))

  (list tr det cls type ev1 ev2))


;;; ------------------------------------------------------------
;;; MAIN COMMAND (ENGINE + DRAWING)
;;; ------------------------------------------------------------

(defun C:PHASE2D (a11 a12 a21 a22 / tr det cls type ev1 ev2 result)

  (prompt "\nPHASE2D � Qualitative Phase Portrait for x' = A x (2x2)")

  (LA-PH2-INIT-LAYERS)

  (setq result (LA-PH2-ENGINE a11 a12 a21 a22))
  (setq tr   (nth 0 result))
  (setq det  (nth 1 result))
  (setq cls  (nth 2 result))
  (setq type (nth 3 result))
  (setq ev1  (nth 4 result))
  (setq ev2  (nth 5 result))

  (LA-PH2-DRAW-AXES)
  (LA-PH2-DRAW-EIGENVECTORS type ev1 ev2)
  (LA-PH2-DRAW-TRAJ type)
  (LA-PH2-DRAW-LABELS tr det cls)

  (prompt "\n[PHASE2D] Done.")
  (princ))


;;; ============================================================
;;; LAUNCHER ENTRY POINT (reads 2�2 matrix from Launcher)
;;; ============================================================

(defun C:PHASE2DLAUNCH ( / M a11 a12 a21 a22 )
  (setq M (VLAS-get-matrix-2x2))   ;; Launcher�s standard 2�2 input block
  (setq a11 (nth 0 M))
  (setq a12 (nth 1 M))
  (setq a21 (nth 2 M))
  (setq a22 (nth 3 M))
  (C:PHASE2D a11 a12 a21 a22)
)


(defun C:PHASE2D-LAUNCH ( ) (C:PHASE2DLAUNCH))


(princ)
