;=====================================================================
;  cadcando Visual Linear Algebra System (VLAS)
;  VP-ANGLE_Rev2  (PLANNING HEADER ONLY � CODE REMAINS Rev1)
;=====================================================================
;  MODULE NAME:   VP-ANGLE  (Angle Between Two Vectors)
;  FILE NAME:     VP-ANGLE_Rev1.lsp   (FILENAME REMAINS UNCHANGED)
;  REVISION:      Rev2  (TITLE BLOCK ONLY � NO CODE CHANGES)
;  STATUS:        PLANNING / DOCUMENTATION UPDATE
;
;  PURPOSE OF REV2:
;     This revision documents the next set of visual enhancements
;     approved for future implementation.  The working code remains
;     the stable Rev1 version.  No geometry, math, or behavior is
;     altered in this revision.
;
;  APPROVED ENHANCEMENTS FOR FUTURE IMPLEMENTATION:
;
;     1. Smooth Arc Rendering
;        - Replace segmented polyline arc with SPLINE-based arc.
;        - Use 5�7 control points for curvature stability.
;
;     2. Arc Arrowheads
;        - Add directional arrowhead at arc terminus.
;        - Arrowhead size proportional to arc radius.
;
;     3. Gradient Arc Coloring
;        - Acute angle:   Green
;        - Right angle:   Yellow
;        - Obtuse angle:  Orange
;        - Reflex angle:  Red
;        - Layer-based color assignment for suite consistency.
;
;     4. Unified Angle Text Color Matching
;        - Angle text color matches arc color layer.
;        - Uses AutoCAD Unicode escape for theta ( \U+03B8 ).
;
;     5. Visual Fidelity Upgrade
;        - Improve arc curvature appearance at small angles.
;        - Ensure arc reads visually as an arc, not a chord.
;
;  NOTES:
;     - This Rev2 header does NOT modify any Rev1 code.
;     - All functionality remains exactly as in Rev1.
;     - Full implementation of items 1�5 will occur in Rev3.
;     - This header preserves SAFE-REV lineage and documentation.
;
;=====================================================================


;;; ------------------------------------------------------------
;;; Math helpers
;;; ------------------------------------------------------------

(defun VPANG-MIN2 (a b)
  (if (< a b) a b)
)

(defun VPANG-DOT (v u)
  (+ (* (car v)   (car u))
     (* (cadr v)  (cadr u))
     (* (caddr v) (caddr u)))
)

(defun VPANG-MAG (v)
  (sqrt (+ (* (car v)   (car v))
           (* (cadr v)  (cadr v))
           (* (caddr v) (caddr v))))
)

(defun VPANG-NORM (v / m)
  (setq m (VPANG-MAG v))
  (if (<= m 0.0)
    '(0.0 0.0 0.0)
    (list (/ (car v)   m)
          (/ (cadr v)  m)
          (/ (caddr v) m)))
)

(defun VPANG-SCALE (s v)
  (list (* s (car v)) (* s (cadr v)) (* s (caddr v)))
)

(defun VPANG-ADD (v u)
  (list (+ (car v) (car u))
        (+ (cadr v) (cadr u))
        (+ (caddr v) (caddr u)))
)

;;; ------------------------------------------------------------
;;; ACOS (ASCII-safe)
;;; ------------------------------------------------------------

(defun VPANG-ACOS (x / root ratio raw)
  (if (> x 1.0) (setq x 1.0))
  (if (< x -1.0) (setq x -1.0))
  (cond
    ((= x 1.0) 0.0)
    ((= x -1.0) pi)
    ((= x 0.0) (/ pi 2.0))
    (T
      (setq root (sqrt (- 1.0 (* x x))))
      (setq ratio (/ root x))
      (setq raw  (atan ratio))
      (if (< x 0.0)
        (+ raw pi)
        raw
      )
    )
  )
)

;;; ------------------------------------------------------------
;;; Drawing helpers
;;; ------------------------------------------------------------

(defun VPANG-MKLINE (p1 p2 layer)
  (entmake
    (list (cons 0 "LINE")
          (cons 8 layer)
          (cons 10 p1)
          (cons 11 p2)))
)

(defun VPANG-MKTEXT (pt h rot str layer)
  (entmake
    (list (cons 0 "TEXT")
          (cons 8 layer)
          (cons 10 pt)
          (cons 40 h)
          (cons 50 rot)
          (cons 1 str)))
)

;;; ------------------------------------------------------------
;;; Layer creation helper
;;; ------------------------------------------------------------

(defun VPANG-MAKE-LAYER (name color)
  (if (not (tblsearch "LAYER" name))
    (entmake
      (list
        (cons 0 "LAYER")
        (cons 2 name)
        (cons 70 0)
        (cons 62 color)
      )
    )
  )
)

;;; ------------------------------------------------------------
;;; Axes
;;; ------------------------------------------------------------

(defun VPANG-DRAW-AXES ( / L)
  (setq L 3.0)
  (VPANG-MKLINE '(0 0 0) (list L 0 0) "LA-VPA-CONST")
  (VPANG-MKLINE '(0 0 0) (list 0 L 0) "LA-VPA-CONST")
  (VPANG-MKLINE '(0 0 0) (list 0 0 L) "LA-VPA-CONST")
  (VPANG-MKTEXT (list (+ L 0.2) 0 0) 0.25 0 "x" "LA-VPA-LABEL")
  (VPANG-MKTEXT (list 0 (+ L 0.2) 0) 0.25 0 "y" "LA-VPA-LABEL")
  (VPANG-MKTEXT (list 0 0 (+ L 0.2)) 0.25 0 "z" "LA-VPA-LABEL")
)

;;; ------------------------------------------------------------
;;; ARC DRAWING � in plane spanned by v and u
;;; ------------------------------------------------------------

(defun VPANG-DRAW-ARC (nv nu r n / i step tA tB dirA dirB pA pB)
  (setq step (/ 1.0 n))
  (setq i 0)
  (while (< i n)
    (setq tA (* i step))
    (setq tB (* (+ i 1) step))

    ;; linear interpolation between nv and nu
    (setq dirA
      (list
        (+ (* (- 1.0 tA) (car nv)) (* tA (car nu)))
        (+ (* (- 1.0 tA) (cadr nv)) (* tA (cadr nu)))
        (+ (* (- 1.0 tA) (caddr nv)) (* tA (caddr nu)))
      )
    )

    (setq dirB
      (list
        (+ (* (- 1.0 tB) (car nv)) (* tB (car nu)))
        (+ (* (- 1.0 tB) (cadr nv)) (* tB (cadr nu)))
        (+ (* (- 1.0 tB) (caddr nv)) (* tB (caddr nu)))
      )
    )

    ;; scale to radius
    (setq pA (list (* r (car dirA)) (* r (cadr dirA)) (* r (caddr dirA))))
    (setq pB (list (* r (car dirB)) (* r (cadr dirB)) (* r (caddr dirB))))

    ;; draw segment
    (VPANG-MKLINE pA pB "LA-VPA-ARC")

    (setq i (1+ i))
  )
)

;;; ------------------------------------------------------------
;;; ANGLE TEXT � ? = xx� near arc
;;; ------------------------------------------------------------

(defun VPANG-DRAW-ANGLE-TEXT (nv nu r thetaDeg / bis dirText ptText txt)
  ;; bisector direction (nv + nu), normalized
  (setq bis (VPANG-ADD nv nu))
  (if (<= (VPANG-MAG bis) 0.0)
    (setq dirText nv)
    (setq dirText (VPANG-NORM bis))
  )

  ;; place text slightly outside arc radius
  (setq ptText (VPANG-SCALE (* 1.3 r) dirText))

  ;; AutoCAD Unicode escape for ? = \U+03B8
  (setq txt (strcat "\U+03B8 = " (rtos thetaDeg 2 2) "%%d"))

  ;; *** COLOR MATCHING: put angle text on the ARC layer (yellow) ***
  (VPANG-MKTEXT ptText 0.25 0 txt "LA-VPA-ARC")
)


;;; ------------------------------------------------------------
;;; LAYER 3 COMMAND: VPA
;;; Math + Axes + Vectors + Labels + ARC + ANGLE TEXT + ZOOM
;;; ------------------------------------------------------------

(defun C:VPA ( / vx vy vz ux uy uz v u
                 magv magu dot cosT theta thetaDeg
                 tipV tipU
                 nv nu r
                 useFixed degPerSeg nSeg)

  (prompt "\nVPA LAYER 3 - Math + Axes + Vectors + Labels + ARC + ANGLE TEXT + ZOOM")

  ;; Input
  (prompt "\nEnter vector v:")
  (setq vx (getreal "\n  v_x: "))
  (setq vy (getreal "\n  v_y: "))
  (setq vz (getreal "\n  v_z: "))

  (prompt "\nEnter vector u:")
  (setq ux (getreal "\n  u_x: "))
  (setq uy (getreal "\n  u_y: "))
  (setq uz (getreal "\n  u_z: "))

  (setq v (list vx vy vz))
  (setq u (list ux uy uz))

  ;; Math
  (setq magv (VPANG-MAG v))
  (setq magu (VPANG-MAG u))
  (setq dot  (VPANG-DOT v u))
  (setq cosT (/ dot (* magv magu)))
  (setq theta (VPANG-ACOS cosT))
  (setq thetaDeg (* 180.0 (/ theta pi)))

  (prompt "\nMAGV = ") (prin1 magv)
  (prompt "\nMAGU = ") (prin1 magu)
  (prompt "\nDOT  = ") (prin1 dot)
  (prompt "\nCOST = ") (prin1 cosT)
  (prompt "\nTHETA = ") (prin1 theta)
  (prompt "\nTHETA DEG = ") (prin1 thetaDeg)

  ;; Layers
  (VPANG-MAKE-LAYER "LA-VPA-V"     1)  ; v vector + label
  (VPANG-MAKE-LAYER "LA-VPA-U"     3)  ; u vector + label
  (VPANG-MAKE-LAYER "LA-VPA-ARC"   2)  ; arc
  (VPANG-MAKE-LAYER "LA-VPA-CONST" 8)
  (VPANG-MAKE-LAYER "LA-VPA-LABEL" 7)

  ;; Draw axes
  (prompt "\n\nDrawing axes...")
  (VPANG-DRAW-AXES)

  ;; Draw vector lines
  (prompt "\nDrawing vector lines...")
  (VPANG-MKLINE '(0 0 0) v "LA-VPA-V")
  (VPANG-MKLINE '(0 0 0) u "LA-VPA-U")

  ;; Vector labels (color-matched via their vector layers)
  (prompt "\nDrawing vector labels...")
  (setq tipV (VPANG-SCALE 1.05 v))
  (setq tipU (VPANG-SCALE 1.05 u))

  (VPANG-MKTEXT tipV 0.25 0 "v" "LA-VPA-V")
  (VPANG-MKTEXT tipU 0.25 0 "u" "LA-VPA-U")

  ;; Unit vectors and radius for arc
  (setq nv (VPANG-NORM v))
  (setq nu (VPANG-NORM u))
  (setq r  (* 0.4 (VPANG-MIN2 magv magu)))

  ;; Segmentation policy: B default, C optional
  ;; Register keywords: Y, N, Yes, No
  (initget "Y N Yes No")
  (setq useFixed
    (getkword "\nUse fixed angular resolution? [Yes/No] <No>: ")
  )

  (if (or (= useFixed "Y") (= useFixed "Yes"))
    (progn
      ;; Option C: fixed degrees per segment
      (setq degPerSeg (getreal "\nDegrees per segment <5.0>: "))
      (if (or (null degPerSeg) (<= degPerSeg 0.0))
        (setq degPerSeg 5.0)
      )
      (setq nSeg (fix (/ thetaDeg degPerSeg)))
      (if (< nSeg 3) (setq nSeg 3))
    )
    (progn
      ;; Default B: segments scale with angle
      ;; about 8 segments per 90 degrees, clamped
      (setq nSeg (fix (* thetaDeg (/ 8.0 90.0))))
      (if (< nSeg 6)  (setq nSeg 6))
      (if (> nSeg 48) (setq nSeg 48))
    )
  )

  (prompt "\nDrawing arc...")
  (VPANG-DRAW-ARC nv nu r nSeg)

  ;; Angle text
  (prompt "\nPlacing angle text...")
  (VPANG-DRAW-ANGLE-TEXT nv nu r thetaDeg)

  ;; Zoom extents (suite standard)
  (prompt "\nZooming to extents...")
  (command "_.ZOOM" "E")

  (prompt "\nVPA complete.")
  (princ)
)

(princ "\nVP-ANGLE_Rev1 LAYER 3 loaded. Command: VPA")
(princ)
