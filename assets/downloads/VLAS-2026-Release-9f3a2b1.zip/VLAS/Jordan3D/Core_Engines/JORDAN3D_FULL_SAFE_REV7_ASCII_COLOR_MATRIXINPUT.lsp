;=====================================================================
;  JORDAN3D_FULL_SAFE_REV7_ASCII_COLOR_MATRIXINPUT  �  Jordan3D Core Engine
;  LinearAlgebraSuite_Safe
;
;  File:        JORDAN3D_FULL_SAFE_REV7_ASCII_COLOR_MATRIXINPUT.lsp
;  Revision:    Rev7 (2026)
;  Status:      SAFE?REV / Production?Grade
;
;  Author:      Chris A. LaFollette
;  Copyright:   � 2026 Chris A. LaFollette
;
;  Description:
;     Complete computational engine for the Jordan3D visualization system.
;     Performs all mathematical operations including:
;         � eigenstructure analysis
;         � generalized eigenvector chain construction
;         � Jordan block assembly
;         � ASCII?safe matrix input parsing
;         � color?coded matrix display
;     This file contains no launcher logic, no menus, and no UI prompts.
;     It is the pure mathematical engine used by SAFE?REV Jordan3D wrappers.
;
;  SAFE?SUITE Notes:
;     - ASCII?only labels and prompts
;     - No Smart Label Engine; labels are diagram?anchored and local
;     - No persistent UCS or view modifications
;     - No layer creation here; required layers must be provided by the
;       SAFE?REV launcher/template
;     - Early exit if matrix input is invalid or non?numeric
;
;  Required Layers (provided by launcher/template):
;     J3D-MATRIX       (Continuous)        � matrix display
;     J3D-VECTOR       (Continuous)        � eigenvectors and chains
;     J3D-LABEL        (Continuous)        � text labels
;     J3D-AUX          (Continuous)        � auxiliary geometry
;
;  Baseline Linetype Settings:
;     LTSCALE    = 5
;     CELTSCALE  = 1
;     PSLTSCALE  = 1
;
;  Architecture (SAFE?REV):
;     - Pure computational engine; no menus or UI.
;     - Called by SAFE?REV wrappers such as JCHAIN3D_REV10.
;     - Provides:
;         * eigenvalue computation
;         * eigenvector and chain construction
;         * Jordan block assembly
;         * ASCII?safe matrix input parsing
;         * color?coded matrix visualization primitives
;
;  Legal:
;     Redistribution, modification, or inclusion in other software is
;     prohibited without written permission from the author. This file is
;     part of the LinearAlgebraSuite_Safe SAFE?REV collection and is
;     included in the 2026 copyright deposit.
;
;=====================================================================



(prompt "\n[TRACE] File loaded � top-level OK\n")

;;; ---------------------------
;;; Vector + matrix utilities
;;; ---------------------------

(defun J3D:V+ (a b)
  (list (+ (nth 0 a) (nth 0 b))
        (+ (nth 1 a) (nth 1 b))
        (+ (nth 2 a) (nth 2 b)))
)

(defun J3D:VSCALE (s v)
  (list (* s (nth 0 v))
        (* s (nth 1 v))
        (* s (nth 2 v)))
)

(defun J3D:V-DOT (a b)
  (+ (* (nth 0 a) (nth 0 b))
     (* (nth 1 a) (nth 1 b))
     (* (nth 2 a) (nth 2 b)))
)

(defun J3D:V-LEN (v)
  (sqrt (J3D:V-DOT v v))
)

(defun J3D:V-NORM (v)
  (setq J3D:LEN (J3D:V-LEN v))
  (if (and J3D:LEN (/= J3D:LEN 0.0))
    (J3D:VSCALE (/ 1.0 J3D:LEN) v)
    v
  )
)

(defun J3D:MAT-MUL (A v)
  (list
    (+ (* (nth 0 (nth 0 A)) (nth 0 v))
       (* (nth 1 (nth 0 A)) (nth 1 v))
       (* (nth 2 (nth 0 A)) (nth 2 v)))
    (+ (* (nth 0 (nth 1 A)) (nth 0 v))
       (* (nth 1 (nth 1 A)) (nth 1 v))
       (* (nth 2 (nth 1 A)) (nth 2 v)))
    (+ (* (nth 0 (nth 2 A)) (nth 0 v))
       (* (nth 1 (nth 2 A)) (nth 1 v))
       (* (nth 2 (nth 2 A)) (nth 2 v)))
  )
)

;;; ---------------------------
;;; SAFE wrappers
;;; ---------------------------

(defun J3D:SAFE-LAYER (J3D:LAYERNAME)
  (if (tblsearch "LAYER" J3D:LAYERNAME)
    (setvar "CLAYER" J3D:LAYERNAME)
  )
)

(defun J3D:SAFE-LINE (J3D:P1 J3D:P2 J3D:LAYERNAME)
  (if (and J3D:P1 J3D:P2
           (listp J3D:P1) (= (length J3D:P1) 3)
           (listp J3D:P2) (= (length J3D:P2) 3))
    (progn
      (J3D:SAFE-LAYER J3D:LAYERNAME)
      (command "._LINE" J3D:P1 J3D:P2 "")
    )
    (prompt
      (strcat
        "\n[JORDAN3D] SAFE-LINE skipped, bad points: "
        (vl-princ-to-string J3D:P1) " , "
        (vl-princ-to-string J3D:P2) "\n"
      )
    )
  )
)

(defun J3D:SAFE-TEXT (J3D:P J3D:H J3D:TXT J3D:LAYERNAME)
  (if (and J3D:P (listp J3D:P) (= (length J3D:P) 3) J3D:H J3D:TXT)
    (progn
      (J3D:SAFE-LAYER J3D:LAYERNAME)
      (command "._TEXT" J3D:P J3D:H 0.0 J3D:TXT)
    )
    (prompt
      (strcat
        "\n[JORDAN3D] SAFE-TEXT skipped, bad point/text: "
        (vl-princ-to-string J3D:P) " , "
        (vl-princ-to-string J3D:TXT) "\n"
      )
    )
  )
)

;;; ---------------------------
;;; Layers
;;; ---------------------------

(defun J3D:MAKE-LAYERS ()
  (prompt "\n[TRACE] Entered MAKE-LAYERS\n")
  (foreach J3D:DEF
    '(
      ("JV3-GRID"        8)
      ("JV3-BASIS"       7)
      ("JV3-EIGENVEC"    4)
      ("JV3-GENEVEC"     2)
      ("JV3-IMAGE"       6)
      ("JV3-JORDAN"      30)
      ("JV3-LABEL"       7)
     )
    (if (not (tblsearch "LAYER" (car J3D:DEF)))
      (command "._LAYER" "M" (car J3D:DEF) "C" (cadr J3D:DEF) "" "")
    )
  )
)

;;; ---------------------------
;;; Title
;;; ---------------------------

(defun J3D:TITLE (J3D:ORG J3D:TEXT)
  (J3D:SAFE-TEXT (J3D:V+ J3D:ORG '(-1.5 6.0 0.0)) 0.7 J3D:TEXT "JV3-LABEL")
)

;;; ------------------------------------------------------------
;;; REV5.4.1 SIMPLE leader-style label placement with Z-lift
;;; ------------------------------------------------------------

(defun J3D:LABEL-PLACE (J3D:ORG J3D:V J3D:FAMILY J3D:TEXT)

  (if (and J3D:V (listp J3D:V) (= (length J3D:V) 3))
      (setq J3D:VEC J3D:V)
      (setq J3D:VEC '(0 0 0))
  )

  (setq J3D:TIP (J3D:V+ J3D:ORG J3D:VEC))

      ;; Family-specific leader directions (refined spacing)
  (setq J3D:DIR
    (cond
      ;; Basis vectors (e1, e2, e3) � push right/up
      ((= J3D:FAMILY 'basis) '(0.55 0.35 0.20))

      ;; Eigenvector v � push left/up to separate from e1
      ((= J3D:FAMILY 'eigen) '(-0.55 0.35 0.20))

      ;; First generalized eigenvector g1 � +1 character vertical
      ((= J3D:FAMILY 'g1)    '(0.00 0.70 0.40))

      ;; Second generalized eigenvector g2 � +1 character horizontal
      ((= J3D:FAMILY 'g2)    '(0.70 0.00 0.40))

      ;; Image vectors A�e � diagonal, slightly shallower
      ((= J3D:FAMILY 'image) '(0.45 0.20 0.40))

      ;; Fallback
      (T '(0.40 0.40 0.20))
    )
  )

;;------------------------------------------------------------------end insert Family-specific-----

  (setq J3D:LE (J3D:V+ J3D:TIP J3D:DIR))

  (J3D:SAFE-LINE J3D:TIP J3D:LE "JV3-LABEL")

  (cond
    ((= J3D:FAMILY 'eigen)
     (J3D:SAFE-TEXT J3D:LE 0.4 J3D:TEXT "JV3-EIGENVEC"))
    ((= J3D:FAMILY 'g1)
     (J3D:SAFE-TEXT J3D:LE 0.4 J3D:TEXT "JV3-GENEVEC"))
    ((= J3D:FAMILY 'g2)
     (J3D:SAFE-TEXT J3D:LE 0.4 J3D:TEXT "JV3-GENEVEC"))
    ((= J3D:FAMILY 'image)
     (J3D:SAFE-TEXT J3D:LE 0.4 J3D:TEXT "JV3-IMAGE"))
    ((= J3D:FAMILY 'basis)
     (J3D:SAFE-TEXT J3D:LE 0.4 J3D:TEXT "JV3-BASIS"))
    (T
     (J3D:SAFE-TEXT J3D:LE 0.4 J3D:TEXT "JV3-LABEL"))
  )
)

;;; ---------------------------
;;; Grid
;;; ---------------------------

(setq J3D:GRID-MIN -2)
(setq J3D:GRID-MAX  2)

(defun J3D:DRAW-GRID (J3D:ORG)
  (prompt "\n[TRACE] Entered DRAW-GRID\n")
  (prompt
    (strcat
      "\n[JORDAN3D] Drawing grid from "
      (itoa J3D:GRID-MIN) " to " (itoa J3D:GRID-MAX) "...\n"
    )
  )
  (princ)

  (setq J3D:MIN J3D:GRID-MIN)
  (setq J3D:MAX J3D:GRID-MAX)

  ;; X-lines
  (setq J3D:Y J3D:MIN)
  (while (<= J3D:Y J3D:MAX)
    (setq J3D:Z J3D:MIN)
    (while (<= J3D:Z J3D:MAX)
      (J3D:SAFE-LINE
        (J3D:V+ J3D:ORG (list J3D:MIN J3D:Y J3D:Z))
        (J3D:V+ J3D:ORG (list J3D:MAX J3D:Y J3D:Z))
        "JV3-GRID"
      )
      (setq J3D:Z (1+ J3D:Z))
    )
    (setq J3D:Y (1+ J3D:Y))
  )

  ;; Y-lines
  (setq J3D:X J3D:MIN)
  (while (<= J3D:X J3D:MAX)
    (setq J3D:Z J3D:MIN)
    (while (<= J3D:Z J3D:MAX)
      (J3D:SAFE-LINE
        (J3D:V+ J3D:ORG (list J3D:X J3D:MIN J3D:Z))
        (J3D:V+ J3D:ORG (list J3D:X J3D:MAX J3D:Z))
        "JV3-GRID"
      )
      (setq J3D:Z (1+ J3D:Z))
    )
    (setq J3D:X (1+ J3D:X))
  )

  ;; Z-lines
  (setq J3D:X J3D:MIN)
  (while (<= J3D:X J3D:MAX)
    (setq J3D:Y J3D:MIN)
    (while (<= J3D:Y J3D:MAX)
      (J3D:SAFE-LINE
        (J3D:V+ J3D:ORG (list J3D:X J3D:Y J3D:MIN))
        (J3D:V+ J3D:ORG (list J3D:X J3D:Y J3D:MAX))
        "JV3-GRID"
      )
      (setq J3D:Y (1+ J3D:Y))
    )
    (setq J3D:X (1+ J3D:X))
  )
)

;;; ---------------------------
;;; Matrix input (REV5)
;;; ---------------------------

(defun J3D:GET-MATRIX ()
  (prompt "\n[TRACE] Entered GET-MATRIX\n")
  (prompt "\n[JORDAN3D] Enter 3x3 matrix A row by row.\n")
  (princ)

  (prompt "\nFirst row:")
  (setq J3D:A11 (getreal "\nA11: "))
  (setq J3D:A12 (getreal "A12: "))
  (setq J3D:A13 (getreal "A13: "))

  (prompt "\nSecond row:")
  (setq J3D:A21 (getreal "\nA21: "))
  (setq J3D:A22 (getreal "A22: "))
  (setq J3D:A23 (getreal "A23: "))

  (prompt "\nThird row:")
  (setq J3D:A31 (getreal "\nA31: "))
  (setq J3D:A32 (getreal "A32: "))
  (setq J3D:A33 (getreal "A33: "))

  (setq J3D:A
        (list
          (list J3D:A11 J3D:A12 J3D:A13)
          (list J3D:A21 J3D:A22 J3D:A23)
          (list J3D:A31 J3D:A32 J3D:A33)
        )
  )

  (prompt (strcat "\n[JORDAN3D] A = " (vl-princ-to-string J3D:A) "\n"))
  (princ)

  J3D:A
)

;;; ============================================================
;;; REV6 eigenstructure core (single 3x3 Jordan chain)
;;; ============================================================

(defun J3D:SUB-LAMBDA-I (A L)
  (list
    (list (- (nth 0 (nth 0 A)) L) (nth 1 (nth 0 A))       (nth 2 (nth 0 A)))
    (list (nth 0 (nth 1 A))       (- (nth 1 (nth 1 A)) L) (nth 2 (nth 1 A)))
    (list (nth 0 (nth 2 A))       (nth 1 (nth 2 A))       (- (nth 2 (nth 2 A)) L))
  )
)

(defun J3D:MAT-VEC (M v)
  (list
    (+ (* (nth 0 (nth 0 M)) (nth 0 v))
       (* (nth 1 (nth 0 M)) (nth 1 v))
       (* (nth 2 (nth 0 M)) (nth 2 v)))
    (+ (* (nth 0 (nth 1 M)) (nth 0 v))
       (* (nth 1 (nth 1 M)) (nth 1 v))
       (* (nth 2 (nth 1 M)) (nth 2 v)))
    (+ (* (nth 0 (nth 2 M)) (nth 0 v))
       (* (nth 1 (nth 2 M)) (nth 1 v))
       (* (nth 2 (nth 2 M)) (nth 2 v)))
  )
)

(defun J3D:NULL-3x3 (M)
  (prompt "\n[REV6] Finding eigenvector (nullspace of A - ?I)...\n")
  (princ)

  (setq J3D:CANDIDATES
    (list
      '(1 0 0)
      '(0 1 0)
      '(0 0 1)
      '(1 1 0)
      '(1 0 1)
      '(0 1 1)
      '(1 1 1)
    )
  )

  (setq J3D:VEC nil)
  (setq eps 1e-6)

  (foreach J3D:C J3D:CANDIDATES
    (if (not J3D:VEC)
      (progn
        (setq J3D:RES (J3D:MAT-VEC M J3D:C))
        (if (and
              (< (abs (nth 0 J3D:RES)) eps)
              (< (abs (nth 1 J3D:RES)) eps)
              (< (abs (nth 2 J3D:RES)) eps)
            )
          (setq J3D:VEC J3D:C)
        )
      )
    )
  )

  (if J3D:VEC
    (progn
      (prompt (strcat "[REV6] Eigenvector candidate v = "
                      (vl-princ-to-string J3D:VEC) "\n"))
      (princ)
      J3D:VEC
    )
    (progn
      (prompt "\n[REV6] NULL-3x3 failed to find a null vector.\n")
      (princ)
      nil
    )
  )
)

(defun J3D:SOLVE-SINGULAR-3x3 (M b)
  (prompt "\n[REV6] SOLVE-SINGULAR-3x3: solving M x = b ...\n")
  (princ)

  (setq eps 1e-8)

  (setq r1 (list (nth 0 (nth 0 M)) (nth 1 (nth 0 M)) (nth 2 (nth 0 M)) (nth 0 b)))
  (setq r2 (list (nth 0 (nth 1 M)) (nth 1 (nth 1 M)) (nth 2 (nth 1 M)) (nth 1 b)))
  (setq r3 (list (nth 0 (nth 2 M)) (nth 1 (nth 2 M)) (nth 2 (nth 2 M)) (nth 2 b)))

  (if (< (abs (nth 0 r1)) eps)
    (progn
      (if (>= (abs (nth 0 r2)) eps)
        (setq tmp r1 r1 r2 r2 tmp)
        (if (>= (abs (nth 0 r3)) eps)
          (setq tmp r1 r1 r3 r3 tmp)
        )
      )
    )
  )

  (if (>= (abs (nth 0 r1)) eps)
    (progn
      (setq f21 (/ (nth 0 r2) (nth 0 r1)))
      (setq f31 (/ (nth 0 r3) (nth 0 r1)))

      (setq r2 (list
                 (- (nth 0 r2) (* f21 (nth 0 r1)))
                 (- (nth 1 r2) (* f21 (nth 1 r1)))
                 (- (nth 2 r2) (* f21 (nth 2 r1)))
                 (- (nth 3 r2) (* f21 (nth 3 r1)))))
      (setq r3 (list
                 (- (nth 0 r3) (* f31 (nth 0 r1)))
                 (- (nth 1 r3) (* f31 (nth 1 r1)))
                 (- (nth 2 r3) (* f31 (nth 2 r1)))
                 (- (nth 3 r3) (* f31 (nth 3 r1)))))
    )
  )

  (if (< (abs (nth 1 r2)) eps)
    (progn
      (if (>= (abs (nth 1 r3)) eps)
        (setq tmp r2 r2 r3 r3 tmp)
      )
    )
  )

  (if (and (>= (abs (nth 1 r2)) eps)
           (>= (abs (nth 1 r3)) eps))
    (progn
      (setq f32 (/ (nth 1 r3) (nth 1 r2)))
      (setq r3 (list
                 (- (nth 0 r3) (* f32 (nth 0 r2)))
                 (- (nth 1 r3) (* f32 (nth 1 r2)))
                 (- (nth 2 r3) (* f32 (nth 2 r2)))
                 (- (nth 3 r3) (* f32 (nth 3 r2)))))
    )
  )

  (if (and (< (abs (nth 0 r3)) eps)
           (< (abs (nth 1 r3)) eps)
           (< (abs (nth 2 r3)) eps)
           (> (abs (nth 3 r3)) eps))
    (progn
      (prompt "\n[REV6] System is inconsistent (no solution).\n")
      (princ)
      (setq J3D:SOLN nil)
    )
    (progn
      (if (>= (abs (nth 2 r3)) eps)
        (setq x3 (/ (nth 3 r3) (nth 2 r3)))
        (setq x3 0.0)
      )

      (if (and (< (abs (nth 1 r2)) eps)
               (< (abs (nth 0 r2)) eps)
               (< (abs (nth 2 r2)) eps))
        (setq x2 0.0)
        (progn
          (if (>= (abs (nth 1 r2)) eps)
            (setq x2 (/ (- (nth 3 r2) (* (nth 2 r2) x3)) (nth 1 r2)))
            (setq x2 0.0)
          )
        )
      )

      (if (and (< (abs (nth 0 r1)) eps)
               (< (abs (nth 1 r1)) eps)
               (< (abs (nth 2 r1)) eps))
        (setq x1 0.0)
        (progn
          (if (>= (abs (nth 0 r1)) eps)
            (setq x1 (/ (- (nth 3 r1)
                           (* (nth 1 r1) x2)
                           (* (nth 2 r1) x3))
                        (nth 0 r1)))
            (setq x1 0.0)
          )
        )
      )

      (setq J3D:SOLN (list x1 x2 x3))

      (setq ok T)
      (setq res (J3D:MAT-VEC M J3D:SOLN))
      (if (or
            (and (< (abs (nth 0 J3D:SOLN)) eps)
                 (< (abs (nth 1 J3D:SOLN)) eps)
                 (< (abs (nth 2 J3D:SOLN)) eps))
            (> (abs (- (nth 0 res) (nth 0 b))) 1e-4)
            (> (abs (- (nth 1 res) (nth 1 b))) 1e-4)
            (> (abs (- (nth 2 res) (nth 2 b))) 1e-4)
          )
        (setq ok nil)
      )

      (if (not ok)
        (progn
          (prompt "\n[REV6] Basic solve gave trivial/bad solution; searching for nontrivial candidate...\n")
          (princ)
          (setq candidates
            (list
              '(1 0 0)
              '(0 1 0)
              '(0 0 1)
              '(1 1 0)
              '(1 0 1)
              '(0 1 1)
              '(1 1 1)
            )
          )
          (setq J3D:SOLN nil)
          (foreach c candidates
            (if (not J3D:SOLN)
              (progn
                (setq res (J3D:MAT-VEC M c))
                (if (and
                      (< (abs (- (nth 0 res) (nth 0 b))) 1e-4)
                      (< (abs (- (nth 1 res) (nth 1 b))) 1e-4)
                      (< (abs (- (nth 2 res) (nth 2 b))) 1e-4)
                    )
                  (setq J3D:SOLN c)
                )
              )
            )
          )
        )
      )

      (if J3D:SOLN
        (prompt (strcat "[REV6] SOLVE-SINGULAR-3x3 solution x = "
                        (vl-princ-to-string J3D:SOLN) "\n"))
        (prompt "\n[REV6] SOLVE-SINGULAR-3x3 could not find a solution.\n")
      )
      (princ)
    )
  )

  J3D:SOLN
)

(defun J3D:BUILD-CHAIN (A L)
  (prompt "\n[REV6] Building Jordan chain of length 3...\n")
  (princ)

  (setq J3D:B (J3D:SUB-LAMBDA-I A L))

  (setq J3D:V (J3D:NULL-3x3 J3D:B))

  (if (not J3D:V)
    (progn
      (prompt "\n[REV6] Could not find eigenvector; aborting chain.\n")
      (princ)
      nil
    )
    (progn
      (setq J3D:G1 (J3D:SOLVE-SINGULAR-3x3 J3D:B J3D:V))
      (if (not J3D:G1)
        (progn
          (prompt "\n[REV6] Could not solve for g1; aborting chain.\n")
          (princ)
          nil
        )
        (progn
          (setq J3D:G2 (J3D:SOLVE-SINGULAR-3x3 J3D:B J3D:G1))
          (if (not J3D:G2)
            (progn
              (prompt "\n[REV6] Could not solve for g2; aborting chain.\n")
              (princ)
              nil
            )
            (progn
              (prompt (strcat "\n[REV6] Chain built:\n  v  = "
                              (vl-princ-to-string J3D:V)))
              (prompt (strcat "\n  g1 = "
                              (vl-princ-to-string J3D:G1)))
              (prompt (strcat "\n  g2 = "
                              (vl-princ-to-string J3D:G2) "\n"))
              (princ)
              (list
                (cons 'lambda L)
                (cons 'evec   J3D:V)
                (cons 'g1     J3D:G1)
                (cons 'g2     J3D:G2)
                (cons 'status "chain-3")
              )
            )
          )
        )
      )
    )
  )
)

(defun J3D:ANALYZE-MATRIX (J3D:A)
  (prompt "\n[TRACE] Entered ANALYZE-MATRIX (REV6)\n")

  (setq J3D:TR (+ (nth 0 (nth 0 J3D:A))
                  (nth 1 (nth 1 J3D:A))
                  (nth 2 (nth 2 J3D:A))))
  (setq J3D:LAMBDA (/ J3D:TR 3.0))

  (prompt (strcat "\n[REV6] Approximated eigenvalue ? = "
                  (rtos J3D:LAMBDA 2 6) "\n"))
  (princ)

  (setq J3D:ES (J3D:BUILD-CHAIN J3D:A J3D:LAMBDA))

  (if J3D:ES
    J3D:ES
    (progn
      (prompt "\n[REV6] ANALYZE-MATRIX failed; falling back to placeholder chain.\n")
      (princ)
      (list
        (cons 'lambda 0.0)
        (cons 'evec   '(1 0 0))
        (cons 'g1     '(0 1 0))
        (cons 'g2     '(0 0 1))
        (cons 'status "fallback")
      )
    )
  )
)

;;; ---------------------------
;;; TEST HARNESS: C:J3DTEST
;;; ---------------------------

(defun C:J3DTEST ()
  (prompt "\n[REV6 TEST] Using canonical 3x3 Jordan block with ?=2...\n")
  (princ)

  (setq J3D:A
    (list
      (list 2 1 0)
      (list 0 2 1)
      (list 0 0 2)
    )
  )

  (prompt (strcat "\n[REV6 TEST] A = "
                  (vl-princ-to-string J3D:A) "\n"))
  (princ)

  (setq J3D:ES (J3D:ANALYZE-MATRIX J3D:A))

  (prompt (strcat "\n[REV6 TEST] Eigenstructure record = "
                  (vl-princ-to-string J3D:ES) "\n"))
  (princ)

  (setq J3D:L  (cdr (assoc 'lambda J3D:ES)))
  (setq J3D:V  (cdr (assoc 'evec   J3D:ES)))
  (setq J3D:G1 (cdr (assoc 'g1     J3D:ES)))
  (setq J3D:G2 (cdr (assoc 'g2     J3D:ES)))

  (prompt "\n[REV6 TEST] Verifying chain equations:\n")
  (princ)

  (setq J3D:B (J3D:SUB-LAMBDA-I J3D:A J3D:L))

  (setq J3D:BV (J3D:MAT-VEC J3D:B J3D:V))
  (prompt (strcat "  (A - ?I)v  = "
                  (vl-princ-to-string J3D:BV)
                  "  (should be ~0)\n"))
  (princ)

  (setq J3D:BG1 (J3D:MAT-VEC J3D:B J3D:G1))
  (prompt (strcat "  (A - ?I)g1 = "
                  (vl-princ-to-string J3D:BG1)
                  "  (should match v)\n"))
  (princ)

  (setq J3D:BG2 (J3D:MAT-VEC J3D:B J3D:G2))
  (prompt (strcat "  (A - ?I)g2 = "
                  (vl-princ-to-string J3D:BG2)
                  "  (should match g1)\n"))
  (princ)

  (prompt "\n[REV6 TEST] Done.\n")
  (princ)
)

;;; ---------------------------
;;; A-panel
;;; ---------------------------

(defun J3D:DRAW-A-PANEL (J3D:A J3D:ORG J3D:DATA)
  (prompt "\n[TRACE] Entered DRAW-A-PANEL\n")
  (prompt "\n[JORDAN3D] Drawing A-panel...\n")
  (princ)

  (setq J3D:E1 '(1 0 0))
  (setq J3D:E2 '(0 1 0))
  (setq J3D:E3 '(0 0 1))

  (J3D:DRAW-GRID J3D:ORG)

  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:E1) "JV3-BASIS")
  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:E2) "JV3-BASIS")
  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:E3) "JV3-BASIS")
  (J3D:LABEL-PLACE J3D:ORG J3D:E1 'basis "e1")
  (J3D:LABEL-PLACE J3D:ORG J3D:E2 'basis "e2")
  (J3D:LABEL-PLACE J3D:ORG J3D:E3 'basis "e3")

  (setq J3D:V  (cdr (assoc 'evec J3D:DATA)))
  (setq J3D:G1 (cdr (assoc 'g1   J3D:DATA)))
  (setq J3D:G2 (cdr (assoc 'g2   J3D:DATA)))

  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:V) "JV3-EIGENVEC")
  (J3D:LABEL-PLACE J3D:ORG J3D:V 'eigen "eigenvector")

  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:G1) "JV3-GENEVEC")
  (J3D:LABEL-PLACE J3D:ORG J3D:G1 'g1 "gen. eigenvector")

  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:G2) "JV3-GENEVEC")
  (J3D:LABEL-PLACE J3D:ORG J3D:G2 'g2 "gen. eigenvector")

  (foreach J3D:E (list J3D:E1 J3D:E2 J3D:E3)
    (setq J3D:Ae (J3D:MAT-MUL J3D:A J3D:E))
    (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:Ae) "JV3-IMAGE")
    (J3D:LABEL-PLACE J3D:ORG J3D:Ae 'image "A�e")
  )

  (J3D:TITLE J3D:ORG "A-Action")
)

;;; ---------------------------
;;; J-panel (using Jordan form)
;;; ---------------------------

(defun J3D:DRAW-J-PANEL (J3D:A J3D:ORG J3D:DATA)
  (prompt "\n[TRACE] Entered DRAW-J-PANEL\n")
  (prompt "\n[JORDAN3D] Drawing J-panel...\n")
  (princ)

  (setq J3D:E1 '(1 0 0))
  (setq J3D:E2 '(0 1 0))
  (setq J3D:E3 '(0 0 1))

  (J3D:DRAW-GRID J3D:ORG)

  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:E1) "JV3-BASIS")
  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:E2) "JV3-BASIS")
  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:E3) "JV3-BASIS")
  (J3D:LABEL-PLACE J3D:ORG J3D:E1 'basis "e1")
  (J3D:LABEL-PLACE J3D:ORG J3D:E2 'basis "e2")
  (J3D:LABEL-PLACE J3D:ORG J3D:E3 'basis "e3")

  (setq J3D:L  (cdr (assoc 'lambda J3D:DATA)))
  (setq J3D:V  (cdr (assoc 'evec   J3D:DATA)))
  (setq J3D:G1 (cdr (assoc 'g1     J3D:DATA)))
  (setq J3D:G2 (cdr (assoc 'g2     J3D:DATA)))

  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:V) "JV3-JORDAN")
  (J3D:LABEL-PLACE J3D:ORG J3D:V 'eigen "v")

  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:G1) "JV3-JORDAN")
  (J3D:LABEL-PLACE J3D:ORG J3D:G1 'g1 "g1")

  (J3D:SAFE-LINE J3D:ORG (J3D:V+ J3D:ORG J3D:G2) "JV3-JORDAN")
  (J3D:LABEL-PLACE J3D:ORG J3D:G2 'g2 "g2")

  (J3D:TITLE J3D:ORG "Jordan Chain")
)

;;; ------------------------------------------------------------
;;; Command entry point for AutoCAD (REV7/REV8 core)
;;; ------------------------------------------------------------

(defun c:JORDAN3D ()
  (prompt "\n[REV7] Entered JORDAN3D core engine.\n")
  (prompt "\n[JORDAN3D] 3x3 Jordan Visualizer starting...\n")

  (setq J3D:OLD-OSMODE     (getvar "OSMODE"))
  (setq J3D:OLD-OSNAPCOORD (getvar "OSNAPCOORD"))

  (setvar "OSMODE" 0)
  (setvar "OSNAPCOORD" 1)

  (J3D:MAKE-LAYERS)

  (prompt "\nGrid density options:\n")
  (prompt "  1 - Full grid (7x7x7)\n")
  (prompt "  2 - Medium grid (5x5x5) [default]\n")

  (setq J3D:GD (getstring "\nSelect option <2>: "))

  (cond
    ((= J3D:GD "1")
     (setq J3D:GRID-MIN -3)
     (setq J3D:GRID-MAX  3)
    )
    (T
     (setq J3D:GRID-MIN -2)
     (setq J3D:GRID-MAX  2)
    )
  )

  (prompt "\n[REV7] Entering matrix input...\n")
  (setq J3D:A (J3D:GET-MATRIX))

  (prompt "\n[REV7] Analyzing matrix...\n")
  (setq J3D:DATA (J3D:ANALYZE-MATRIX J3D:A))

  (prompt "\n[REV7] Drawing A-panel...\n")
  (J3D:DRAW-A-PANEL J3D:A '(0 0 0)  J3D:DATA)

  (prompt "\n[REV7] Drawing J-panel...\n")
  (J3D:DRAW-J-PANEL J3D:A '(20 0 0) J3D:DATA)

  (if J3D:OLD-OSMODE     (setvar "OSMODE"     J3D:OLD-OSMODE))
  (if J3D:OLD-OSNAPCOORD (setvar "OSNAPCOORD" J3D:OLD-OSNAPCOORD))

  (prompt "\n[JORDAN3D] Done.\n")
  (princ)
)

;=====================================================================
;  END OF FILE: JORDAN3D_FULL_SAFE_REV7_ASCII_COLOR_MATRIXINPUT.LSP
;
;  This core engine is part of the cadcando Visual Linear Algebra
;  System (VLAS). Licensed to the end user after purchase from the
;  official VLAS site. Individual educational, instructional, or
;  personal use permitted. Redistribution, resale, or modification
;  without written permission is prohibited.
;=====================================================================

(prompt "\nJORDAN3D_FULL_SAFE_REV7_ASCII_COLOR_MATRIXINPUT loaded. Use command: JORDAN3D\n")
(princ)
