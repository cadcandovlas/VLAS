;=====================================================================
;  MEXP3D_Rev4  �  Matrix Exponential (3�3) Trajectory Visualization
;  LinearAlgebraSuite_Safe
;
;  File:        MEXP3D_Rev4.lsp
;  Revision:    Rev4 (2026)
;  Status:      SAFE?REV / Production?Grade
;
;  Author:      Chris A. LaFollette
;  Copyright:   � 2026 Chris A. LaFollette
;
;  Description:
;     Visualizes trajectories of the linear system x' = A x in 3D using
;     the matrix exponential x(t) = exp(A t) x0. Draws multiple seeded
;     trajectories, optional vector labels, optional component labels,
;     and optional vector?from?x0 arrows. All labels are ASCII?safe and
;     diagram?anchored. SAFE?REV guarantees stable behavior across
;     restricted AutoCAD environments.
;
;  SAFE?SUITE Notes:
;     - ASCII?only labels (v, x0, xf, components)
;     - No Smart Label Engine; labels are diagram?anchored and local
;     - No persistent UCS or view modifications
;     - No layer creation here; required layers must be provided by the
;       SAFE?REV launcher/template
;     - Early exit if A is not a real 3�3 matrix
;     - Stability flush after each trajectory (UCS W + REGEN)
;
;  Required Layers (provided by launcher/template):
;     ME3D_TRAJ        (Continuous)        � trajectory curves
;     ME3D_LABELS      (Continuous)        � vector and component labels
;     ME3D_AUX         (Continuous)        � auxiliary geometry
;
;  Baseline Linetype Settings:
;     LTSCALE    = 5
;     CELTSCALE  = 1
;     PSLTSCALE  = 1
;
;  Dependencies:
;     � TRANSFORM_LAUNCHER_MINI_MENU_FULL.lsp
;     � LA_LABEL_ENGINE_Rev1b.lsp
;     � MEXP3D_LABEL_ENGINE_Rev2k.lsp
;     � SAFE?REV Layer Model
;
;  Architecture (SAFE?REV):
;     - Launcher creates layers and loads core engines.
;     - This module:
;         * collects matrix A
;         * collects mode, seeds, time interval, dt
;         * computes trajectories using exp(A t)
;         * draws curves and optional labels
;         * performs SAFE?REV stability flush per trajectory
;
;  Command:
;     MEX
;
;  Legal:
;     Redistribution, modification, or inclusion in other software is
;     prohibited without written permission from the author. This file is
;     part of the LinearAlgebraSuite_Safe SAFE?REV collection and is
;     included in the 2026 copyright deposit.
;
;=====================================================================




(princ "\n[ME4] START LOADING Rev4...")

;; The launcher loads both label engines, so Rev4 is ready
;; to use ME3D-label-vector from MEXP3D_LABEL_ENGINE_Rev2k

;---------------------------------------------------------------------
; GLOBAL CONSTANTS AND FLAGS
;---------------------------------------------------------------------

(setq MEX4-spiral-mode         T)      ;; enable experimental spiral approx
(setq MEX4-refine-trajectories T)      ;; enable multi-pass refinement
(setq MEX4-safe-return         nil)    ;; used to prevent stray "T" returns
(setq MEX4-debug               nil)    ;; Disabled for production

;; Label mode:
;;   'coord ? use LAS-LABEL-COORD (calls ME3D-label-vector)
;;   '3d    ? use LAS-LABEL-3D (calls ME3D-label-vector)
(setq MEX4-label-mode 'coord)


;;; ================================================================
;;;  REV4 LABEL SHIM � Working Version + Style A/B/C + Color Gradient
;;; ================================================================

(if (not *MEX4-label-counter*)
  (setq *MEX4-label-counter* 0)
)

;; Default style if not set - RESET each session so prompt shows
(setq *LA-label-style* nil)

;;; ================================================================
;;;  STUDENT STYLE SELECTION
;;; ================================================================
(defun MEX4:CHOOSE-STYLE ( / s )
  (if (not *LA-label-style*)
    (progn
      (setq s
        (getstring
          "\nChoose label style for spiral:
   A = Point indices (P1, P2, P3...)
   B = Vector magnitude |x| = ...
   C = Time parameter t = ...
 <Default = B>: "
        )
      )
      (cond
        ((or (eq s "") (eq (strcase s) "B"))
          (setq *LA-label-style* "B")
        )
        ((eq (strcase s) "A")
          (setq *LA-label-style* "A")
        )
        ((eq (strcase s) "C")
          (setq *LA-label-style* "C")
        )
        (T
          (princ "\nInvalid choice. Using B.")
          (setq *LA-label-style* "B")
        )
      )
    )
  )
  *LA-label-style*
)

;;; ================================================================
;;;  COLOR GRADIENT FUNCTION (Blue ? Cyan ? Green ? Yellow ? Red)
;;; ================================================================
(defun MEX4:GRADIENT-COLOR (counter total-count / color-bin)
  ;; counter: current point/label number
  ;; Returns rainbow gradient: 5 colors
  
  ;; Smart scaling: if counter is small (1-10), it's a label; scale it to full range
  ;; If counter is larger (0-50), it's a trajectory point; divide by 10
  
  (if (<= counter 10)
    ;; Small counter: likely labels (1-5), scale to reach full color range
    (setq color-bin counter)  ; 1-5 maps to bins 0-4 naturally
    ;; Large counter: trajectory points, divide by 10
    (setq color-bin (/ counter 10))
  )
  
  (cond
    ((< color-bin 1) 5)       ; blue
    ((< color-bin 2) 6)       ; magenta
    ((< color-bin 3) 3)       ; cyan
    ((< color-bin 4) 2)       ; yellow
    (T 1)                      ; red
  )
)

(defun LAS-LABEL-COORD (pt layer traj-count / vx vy vz mag txt h u2 perp2 vec col p2 ang oldUCS ent head off2 s c x_rot y_rot entlist)

  ;; increment counter for label sequence numbering
  (setq *MEX4-label-counter* (1+ *MEX4-label-counter*))

  (if MEX4-debug
    (princ (strcat "\n    [LABEL-COORD] Counter=" (itoa *MEX4-label-counter*) " at (" 
                   (rtos (car pt) 2 2) "," (rtos (cadr pt) 2 2) "," (rtos (caddr pt) 2 2) ")"))
  )

  ;; components
  (setq vx (car pt))
  (setq vy (cadr pt))
  (setq vz (caddr pt))

  ;; ============================
  ;; STYLE A/B/C LABEL TEXT
  ;; ============================
  (cond
    ;; Style A � P1, P2, P3...
    ((= *LA-label-style* "A")
      (setq txt (strcat "P" (itoa *MEX4-label-counter*))))

    ;; Style B � |x| = ...
    ((= *LA-label-style* "B")
      (setq mag (sqrt (+ (* vx vx) (* vy vy) (* vz vz))))
      (setq txt (strcat "|x| = " (rtos mag 2 3))))

    ;; Style C � t = ...
    ((= *LA-label-style* "C")
      (setq txt (strcat "t = " (rtos (* *MEX4-label-counter* 0.05) 2 2))))

    (T (setq txt ""))
  )

  (if MEX4-debug
    (princ (strcat "\n      Text: \"" txt "\""))
  )

  ;; text height
  (setq h 0.20)

  ;; radial direction
  (setq u2   (ME3D-unit2 (list vx vy)))
  (setq perp2 (ME3D-perp2 u2))

  ;; outward + minimal Z offset (alternating +/- for visual separation)
  (setq offset-sign (if (= (rem *MEX4-label-counter* 2) 1) 1 -1))
  (setq vec (list (* h (car perp2))
                  (* h (cadr perp2))
                  (* 0.09 *MEX4-label-counter* offset-sign)))

  ;; Calculate gradient color using label counter (not traj-count parameter)
  ;; This ensures each label gets a unique position in the color gradient
  (setq col (MEX4:GRADIENT-COLOR *MEX4-label-counter* 200))

  (if MEX4-debug
    (princ (strcat "\n      Color: " (itoa col)))
  )

  ;; Build label point (head of vector + perpendicular offset)
  (setq head
        (list
          (+ (nth 0 pt) (nth 0 vec))
          (+ (nth 1 pt) (nth 1 vec))
          (+ (nth 2 pt) (nth 2 vec))))

  (setq u2   (ME3D-unit2 (list (nth 0 vec) (nth 1 vec))))
  (setq perp2 (ME3D-perp2 u2))

  (setq off2
        (list
          (* 0.15 (nth 0 perp2))
          (* 0.15 (nth 1 perp2))))

  (setq p2
        (list
          (+ (nth 0 head) (nth 0 off2))
          (+ (nth 1 head) (nth 1 off2))
          (nth 2 head)))

  ;; rotation angle � PURE MATH, NO COMMAND CALLS
  (setq ang (angle '(0 0 0)
                   (list (nth 0 vec) (nth 1 vec) 0)))

  ;; Apply Y-offset using pure math (NO UCS command interference)
  (setq s (sin ang))
  (setq c (cos ang))
  
  ;; Rotate offset vector by angle and apply
  (setq x_rot (* (- 0.15) s))   ;; perpendicular offset rotated
  (setq y_rot (* (- 0.15) c))

  (setq p2 (list 
    (+ (nth 0 p2) x_rot)
    (+ (nth 1 p2) y_rot)
    (nth 2 p2)))

  ;; Create text directly with GRADIENT COLOR and PROPER LAYER
  ;; NO UCS CHANGES � pure WCS coordinates
  (setq entlist
    (list
      (cons 0 "TEXT")
      (cons 8 "LA-MEX-LABEL")    ; Correct layer
      (cons 62 col)              ; Gradient color DIRECTLY in creation
      (cons 10 p2)
      (cons 40 1.5)              ; Increased height for visibility at various scales
      (cons 50 ang)
      (cons 210 (list 0 0 1))
      (cons 1 txt)
    )
  )

  (if MEX4-debug
    (princ "\n      Calling entmakex...")
  )

  (setq ent (entmakex entlist))

  (if ent
    (if MEX4-debug
      (princ "\n      ? Label created successfully")
    )
    (progn
      (princ "\n      ??? ENTMAKEX FAILED! Label NOT created.")
      (if MEX4-debug
        (progn
          (princ "\n      Entity list was:")
          (print entlist)
        )
      )
    )
  )

  (princ)
)

(defun LAS-LABEL-3D (pt layer traj-count /)
  (LAS-LABEL-COORD pt layer traj-count)
)


;---------------------------------------------------------------------
; LAYER CONSTANTS (match Rev3g for compatibility)
;---------------------------------------------------------------------

(setq MEX4-LAYER-TRAJ "ME3D_TRAJ")
(setq MEX4-LAYER-AUX  "ME3D_AUX")
(setq MEX4-LAYER-LBL  "0")            ;; labels always on Layer 0

;---------------------------------------------------------------------
; MAIN ENTRY POINT (called by launcher)
;---------------------------------------------------------------------

(defun C:MEXP3D-REV4 ( / )
  (setq MEX4-safe-return nil)

  (if MEX4-debug
    (princ "\n[MEX4] Starting Rev4 experimental engine..."))

  (MEXP3D-setup-layers)
  (MEXP3D_R4_MAIN)

  (setq MEX4-safe-return T)
  (princ)
)

;---------------------------------------------------------------------
; LEGACY CORE SHELL (kept for compatibility)
;---------------------------------------------------------------------

(defun MEXP3D-Rev4-core ( / A v0 steps dt cur )
  (if MEX4-debug
    (princ "\n[MEX4] Entering core engine shell..."))

  (setq cur   nil
        steps 200
        dt    0.05)

  (setq v0 (MEXP3D-get-initial-vector))
  (setq A  (MEXP3D-get-matrix))
  ;; placeholder � real work is now in MEXP3D_R4_MAIN
)

;---------------------------------------------------------------------
; INPUT + VALIDATION
;---------------------------------------------------------------------

(defun ME4-GETREAL-SAFE (msg / val)
  (setq val (getreal msg))
  (while (not (numberp val))
    (princ "\n  Please enter a valid number or 0.")
    (setq val (getreal msg))
    (if (null val) (setq val 0.0))
    (if (eq val T) (setq val 0.0))
  )
  val
)

(defun ME4-VALIDATE-TIME (tmin tmax dt / )
  (while (or (<= dt 0)
             (<= tmax tmin))
    (princ "\n[ME4] Invalid time parameters. Conditions:")
    (princ "\n       - dt   > 0")
    (princ "\n       - tmax > tmin")
    (princ "\nPlease re-enter time parameters.\n")

    (setq tmin (ME4-GETREAL-SAFE "\n  tmin: "))
    (setq tmax (ME4-GETREAL-SAFE "  tmax: "))
    (setq dt   (ME4-GETREAL-SAFE "  dt:   "))
  )
  (list tmin tmax dt)
)

(defun ME4-INPUT ( / a11 a12 a13 a21 a22 a23 a31 a32 a33
                      x1 x2 x3 tmin tmax dt A x0 timebundle )

  (princ "\n[MEXP3D Rev4] Enter system matrix A (3x3):")

  (setq a11 (ME4-GETREAL-SAFE "\n  A11: "))
  (setq a12 (ME4-GETREAL-SAFE "  A12: "))
  (setq a13 (ME4-GETREAL-SAFE "  A13: "))

  (setq a21 (ME4-GETREAL-SAFE "\n  A21: "))
  (setq a22 (ME4-GETREAL-SAFE "  A22: "))
  (setq a23 (ME4-GETREAL-SAFE "  A23: "))

  (setq a31 (ME4-GETREAL-SAFE "\n  A31: "))
  (setq a32 (ME4-GETREAL-SAFE "  A32: "))
  (setq a33 (ME4-GETREAL-SAFE "  A33: "))

  (setq A (list
            (list a11 a12 a13)
            (list a21 a22 a23)
            (list a31 a32 a33)
          ))

  (princ "\n[MEXP3D Rev4] Enter initial vector x0:")

  (setq x1 (ME4-GETREAL-SAFE "\n  x0_1: "))
  (setq x2 (ME4-GETREAL-SAFE "  x0_2: "))
  (setq x3 (ME4-GETREAL-SAFE "  x0_3: "))

  (setq x0 (list x1 x2 x3))

  (princ "\n[MEXP3D Rev4] Enter time parameters:")

  (setq tmin (ME4-GETREAL-SAFE "\n  tmin: "))
  (setq tmax (ME4-GETREAL-SAFE "  tmax: "))
  (setq dt   (ME4-GETREAL-SAFE "  dt:   "))

  (setq timebundle (ME4-VALIDATE-TIME tmin tmax dt))
  (setq tmin (nth 0 timebundle))
  (setq tmax (nth 1 timebundle))
  (setq dt   (nth 2 timebundle))

  (if MEX4-debug
    (progn
      (princ "\n[DEBUG] ME4-INPUT bundle = ")
      (print (list A x0 tmin tmax dt))
    )
  )

  ;;; ============================================================
  ;;;  SEEDING MODE PROMPT (RESTORED)
  ;;; ============================================================
  (initget "1 2 3 4 5 6")
  (setq mode
    (getkword
      "\nSeeding modes:
       1 = Axis seeds
       2 = Circle seeds (XY plane)
       3 = Sphere seeds
       4 = Cube corners
       5 = Custom shell
       6 = Manual
     Select seeding mode <1>: "
    )
  )
  (if (not mode) (setq mode "1"))

  ;;; ============================================================
  ;;;  RADIUS PROMPT (RESTORED)
  ;;; ============================================================
  (setq radius (ME4-GETREAL-SAFE "\nRadius for seeds <1.0>: "))
  (if (not radius) (setq radius 1.0))

  ;;; ============================================================
  ;;;  LABELING OPTIONS PROMPT � PEDAGOGICAL CHOICE
  ;;; ============================================================
  (initget "1 2")
  (setq labelMode
    (getkword
      "\nLabeling mode (pedagogical focus):
     1 = Phase-space families (label seeds only)
         ? Emphasize solutions emanating from initial conditions
     2 = Time dynamics (label main trajectory)
         ? Emphasize time parameterization along one solution
   Select labeling mode <1>: "
    )
  )
  (if (not labelMode) (setq labelMode "1"))

  
  (list A x0 tmin tmax dt mode radius labelMode)


)

;;; ================================================================
;;;  (3) CUBELATTICE LAYER - BASIS, SCALE, MAPPING
;;; ================================================================

(defun ME4-LATTICE-PARAMS ( / h o e1 e2 e3 )
  (setq h 10.0)
  (setq o (list 0.0 0.0 0.0))
  (setq e1 (list 1.0 0.0 0.0))
  (setq e2 (list 0.0 1.0 0.0))
  (setq e3 (list 0.0 0.0 1.0))
  (list h o e1 e2 e3)
)

(defun ME4-LATTICE-POINT (i j k / params h o e1 e2 e3 result)

  (setq params (ME4-LATTICE-PARAMS))
  (setq h  (car params)
        o  (cadr params)
        e1 (caddr params)
        e2 (cadddr params)
        e3 (car (cddddr params)))

  (setq result
    (list
      (+ (car o) (* h (+ (* i (car e1)) (* j (car e2)) (* k (car e3)))))
      (+ (cadr o) (* h (+ (* i (cadr e1)) (* j (cadr e2)) (* k (cadr e3)))))
      (+ (caddr o) (* h (+ (* i (caddr e1)) (* j (caddr e2)) (* k (caddr e3)))))
    )
  )

  result
)

(defun ME4-LATTICE-VEC->POINT (v / params h o e1 e2 e3 vx vy vz result)

  (setq params (ME4-LATTICE-PARAMS))
  (setq h  (car params)
        o  (cadr params)
        e1 (caddr params)
        e2 (cadddr params)
        e3 (car (cddddr params)))

  (setq vx (car v)
        vy (cadr v)
        vz (caddr v))

  (setq result
    (list
      (+ (car o) (* h (+ (* vx (car e1)) (* vy (car e2)) (* vz (car e3)))))
      (+ (cadr o) (* h (+ (* vx (cadr e1)) (* vy (cadr e2)) (* vz (cadr e3)))))
      (+ (caddr o) (* h (+ (* vx (caddr e1)) (* vy (caddr e2)) (* vz (caddr e3)))))
    )
  )

  result
)

;;; ================================================================
;;;  SEED GENERATION � Multiple Initial Conditions
;;; ================================================================

(defun ME4-GENERATE-SEEDS (mode radius / seeds i)
  (setq seeds '())
  (cond
    ;; Mode 1: Axis seeds (6 points)
    ((= mode "1")
     (setq seeds
       (list
         (list radius 0 0)
         (list (- radius) 0 0)
         (list 0 radius 0)
         (list 0 (- radius) 0)
         (list 0 0 radius)
         (list 0 0 (- radius))
       )
     )
    )
    ;; Mode 2: Circle seeds in XY plane
    ((= mode "2")
     (setq i 0)
     (while (< i 8)
       (setq seeds
         (append seeds
           (list
             (list
               (* radius (cos (* i (/ pi 4))))
               (* radius (sin (* i (/ pi 4))))
               0
             )
           )
         )
       )
       (setq i (1+ i))
     )
    )
    ;; Mode 3: Sphere seeds (6 points + center neighbors)
    ((= mode "3")
     (setq seeds
       (list
         (list radius 0 0)
         (list (- radius) 0 0)
         (list 0 radius 0)
         (list 0 (- radius) 0)
         (list 0 0 radius)
         (list 0 0 (- radius))
       )
     )
    )
    ;; Mode 4: Cube corners (8 points)
    ((= mode "4")
     (setq seeds
       (list
         (list radius radius radius)
         (list radius radius (- radius))
         (list radius (- radius) radius)
         (list radius (- radius) (- radius))
         (list (- radius) radius radius)
         (list (- radius) radius (- radius))
         (list (- radius) (- radius) radius)
         (list (- radius) (- radius) (- radius))
       )
     )
    )
    ;; Mode 5-6: Fallback to axis
    (T
     (setq seeds
       (list
         (list radius 0 0)
         (list (- radius) 0 0)
         (list 0 radius 0)
         (list 0 (- radius) 0)
       )
     )
    )
  )
  seeds
)

;;; ================================================================
;;;  TRAJECTORY COMPUTATION � From Any Starting Point
;;; ================================================================

(defun ME4-COMPUTE-TRAJ (A pt tmin tmax dt)
  (ME4-COMPUTE-STATES-R4 A pt tmin tmax dt)
)

;;; ================================================================
;;;  TRAJECTORY DRAWING � With Gradient Colors
;;; ================================================================

(defun ME4-DRAW-TRAJ (traj / pprev pcur count col lines-drawn ent)
  (setq pprev nil)
  (setq count 0)
  (setq lines-drawn 0)
  (foreach state traj
    (setq pcur (cadr state))
    (if pprev
      (progn
        (setq col (MEX4:GRADIENT-COLOR count 200))
        (setq ent (entmake
          (list
            '(0 . "LINE")
            '(8 . "LA-MEX-TRAJ")
            (cons 62 col)
            (cons 10 pprev)
            (cons 11 pcur)
          )
        ))
        (if ent
          (setq lines-drawn (1+ lines-drawn))
          (if MEX4-debug
            (princ (strcat "\n    ? entmake FAILED at segment " (itoa count)))
          )
        )
      )
    )
    (setq pprev pcur)
    (setq count (1+ count))
  )
  (if MEX4-debug
    (princ (strcat "\n  ? Trajectory: " (itoa (length traj)) " states, " (itoa lines-drawn) " lines drawn"))
  )
)

;;; ================================================================
;;;  POINT DRAWING � Seed Markers
;;; ================================================================

(defun ME4-DRAW-POINT (pt layer / ent)
  (entmake
    (list
      '(0 . "POINT")
      (cons 8 layer)
      (cons 62 2)  ; Yellow seed markers
      (cons 10 pt)
    )
  )
)

;;; ================================================================
;;;  POINT LABELING � For Seeds and Trajectory Points
;;; ================================================================

(defun ME4-LABEL (pt count / traj-count)
  ;; Route to existing label function
  ;; count = trajectory index for color progression, or 0 for seed labels
  (LAS-LABEL-COORD pt "LA-MEX-LABEL" count)
)

;;; ================================================================
;;;  (4) GEOMETRY - TRAJECTORY DRAWING + LABELS
;;; ================================================================

(defun ME4-GEOM-DRAW-TRAJECTORY (states / pprev pcur count tval col en line-count label-count)

  (setq pprev nil)
  (setq count 0)
  (setq line-count 0)
  (setq label-count 0)

  (foreach s states
    (setq tval (car s))
    (setq pcur (cadr s)) ;; (t x) ? x

    ;; Draw line segment with gradient color on proper layer
    (if pprev
      (progn
        ;; Calculate gradient color first
        (setq col (MEX4:GRADIENT-COLOR count 200))
        
        (if (entmake
          (list
            '(0 . "LINE")
            '(8 . "LA-MEX-TRAJ")    ; Assign to trajectory layer
            (cons 62 col)           ; Apply color directly in creation
            (cons 10 pprev)
            (cons 11 pcur)
          ))
          (setq line-count (1+ line-count))
        )
      )
    )

    ;; Label based on mode: trajectory (every 10th) or seeds-only (first point only)
    (if (or (and (eq *MEX4-label-mode-choice* 'trajectory) (= (rem count 10) 0))
            (and (eq *MEX4-label-mode-choice* 'seeds-only) (= count 0)))
      (cond
        ((eq MEX4-label-mode 'coord)
         ;; Safe coordinate label - pass count for color matching
         (LAS-LABEL-COORD pcur MEX4-LAYER-LBL count)
        )
        ((eq MEX4-label-mode '3d)
         ;; Safe 3D label - pass count for color matching
         (LAS-LABEL-3D pcur MEX4-LAYER-LBL count)
        )
      )
    )

    (setq pprev pcur)
    (setq count (1+ count))
  )

  pprev
)

;;; ================================================================
;;;  MATH ENGINE - PURE STATES, NO DRAWING
;;; ================================================================

(defun ME4-MUL-MAT-VEC (A x / r1 r2 r3)
  (setq r1 (car A)
        r2 (cadr A)
        r3 (caddr A))
  (list
    (+ (* (car   r1) (car x))
       (* (cadr  r1) (cadr x))
       (* (caddr r1) (caddr x)))
    (+ (* (car   r2) (car x))
       (* (cadr  r2) (cadr x))
       (* (caddr r2) (caddr x)))
    (+ (* (car   r3) (car x))
       (* (cadr  r3) (cadr x))
       (* (caddr r3) (caddr x)))
  )
)

(defun ME4-STEP-EULER (A x dt / Ax)
  (setq Ax (ME4-MUL-MAT-VEC A x))
  (list
    (+ (car x)   (* dt (car Ax)))
    (+ (cadr x)  (* dt (cadr Ax)))
    (+ (caddr x) (* dt (caddr Ax)))
  )
)

(defun ME4-COMPUTE-STATES-R4 (A x0 tmin tmax dt / t_step x_state states step-count max-steps)

  (setq t_step  tmin
        x_state x0
        states  '()
        step-count 0
        max-steps (fix (+ (/ (- tmax tmin) dt) 1.5)))  ; Add margin for FP rounding

  (while (<= step-count max-steps)
    (setq states (append states (list (list t_step x_state))))
    (setq x_state (ME4-STEP-EULER A x_state dt))
    (setq t_step (+ t_step dt))
    (setq step-count (1+ step-count))
  )

  states
)

(defun ME4-COMPUTE-STATES (A x0 tmin tmax dt / t_step x_state states)

  (setq t_step  tmin
        x_state x0
        states  '())

  (while (<= t_step tmax)
    (setq states (append states (list (list t_step x_state))))
    (setq x_state (ME4-STEP-EULER A x_state dt))
    (setq t_step (+ t_step dt))
  )

  states
)

;;; ================================================================
;;;  SANITIZER - ENSURE STATES ARE DRAWABLE
;;; ================================================================

(defun ME4-VALID-VEC3P (v)
  (and (listp v)
       (= (length v) 3)
       (numberp (car v))
       (numberp (cadr v))
       (numberp (caddr v)))
)

(defun ME4-SANITIZE-STATES (states / clean t_val x_val)
  (if (not (and (listp states) states))
    nil
    (progn
      (setq clean nil)
      (foreach s states
        (setq t_val (car s)
              x_val (cadr s))
        (if (and (numberp t_val)
                 (ME4-VALID-VEC3P x_val))
          (setq clean (append clean (list (list t_val x_val))))
        )
      )
      clean
    )
  )
)

;;; ================================================================
;;;  LAYER VISIBILITY HELPERS
;;; ================================================================

(defun ME4-ENSURE-LAYER-VISIBLE (layer-name /)
  ;; Simplified - just thaw the layer, no OFF property in this AC version
  (vl-catch-all-apply
    '(lambda  ()
       (vla-put-freeze  
         (vla-item (vla-get-layers (vla-get-activedocument (vlax-get-acad-object))) layer-name)
         :vlax-false)
     )
  )
  (if MEX4-debug
    (princ (strcat "\n  [LAYER] " layer-name " thawed"))
  )
)

(defun ME4-SNAPS-OFF ( / pol )
  (setq pol (getvar "POLAR"))
  (if (null pol) (setq pol 1))

  (setq *ME4-saved-snaps*
        (list
          (getvar "OSMODE")
          pol
          (getvar "3DOSMODE")
          (getvar "OSNAPCOORD")
          (getvar "AUTOSNAP")
        )
  )

  (setvar "OSMODE" 0)
  (vl-catch-all-apply '(lambda () (setvar "POLAR" 0)))
  (setvar "3DOSMODE" 0)
  (setvar "OSNAPCOORD" 0)
  (setvar "AUTOSNAP" 0)
)

(defun ME4-SNAPS-RESTORE ( / pol )
  (if *ME4-saved-snaps*
    (progn
      (setvar "OSMODE"      (nth 0 *ME4-saved-snaps*))
      (setq pol (nth 1 *ME4-saved-snaps*))
      (if (null pol) (setq pol 1))
      (vl-catch-all-apply '(lambda () (setvar "POLAR" pol)))
      (setvar "3DOSMODE"    (nth 2 *ME4-saved-snaps*))
      (setvar "OSNAPCOORD"  (nth 3 *ME4-saved-snaps*))
      (setvar "AUTOSNAP"    (nth 4 *ME4-saved-snaps*))
    )
  )
)

;;; ============================================================
;;;  MEX4:RUN � Multi-Trajectory Phase-Space Visualization
;;;  Supports:
;;;    - LabelMode = 1 (label seeds only) ? families of solutions
;;;    - LabelMode = 2 (label main trajectory) ? time dynamics
;;; ============================================================

(defun MEX4:RUN (A x0 tmin tmax dt mode radius labelMode
                  / seedList seedPt traj mainTraj stepCount seedCount)

  ;; Ask student for label style (A/B/C)
  (MEX4:CHOOSE-STYLE)

  ;; Reset label counter for this visualization
  (setq *MEX4-label-counter* 0)

  ;; Set label mode based on pedagogical choice
  (cond
    ((= labelMode "1")
     (setq *MEX4-label-mode-choice* 'seeds-only)
     (if MEX4-debug
       (princ "\n  [MEX4] Label mode: SEEDS-ONLY (will label seed points)")
     )
    )
    ((= labelMode "2")
     (setq *MEX4-label-mode-choice* 'trajectory)
     (if MEX4-debug
       (princ "\n  [MEX4] Label mode: TRAJECTORY (will label main trajectory)")
     )
    )
    (T
     (setq *MEX4-label-mode-choice* 'seeds-only)
     (if MEX4-debug
       (princ "\n  [MEX4] Label mode: DEFAULT (seeds-only)")
     )
    )
  )

  ;; Snap control
  (ME4-SNAPS-OFF)

  ;; *** ENSURE LAYERS ARE VISIBLE AND THAWED ***
  (ME4-ENSURE-LAYER-VISIBLE "LA-MEX-TRAJ")
  (ME4-ENSURE-LAYER-VISIBLE "LA-MEX-SEED")
  (ME4-ENSURE-LAYER-VISIBLE "LA-MEX-LABEL")

  (princ "\n[MEX4] Generating seeds...")
  (setq seedList (ME4-GENERATE-SEEDS mode radius))
  (princ (strcat "\n[MEX4] Seeds generated: " (itoa (length seedList)) " points"))
  (setq seedCount 0)

  ;; ============================================================
  ;; 1. Draw and label each seed point
  ;; ============================================================
  (foreach seedPt seedList
    (setq seedCount (1+ seedCount))
    (princ (strcat "\n[MEX4] Processing seed " (itoa seedCount) " at " 
                   (rtos (car seedPt) 2 3) "," 
                   (rtos (cadr seedPt) 2 3) "," 
                   (rtos (caddr seedPt) 2 3)))

    ;; Draw seed marker
    (if (ME4-DRAW-POINT seedPt "LA-MEX-SEED")
      (princ " ? Seed marker drawn")
      (princ " ? Seed marker FAILED")
    )

    ;; Label seed (LabelMode = 1 or 2) � pass count 0 for seed labels
    (if (or (= labelMode "1") (= labelMode "2"))
      (progn
        (if MEX4-debug
          (princ (strcat "\n    [SEED-LABEL] Calling ME4-LABEL for seed " (itoa seedCount)))
        )
        (ME4-LABEL seedPt 0)
      )
      (if MEX4-debug
        (princ "\n    [LABEL-SKIP] labelMode conditions not met")
      )
    )

    ;; ============================================================
    ;; 2. Compute and draw trajectory for this seed (NO LABELS)
    ;; ============================================================
    (princ " ? Computing trajectory...")
    (setq traj (ME4-COMPUTE-TRAJ A seedPt tmin tmax dt))
    (if traj
      (princ (strcat " (" (itoa (length traj)) " states)"))
    )
    (if (> (length traj) 0)
      (ME4-DRAW-TRAJ traj)
    )
  )

  ;; ============================================================
  ;; 3. Distinguished main trajectory from x0 (always drawn)
  ;; ============================================================
  (princ "\n[MEX4] Computing main trajectory from x0...")
  (setq mainTraj (ME4-COMPUTE-TRAJ A x0 tmin tmax dt))
  (if mainTraj
    (princ (strcat " (" (itoa (length mainTraj)) " states)"))
  )
  (if (> (length mainTraj) 0)
    (ME4-DRAW-TRAJ mainTraj)
  )

  ;; ============================================================
  ;; 4. Label sparse points along main trajectory if mode 2
  ;; ============================================================
  (if (= labelMode "2")
    (progn
      (princ "\n[MEX4] Labeling main trajectory (every 10th point)...")
      (setq stepCount 0)
      (foreach pt mainTraj
        (setq stepCount (1+ stepCount))
        ;; Label every 10th point with color gradient progression
        (if (= 0 (rem stepCount 10))
          (progn
            (if MEX4-debug
              (princ (strcat "\n  [TRAJ-LABEL] Label point " (itoa stepCount)))
            )
            (ME4-LABEL (cadr pt) stepCount)
          )
        )
      )
    )
    (if MEX4-debug
      (princ "\n[MEX4] Main trajectory labeling skipped (labelMode mode = 1)")
    )
  )

  ;; *** ENSURE LAYERS STAY VISIBLE AND THAWED ***
  (ME4-ENSURE-LAYER-VISIBLE "LA-MEX-TRAJ")
  (ME4-ENSURE-LAYER-VISIBLE "LA-MEX-SEED")
  (ME4-ENSURE-LAYER-VISIBLE "LA-MEX-LABEL")

  ;; Restore snap settings
  (ME4-SNAPS-RESTORE)

  ;; *** ZOOM ALL TO SHOW ALL ENTITIES ***
  (command "_.ZOOM" "_ALL")

  (princ "\n[MEX4] Done.")
  (princ)
)


(princ "\nMatrixExponential_Rev4 loaded.")
(defun C:MEX ( / bundle A x0 tmin tmax dt mode radius labelMode )

  (setq bundle (ME4-INPUT))

  (setq A        (nth 0 bundle))
  (setq x0       (nth 1 bundle))
  (setq tmin     (nth 2 bundle))
  (setq tmax     (nth 3 bundle))
  (setq dt       (nth 4 bundle))
  (setq mode     (nth 5 bundle))
  (setq radius   (nth 6 bundle))
  (setq labelMode (nth 7 bundle))

  (MEX4:RUN A x0 tmin tmax dt mode radius labelMode)

  (princ)
)

;;; ============================================================
;;;  END OF MODULE � MEXP3D (Rev4)
;;; ============================================================

(princ "\nMEXP3D Rev4 loaded. Command: MEX")
(princ)
