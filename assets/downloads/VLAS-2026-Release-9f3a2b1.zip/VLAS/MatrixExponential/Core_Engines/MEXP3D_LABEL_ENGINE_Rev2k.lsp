;=====================================================================
;  MEXP3D_LABEL_ENGINE_Rev2k  —  Label Engine for Matrix Exponential 3D
;  LinearAlgebraSuite_Safe
;
;  File:        MEXP3D_LABEL_ENGINE_Rev2k.lsp
;  Revision:    Rev2k (2026)
;  Status:      SAFE‑REV / Production‑Grade
;
;  Author:      Chris A. LaFollette
;  Copyright:   © 2026 Chris A. LaFollette
;
;  Description:
;     Stable SAFE‑REV label engine for 3D matrix exponential trajectory
;     visualization. Provides rotation‑aware, UCS‑safe text placement for:
;         • component labels
;         • vector head labels
;         • auxiliary vector lines
;         • tail dots
;     Ensures consistent alignment, offset logic, and pedagogical clarity
;     across all SAFE‑REV modules that rely on MEXP3D trajectory output.
;
;  SAFE‑SUITE Notes:
;     - ASCII‑only labels (x, y, z, v, components)
;     - No Smart Label Engine; labels are diagram‑anchored and local
;     - All UCS transforms are isolated and restored
;     - No persistent UCS or view modifications
;     - No layer creation here; required layers must be provided by the
;       SAFE‑REV launcher/template or calling module
;
;  Required Layers (provided by launcher/template or caller):
;     ME3D_LABELS      (Continuous, blue)   — component labels
;     ME3D_AUX         (Continuous, tan)    — vector lines and tail dots
;     0                (Continuous, white)  — vector head labels (“v”)
;
;  Baseline Linetype Settings:
;     LTSCALE    = 5
;     CELTSCALE  = 1
;     PSLTSCALE  = 1
;
;  Architecture (SAFE‑REV):
;     - Provides stable, minimal‑geometry entmake blocks.
;     - All text placement is rotation‑aware and UCS‑safe.
;     - Layer colors and behaviors are controlled by the SAFE‑REV launcher.
;     - Designed for compatibility across AutoCAD versions and student
;       machines with restricted UCS behavior.
;
;  Legal:
;     Redistribution, modification, or inclusion in other software is
;     prohibited without written permission from the author. This file is
;     part of the LinearAlgebraSuite_Safe SAFE‑REV collection and is
;     included in the 2026 copyright deposit.
;
;=====================================================================



(vl-load-com)

;---------------------------------------------------------------------
; CREATE TRUE-TYPE TEXT STYLE FOR COMPONENT LABELS (Arial)
;   Must be created BEFORE any TEXT entities are drawn.
;---------------------------------------------------------------------
(if (not (tblsearch "STYLE" "ME3D_TTF"))
  (entmake
    (list
      (cons 0 "STYLE")
      (cons 100 "AcDbSymbolTableRecord")
      (cons 100 "AcDbTextStyleTableRecord")
      (cons 2 "ME3D_TTF")
      (cons 70 0)
      (cons 40 0.0)
      (cons 41 1.0)
      (cons 50 0.0)
      (cons 71 0)
      (cons 42 0.0)
      (cons 3 "arial.ttf")
      (cons 4 ""))))

;---------------------------------------------------------------------
; CREATE LABEL LAYER (dark blue for components + tail dots)
;---------------------------------------------------------------------
(if (not (tblsearch "LAYER" "ME3D_LABELS"))
  (entmake
    (list
      (cons 0 "LAYER")
      (cons 100 "AcDbSymbolTableRecord")
      (cons 100 "AcDbLayerTableRecord")
      (cons 2 "ME3D_LABELS")
      (cons 70 0)
      (cons 62 160)
      (cons 6 "Continuous"))))

;---------------------------------------------------------------------
; INTERNAL: safe 2D length
;---------------------------------------------------------------------
(defun ME3D-len2 (v)
  (sqrt (+ (* (nth 0 v) (nth 0 v))
           (* (nth 1 v) (nth 1 v))))
)

;---------------------------------------------------------------------
; INTERNAL: 2D unit vector
;---------------------------------------------------------------------
(defun ME3D-unit2 (v / L)
  (setq L (ME3D-len2 v))
  (if (> L 1e-9)
    (list (/ (nth 0 v) L) (/ (nth 1 v) L))
    (list 1.0 0.0))
)

;---------------------------------------------------------------------
; INTERNAL: 2D perpendicular vector
;---------------------------------------------------------------------
(defun ME3D-perp2 (u)
  (list (- (nth 1 u)) (nth 0 u))
)

;---------------------------------------------------------------------
; VECTOR LABEL (WHITE, ALIGNED, WORLD-Y POST-OFFSET)
;---------------------------------------------------------------------
(defun ME3D-label-vector (origin vec txt / oldUCS head u2 perp2 off2 p2 ang ent)
  (setq oldUCS (getvar "UCSNAME"))

  ;; head point
  (setq head
        (list
          (+ (nth 0 origin) (nth 0 vec))
          (+ (nth 1 origin) (nth 1 vec))
          (+ (nth 2 origin) (nth 2 vec))))

  ;; direction + perpendicular
  (setq u2   (ME3D-unit2 (list (nth 0 vec) (nth 1 vec))))
  (setq perp2 (ME3D-perp2 u2))

  ;; perpendicular offset
  (setq off2
        (list
          (* 0.15 (nth 0 perp2))
          (* 0.15 (nth 1 perp2))))

  ;; base label point in WCS
  (setq p2
        (list
          (+ (nth 0 head) (nth 0 off2))
          (+ (nth 1 head) (nth 1 off2))
          (nth 2 head)))

  ;; rotation angle
  (setq ang (angle '(0 0 0)
                   (list (nth 0 vec) (nth 1 vec) 0)))

  ;; rotate UCS
  (command "_.UCS" "_Z" ang)

  ;; transform into UCS
  (setq p2 (trans p2 0 1))
  ;; detect -X direction (angle near pi)
(if (and (> ang (* 0.75 pi)) (< ang (* 1.25 pi)))
    ;; flip upward for -X
    (setq p2 (list (nth 0 p2) (+ (nth 1 p2) 0.15) (nth 2 p2)))
    ;; normal downward drop
    (setq p2 (list (nth 0 p2) (- (nth 1 p2) 0.15) (nth 2 p2))))


  ;; create rotated white text
  (setq ent
    (entmakex
      (list
        (cons 0 "TEXT")
        (cons 8 "0")
        (cons 10 p2)
        (cons 40 0.20)
        (cons 50 ang)
        (cons 210 (list 0 0 1))
        (cons 1 txt))))

  ;; restore UCS
  (if (and oldUCS (/= oldUCS ""))
    (command "_.UCS" "_R" oldUCS)
    (command "_.UCS" "_W"))

  ;; FINAL FIX: apply world-Y offset AFTER UCS restore
  (command "_.MOVE" ent "" '(0 0 0) '(0 -0.15 0))

  (princ)
)

;---------------------------------------------------------------------
; COMPONENT LABEL (DARK BLUE, SOLID TTF, ALIGNED)
;---------------------------------------------------------------------
(defun ME3D-label-components (origin vec / oldUCS oldStyle u2 perp2 off2 p2 ang txt)
  (setq oldUCS (getvar "UCSNAME"))
  (setq oldStyle (getvar "TEXTSTYLE"))

  ;; switch to TTF style
  (setvar "TEXTSTYLE" "ME3D_TTF")

  ;; build text
  (setq txt
        (strcat
          "( "
          (rtos (nth 0 origin) 2 3)
          " , "
          (rtos (nth 1 origin) 2 3)
          " , "
          (rtos (nth 2 origin) 2 3)
          " )"))

  ;; direction + perpendicular
  (setq u2   (ME3D-unit2 (list (nth 0 vec) (nth 1 vec))))
  (setq perp2 (ME3D-perp2 u2))

  ;; offset at tail
  (setq off2
        (list
          (* 0.12 (nth 0 perp2))
          (* 0.12 (nth 1 perp2))))

  ;; label point
  (setq p2
        (list
          (+ (nth 0 origin) (nth 0 off2))
          (+ (nth 1 origin) (nth 1 off2))
          (nth 2 origin)))

  ;; rotation angle
  (setq ang (angle '(0 0 0)
                   (list (nth 0 vec) (nth 1 vec) 0)))

  ;; rotate UCS
  (command "_.UCS" "_Z" ang)

  ;; transform into UCS
  (setq p2 (trans p2 0 1))
  (setq p2 (polar p2 (+ ang (/ pi 2)) 0.15))


  ;; create rotated dark-blue TTF text
  (entmake
    (list
      (cons 0 "TEXT")
      (cons 8 "ME3D_LABELS")
      (cons 7 "ME3D_TTF")
      (cons 10 p2)
      (cons 40 0.12)
      (cons 50 ang)
      (cons 210 (list 0 0 1))
      (cons 1 txt)))

  ;; restore TEXTSTYLE + UCS
  (setvar "TEXTSTYLE" oldStyle)

  (if (and oldUCS (/= oldUCS ""))
    (command "_.UCS" "_R" oldUCS)
    (command "_.UCS" "_W"))

  (princ)
)

;---------------------------------------------------------------------
; VECTOR LINE + TAIL DOT  (now on ME3D_AUX = tan)
;---------------------------------------------------------------------
(defun ME3D-draw-vector (origin vec)
  ;; main vector line
  (entmake
    (list
      (cons 0 "LINE")
      (cons 8 "ME3D_AUX")   ; CHANGED from ME3D_LABELS
      (cons 10 origin)
      (cons 11
            (list
              (+ (nth 0 origin) (nth 0 vec))
              (+ (nth 1 origin) (nth 1 vec))
              (+ (nth 2 origin) (nth 2 vec))))))

  ;; tiny tail dot
  (entmake
    (list
      (cons 0 "CIRCLE")
      (cons 8 "ME3D_AUX")   ; CHANGED from ME3D_LABELS
      (cons 10 origin)
      (cons 40 0.05)))

  (princ)
)
;---------------------------------------------------------------------
; [last function in the file ends here]
;---------------------------------------------------------------------


;=====================================================================
;  END OF FILE: MEXP3D_LABEL_ENGINE_Rev2k.lsp
;
;  This module is part of the cadcando Visual Linear Algebra System.
;  All geometry and label routines in this file are stable, UCS‑safe,
;  and designed for predictable behavior under the Rev1a launcher and
;  the MatrixExponential_Rev3g core module.
;  This module is part of the cadcando Visual Linear Algebra System.
;  Licensed to the end user after purchase from the official VLAS site.
;  Redistribution, resale, or modification without written permission
;  is prohibited.
;  Revision 2k is the frozen, production‑ready label engine for the
;  Matrix Exponential 3D suite. Future enhancements should be added
;  as new revisions rather than modifying this file directly.
;=====================================================================

(princ "\nMEXP3D_LABEL_ENGINE_Rev2k.lsp loaded.")
(princ)
