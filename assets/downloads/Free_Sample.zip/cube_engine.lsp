;;; ==========================================
;;; cube_engine.lsp
;;; Centered cubes, two offsets:
;;; - Internal cube to cube offset  (between cubes)
;;; - Box to cube offset            (air gap to outer box)
;;; Each cube drawn individually (12 edges)
;;; ==========================================

;;; ---- Helper: ask for positive real with default ----
(defun ce-ask-positive-real (msg default / val)
  (while
    (progn
      (setq val (getreal msg))
      (cond
        ((and (null val) default) (setq val default) nil)
        ((or (null val) (<= val 0.0))
         (prompt "\nPlease enter a positive number.")
         T
        )
        (T nil)
      )
    )
  )
  val
)

;;; ---- Helper: ask for integer with soft limit ----
(defun ce-ask-int-soft-limit (msg default softMax / n raw override)
  (while
    (progn
      (setq raw (getint msg))
      (cond
        ((and (null raw) default) (setq n default))
        ((or (null raw) (< raw 1))
         (prompt "\nPlease enter an integer >= 1.")
         (setq n nil)
        )
        (T (setq n raw))
      )

      (cond
        ((null n) T)
        ((<= n softMax) nil)
        (T
         (prompt
           (strcat
             "\nYou entered " (itoa n)
             ". Recommended maximum is "
             (itoa softMax) "."
           )
         )
         (initget "Yes No")
         (setq override (getkword "\nProceed anyway? [Yes/No] <No>: "))
         (if (or (null override) (= override "No"))
           (progn (setq n nil) T)
           nil
         )
        )
      )
    )
  )
  n
)

;;; ---- Core spans: internal cube block only ----
;;; cubeSize    = cube edge
;;; offInternal = cube-to-cube offset
;;; nx,ny,nz    = counts
(defun ce-internal-spans (cubeSize offInternal nx ny nz
                          / spanX spanY spanZ)
  (setq spanX (+ (* nx cubeSize)
                 (* (max 0 (1- nx)) offInternal)))
  (setq spanY (+ (* ny cubeSize)
                 (* (max 0 (1- ny)) offInternal)))
  (setq spanZ (+ (* nz cubeSize)
                 (* (max 0 (1- nz)) offInternal)))
  (list spanX spanY spanZ)
)

;;; ---- Outer extents from internal spans + box-to-cube offset ----
(defun ce-outer-extents (spanX spanY spanZ offOuter
                          / outerX outerY outerZ)
  (setq outerX (+ spanX (* 2.0 offOuter)))
  (setq outerY (+ spanY (* 2.0 offOuter)))
  (setq outerZ (+ spanZ (* 2.0 offOuter)))
  (list outerX outerY outerZ)
)

;;; ---- Draw one cube (12 edges), given its min corner ----
;;; p0 = (x0 y0 z0) is the lower-left-back corner of the cube
(defun ce-draw-one-cube (p0 cubeSize / x0 y0 z0 x1 y1 z1 c)
  (setq x0 (car p0)
        y0 (cadr p0)
        z0 (caddr p0)
        x1 (+ x0 cubeSize)
        y1 (+ y0 cubeSize)
        z1 (+ z0 cubeSize))

  ;; 8 corners
  (setq c
    (list
      (list x0 y0 z0) ; 0
      (list x1 y0 z0) ; 1
      (list x1 y1 z0) ; 2
      (list x0 y1 z0) ; 3
      (list x0 y0 z1) ; 4
      (list x1 y0 z1) ; 5
      (list x1 y1 z1) ; 6
      (list x0 y1 z1) ; 7
    )
  )

  (defun ce-edge (i j / p1 p2)
    (setq p1 (nth i c)
          p2 (nth j c))
    (entmakex
      (list
        (cons 0 "LINE")
        (cons 10 p1)
        (cons 11 p2)
      )
    )
  )

  ;; bottom
  (ce-edge 0 1)
  (ce-edge 1 2)
  (ce-edge 2 3)
  (ce-edge 3 0)

  ;; top
  (ce-edge 4 5)
  (ce-edge 5 6)
  (ce-edge 6 7)
  (ce-edge 7 4)

  ;; verticals
  (ce-edge 0 4)
  (ce-edge 1 5)
  (ce-edge 2 6)
  (ce-edge 3 7)

  (princ)
)

;;; ---- Draw all cubes (each individually) ----
;;; origin      = center of the entire cube block
;;; cubeSize    = cube edge
;;; offInternal = cube-to-cube offset
;;; nx,ny,nz    = counts
(defun ce-draw-all-cubes (origin cubeSize offInternal nx ny nz
                           / ox oy oz spans spanX spanY spanZ
                             startX startY startZ
                             stepX stepY stepZ
                             i j k x0 y0 z0)

  (setq ox (car origin)
        oy (cadr origin)
        oz (caddr origin))

  (setq spans (ce-internal-spans cubeSize offInternal nx ny nz)
        spanX (nth 0 spans)
        spanY (nth 1 spans)
        spanZ (nth 2 spans))

  ;; internal block min corner (centered)
  (setq startX (- ox (/ spanX 2.0)))
  (setq startY (- oy (/ spanY 2.0)))
  (setq startZ (- oz (/ spanZ 2.0)))

  ;; step between cube origins
  (setq stepX (+ cubeSize offInternal))
  (setq stepY (+ cubeSize offInternal))
  (setq stepZ (+ cubeSize offInternal))

  (setq i 0)
  (while (< i nx)
    (setq x0 (+ startX (* i stepX)))
    (setq j 0)
    (while (< j ny)
      (setq y0 (+ startY (* j stepY)))
      (setq k 0)
      (while (< k nz)
        (setq z0 (+ startZ (* k stepZ)))
        (ce-draw-one-cube (list x0 y0 z0) cubeSize)
        (setq k (1+ k))
      )
      (setq j (1+ j))
    )
    (setq i (1+ i))
  )

  (princ)
)

;;; ---- Draw outer box, centered around cube block + box-to-cube offset ----
(defun ce-draw-outer-box (origin cubeSize offInternal offOuter nx ny nz
                            / ox oy oz spans spanX spanY spanZ
                              outs outerX outerY outerZ
                              halfX halfY halfZ corners)

  (setq ox (car origin)
        oy (cadr origin)
        oz (caddr origin))

  (setq spans (ce-internal-spans cubeSize offInternal nx ny nz)
        spanX (nth 0 spans)
        spanY (nth 1 spans)
        spanZ (nth 2 spans))

  (setq outs   (ce-outer-extents spanX spanY spanZ offOuter)
        outerX (nth 0 outs)
        outerY (nth 1 outs)
        outerZ (nth 2 outs))

  (setq halfX (/ outerX 2.0)
        halfY (/ outerY 2.0)
        halfZ (/ outerZ 2.0))

  (setq corners
    (list
      (list (- ox halfX) (- oy halfY) (- oz halfZ)) ; 0
      (list (+ ox halfX) (- oy halfY) (- oz halfZ)) ; 1
      (list (+ ox halfX) (+ oy halfY) (- oz halfZ)) ; 2
      (list (- ox halfX) (+ oy halfY) (- oz halfZ)) ; 3
      (list (- ox halfX) (- oy halfY) (+ oz halfZ)) ; 4
      (list (+ ox halfX) (- oy halfY) (+ oz halfZ)) ; 5
      (list (+ ox halfX) (+ oy halfY) (+ oz halfZ)) ; 6
      (list (- ox halfX) (+ oy halfY) (+ oz halfZ)) ; 7
    )
  )

  (defun ce-obox-edge (i j / p1 p2)
    (setq p1 (nth i corners)
          p2 (nth j corners))
    (entmakex
      (list
        (cons 0 "LINE")
        (cons 10 p1)
        (cons 11 p2)
      )
    )
  )

  ;; bottom
  (ce-obox-edge 0 1)
  (ce-obox-edge 1 2)
  (ce-obox-edge 2 3)
  (ce-obox-edge 3 0)

  ;; top
  (ce-obox-edge 4 5)
  (ce-obox-edge 5 6)
  (ce-obox-edge 6 7)
  (ce-obox-edge 7 4)

  ;; verticals
  (ce-obox-edge 0 4)
  (ce-obox-edge 1 5)
  (ce-obox-edge 2 6)
  (ce-obox-edge 3 7)

  (princ)
)

;;; ---- Top-level command: CUBELATTICE_ENGINE ----
;;; Self-contained test command for this engine.
(defun c:CUBELATTICE_ENGINE (/ origin cubeSize offInternal offOuter nx ny nz
                                useOuter oldLayer)

  (prompt "\nCUBELATTICE_ENGINE: Centered cubes with two offsets.")

  ;; If you have *CUBE_CENTER* from SETCENTER, use it; else default to (0,0,0)
  (setq origin (if (and (boundp '*CUBE_CENTER*) *CUBE_CENTER*)
                 *CUBE_CENTER*
                 '(0.0 0.0 0.0)
               )
  )

  ;; Internal cube size
  (setq cubeSize
        (ce-ask-positive-real
          "\nEnter internal cube size <5.0>: "
          5.0))

  ;; Internal cube-to-cube offset
  (setq offInternal
        (ce-ask-positive-real
          "\nEnter Internal cube to cube offset <1.0>: "
          1.0))

  ;; Box-to-cube offset (air gap)
  (setq offOuter
        (ce-ask-positive-real
          "\nEnter Box to cube offset <2.0>: "
          2.0))

  ;; Counts
  (setq nx (ce-ask-int-soft-limit "\nEnter cubes in X direction <5>: " 5 25))
  (setq ny (ce-ask-int-soft-limit "\nEnter cubes in Y direction <5>: " 5 25))
  (setq nz (ce-ask-int-soft-limit "\nEnter cubes in Z direction <5>: " 5 25))

  ;; Draw outer box?
  (initget "Yes No")
  (setq useOuter (getkword "\nDraw outer box? [Yes/No] <Yes>: "))
  (if (null useOuter) (setq useOuter "Yes"))

  ;; Layer setup
  (setq oldLayer (getvar "CLAYER"))

  (if (not (tblsearch "LAYER" "OUTER"))
    (command "-LAYER" "M" "OUTER" "C" "1" "" "")
  )
  (if (not (tblsearch "LAYER" "CUBES"))
    (command "-LAYER" "M" "CUBES" "C" "8" "" "")
  )

  ;; Outer on OUTER
  (if (= useOuter "Yes")
    (progn
      (command "-LAYER" "S" "OUTER" "")
      (ce-draw-outer-box origin cubeSize offInternal offOuter nx ny nz)
    )
  )

  ;; Cubes on CUBES
  (command "-LAYER" "S" "CUBES" "")
  (ce-draw-all-cubes origin cubeSize offInternal nx ny nz)

  ;; Restore layer
  (command "-LAYER" "S" oldLayer "")

  (prompt "\nCUBELATTICE_ENGINE completed.")
  (princ)
)
