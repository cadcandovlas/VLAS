;;; ==========================================
;;; BASISFRAMEPLUS 4.0
;;; Core: 3.2 (clean vectors + TEXT labels)
;;; Extras (all optional, default No):
;;;  1. Arrowheads
;;;  2. Origin marker (circle or cross)
;;;  3. Label offset
;;;  4. Magnitude display
;;;  5. Orthogonality check
;;;  6. Orthonormality check
;;;  7. Normal vector (e1 x e2)
;;;  8. Coordinate planes
;;;  9. Parallelepiped
;;; ==========================================

;;; ---------- Helpers: geometry & layers ----------

(defun bfp40-ensure-layer (name color / tbl)
  (setq tbl (tblsearch "LAYER" name))
  (if tbl
    name
    (progn
      (entmakex
        (list
          (cons 0 "LAYER")
          (cons 2 name)
          (cons 70 0)
          (cons 62 color)
        )
      )
      name
    )
  )
)

(defun bfp40-make-line (p1 p2 layerName)
  (entmakex
    (list
      (cons 0 "LINE")
      (cons 8 layerName)
      (cons 10 p1)
      (cons 11 p2)
      (cons 62 256)
    )
  )
)

(defun bfp40-make-text (p h text layerName / styleName)
  (setq styleName (getvar "TEXTSTYLE"))
  (entmakex
    (list
      (cons 0 "TEXT")
      (cons 8 layerName)
      (cons 10 p)
      (cons 40 h)
      (cons 1 text)
      (cons 7 styleName)
    )
  )
)

(defun bfp40-make-circle (center radius layerName)
  (entmakex
    (list
      (cons 0 "CIRCLE")
      (cons 8 layerName)
      (cons 10 center)
      (cons 40 radius)
    )
  )
)

(defun bfp40-make-cross (center size layerName / cx cy cz h)
  (setq cx (car center)
        cy (cadr center)
        cz (caddr center)
        h  (/ size 2.0))
  (bfp40-make-line
    (list (- cx h) cy cz)
    (list (+ cx h) cy cz)
    layerName
  )
  (bfp40-make-line
    (list cx (- cy h) cz)
    (list cx (+ cy h) cz)
    layerName
  )
)

(defun bfp40-vadd (a b)
  (list (+ (car a) (car b))
        (+ (cadr a) (cadr b))
        (+ (caddr a) (caddr b))))

(defun bfp40-vsub (a b)
  (list (- (car a) (car b))
        (- (cadr a) (cadr b))
        (- (caddr a) (caddr b))))

(defun bfp40-vscale (s v)
  (list (* s (car v))
        (* s (cadr v))
        (* s (caddr v))))

(defun bfp40-dot (a b)
  (+ (* (car a) (car b))
     (* (cadr a) (cadr b))
     (* (caddr a) (caddr b))))

(defun bfp40-mag (v)
  (sqrt (bfp40-dot v v)))

(defun bfp40-cross (a b)
  (list
    (- (* (cadr a) (caddr b)) (* (caddr a) (cadr b)))
    (- (* (caddr a) (car b)) (* (car a) (caddr b)))
    (- (* (car a) (cadr b)) (* (cadr a) (car b)))
  )
)

(defun bfp40-unit (v / m)
  (setq m (bfp40-mag v))
  (if (> m 0.0)
    (bfp40-vscale (/ 1.0 m) v)
    '(0 0 0)
  )
)

;;; ---------- Arrowhead (if enabled) ----------

(defun bfp40-make-arrow (tip dir size layerName / u ref perp1 perp2 b1 b2)
  (setq u (bfp40-unit dir))
  (if (< (abs (car u)) 0.0001)
    (setq ref '(1 0 0))
    (setq ref '(0 0 1))
  )
  (setq perp1 (bfp40-cross u ref))
  (setq perp2 (bfp40-cross u perp1))
  (setq perp1 (bfp40-vscale size perp1))
  (setq perp2 (bfp40-vscale size perp2))
  (setq b1 (bfp40-vadd tip perp1))
  (setq b2 (bfp40-vadd tip perp2))
  (entmakex
    (list
      (cons 0 "SOLID")
      (cons 8 layerName)
      (cons 10 tip)
      (cons 11 b1)
      (cons 12 b2)
      (cons 13 b2)
    )
  )
)

;;; ---------- Planes and parallelepiped ----------

(defun bfp40-make-3dface (p1 p2 p3 p4 layerName)
  (entmakex
    (list
      (cons 0 "3DFACE")
      (cons 8 layerName)
      (cons 10 p1)
      (cons 11 p2)
      (cons 12 p3)
      (cons 13 p4)
      (cons 70 0)
    )
  )
)

(defun bfp40-draw-plane (origin v1 v2 layerName)
  (setq p0 origin)
  (setq p1 (bfp40-vadd origin v1))
  (setq p2 (bfp40-vadd origin (bfp40-vadd v1 v2)))
  (setq p3 (bfp40-vadd origin v2))
  (bfp40-make-3dface p0 p1 p2 p3 layerName)
)

(defun bfp40-draw-parallelepiped (origin e1 e2 e3 layerName / o e1p e2p e3p e12 e13 e23 top)
  (setq o   origin)
  (setq e1p (bfp40-vadd o e1))
  (setq e2p (bfp40-vadd o e2))
  (setq e3p (bfp40-vadd o e3))
  (setq e12 (bfp40-vadd e1p e2))
  (setq e13 (bfp40-vadd e1p e3))
  (setq e23 (bfp40-vadd e2p e3))
  (setq top (bfp40-vadd o (bfp40-vadd e1 (bfp40-vadd e2 e3))))

  ;; edges from origin
  (bfp40-make-line o e1p layerName)
  (bfp40-make-line o e2p layerName)
  (bfp40-make-line o e3p layerName)

  ;; edges on base rectangle
  (bfp40-make-line e1p e12 layerName)
  (bfp40-make-line e2p e12 layerName)
  (bfp40-make-line e1p e13 layerName)
  (bfp40-make-line e3p e13 layerName)
  (bfp40-make-line e2p e23 layerName)
  (bfp40-make-line e3p e23 layerName)

  ;; vertical edges to top
  (bfp40-make-line e12 top layerName)
  (bfp40-make-line e13 top layerName)
  (bfp40-make-line e23 top layerName)

  ;; faces (optional visual solidity)
  (bfp40-make-3dface o   e1p e12 e2p layerName)
  (bfp40-make-3dface o   e1p e13 e3p layerName)
  (bfp40-make-3dface o   e2p e23 e3p layerName)
  (bfp40-make-3dface top e12 e1p e13 layerName)
  (bfp40-make-3dface top e12 e2p e23 layerName)
  (bfp40-make-3dface top e13 e3p e23 layerName)
)

;;; ---------- Main command ----------

(defun c:BASISFRAMEPLUS4_0
  ( / originChoice origin
     e1x e1y e1z e2x e2y e2z e3x e3y e3z
     e1 e2 e3
     end1 end2 end3
     layE1 layE2 layE3 layOrigin layPlane layBox layNormal
     oldLayer oldLweight
     txtHeight
     optArrow optOrigin optLabelOffset optMagnitudes
     optOrtho optOrthon optNormal optPlanes optBox
     offsetVec otext1 otext2 otext3
     mag1 mag2 mag3 normal normalEnd)

  (prompt "\nBASISFRAMEPLUS 4.0: 3.2 core + optional features.")

  ;; Save system vars
  (setq oldLayer   (getvar "CLAYER"))
  (setq oldLweight (getvar "CELWEIGHT"))

  ;; Origin
  (initget "Yes No")
  (setq originChoice (getkword "\nSpecify custom origin? [Yes/No] <No>: "))
  (if (null originChoice) (setq originChoice "No"))
  (setq origin
    (if (= originChoice "Yes")
      (getpoint "\nPick origin point: ")
      '(0 0 0)
    )
  )

  ;; Basis vectors
  (prompt "\nEnter basis vector e1:")
  (setq e1x (getreal "\n e1_x: "))
  (setq e1y (getreal "  e1_y: "))
  (setq e1z (getreal "  e1_z: "))
  (setq e1 (list e1x e1y e1z))
  (setq end1 (bfp40-vadd origin e1))

  (prompt "\nEnter basis vector e2:")
  (setq e2x (getreal "\n e2_x: "))
  (setq e2y (getreal "  e2_y: "))
  (setq e2z (getreal "  e2_z: "))
  (setq e2 (list e2x e2y e2z))
  (setq end2 (bfp40-vadd origin e2))

  (prompt "\nEnter basis vector e3:")
  (setq e3x (getreal "\n e3_x: "))
  (setq e3y (getreal "  e3_y: "))
  (setq e3z (getreal "  e3_z: "))
  (setq e3 (list e3x e3y e3z))
  (setq end3 (bfp40-vadd origin e3))

  ;; Layers
  (setq layE1     (bfp40-ensure-layer "BASIS-E1"      1))
  (setq layE2     (bfp40-ensure-layer "BASIS-E2"      3))
  (setq layE3     (bfp40-ensure-layer "BASIS-E3"      5))
  (setq layOrigin (bfp40-ensure-layer "BASIS-ORIGIN"  8))
  (setq layPlane  (bfp40-ensure-layer "BASIS-PLANE"   9))
  (setq layBox    (bfp40-ensure-layer "BASIS-BOX"     7))
  (setq layNormal (bfp40-ensure-layer "BASIS-NORMAL"  2))

  ;; Options (all default No)
  (initget "Yes No")
  (setq optArrow (getkword "\nArrowheads? [Yes/No] <No>: "))
  (if (null optArrow) (setq optArrow "No"))

  (initget "Circle Cross None")
  (setq optOrigin (getkword "\nOrigin marker? [Circle/Cross/None] <None>: "))
  (if (null optOrigin) (setq optOrigin "None"))

  (initget "Yes No")
  (setq optLabelOffset (getkword "\nOffset labels from tips? [Yes/No] <No>: "))
  (if (null optLabelOffset) (setq optLabelOffset "No"))

  (initget "Yes No")
  (setq optMagnitudes (getkword "\nShow magnitudes? [Yes/No] <No>: "))
  (if (null optMagnitudes) (setq optMagnitudes "No"))

  (initget "Yes No")
  (setq optOrtho (getkword "\nCheck orthogonality? [Yes/No] <No>: "))
  (if (null optOrtho) (setq optOrtho "No"))

  (initget "Yes No")
  (setq optOrthon (getkword "\nCheck orthonormality? [Yes/No] <No>: "))
  (if (null optOrthon) (setq optOrthon "No"))

  (initget "Yes No")
  (setq optNormal (getkword "\nDraw normal vector e1 x e2? [Yes/No] <No>: "))
  (if (null optNormal) (setq optNormal "No"))

  (initget "Yes No")
  (setq optPlanes (getkword "\nDraw coordinate planes? [Yes/No] <No>: "))
  (if (null optPlanes) (setq optPlanes "No"))

  (initget "Yes No")
  (setq optBox (getkword "\nDraw parallelepiped? [Yes/No] <No>: "))
  (if (null optBox) (setq optBox "No"))

  ;; Text height
  (setq txtHeight (getreal "\nEnter basis label text height <0.5>: "))
  (if (null txtHeight) (setq txtHeight 0.5))

  ;; Make lines thicker
  (setvar "CELWEIGHT" 50)

  ;; Origin marker
  (cond
    ((= optOrigin "Circle")
     (bfp40-make-circle origin (/ txtHeight 2.0) layOrigin)
    )
    ((= optOrigin "Cross")
     (bfp40-make-cross origin txtHeight layOrigin)
    )
  )

  ;; Draw main vectors
  (bfp40-make-line origin end1 layE1)
  (bfp40-make-line origin end2 layE2)
  (bfp40-make-line origin end3 layE3)

  ;; Arrowheads (optional)
  (if (= optArrow "Yes")
    (progn
      (bfp40-make-arrow end1 e1 (* txtHeight 0.2) layE1)
      (bfp40-make-arrow end2 e2 (* txtHeight 0.2) layE2)
      (bfp40-make-arrow end3 e3 (* txtHeight 0.2) layE3)
    )
  )

  ;; Label positions (offset or not)
  (setq offsetVec (bfp40-vscale 0.2 (bfp40-unit (bfp40-vadd e1 e2))))
  (if (= optLabelOffset "Yes")
    (progn
      (setq otext1 (bfp40-vadd end1 offsetVec))
      (setq otext2 (bfp40-vadd end2 offsetVec))
      (setq otext3 (bfp40-vadd end3 offsetVec))
    )
    (progn
      (setq otext1 end1)
      (setq otext2 end2)
      (setq otext3 end3)
    )
  )

  ;; TEXT labels for e1, e2, e3
  (bfp40-make-text otext1 txtHeight "e1" layE1)
  (bfp40-make-text otext2 txtHeight "e2" layE2)
  (bfp40-make-text otext3 txtHeight "e3" layE3)

  ;; Magnitudes (optional)
  (if (= optMagnitudes "Yes")
    (progn
      (setq mag1 (bfp40-mag e1))
      (setq mag2 (bfp40-mag e2))
      (setq mag3 (bfp40-mag e3))
      (bfp40-make-text
        (bfp40-vadd otext1 (list 0 (* txtHeight 1.2) 0))
        txtHeight
        (strcat "|e1|=" (rtos mag1 2 3))
        layE1
      )
      (bfp40-make-text
        (bfp40-vadd otext2 (list 0 (* txtHeight 1.2) 0))
        txtHeight
        (strcat "|e2|=" (rtos mag2 2 3))
        layE2
      )
      (bfp40-make-text
        (bfp40-vadd otext3 (list 0 (* txtHeight 1.2) 0))
        txtHeight
        (strcat "|e3|=" (rtos mag3 2 3))
        layE3
      )
    )
  )

  ;; Orthogonality check (optional)
  (if (= optOrtho "Yes")
    (progn
      (prompt
        (strcat
          "\nDot(e1,e2)=" (rtos (bfp40-dot e1 e2) 2 6)
          ", Dot(e1,e3)=" (rtos (bfp40-dot e1 e3) 2 6)
          ", Dot(e2,e3)=" (rtos (bfp40-dot e2 e3) 2 6)
        )
      )
    )
  )

  ;; Orthonormality check (optional)
  (if (= optOrthon "Yes")
    (progn
      (prompt
        (strcat
          "\n|e1|=" (rtos (bfp40-mag e1) 2 6)
          ", |e2|=" (rtos (bfp40-mag e2) 2 6)
          ", |e3|=" (rtos (bfp40-mag e3) 2 6)
        )
      )
    )
  )

  ;; Normal vector (e1 x e2) (optional)
  (if (= optNormal "Yes")
    (progn
      (setq normal (bfp40-cross e1 e2))
      (setq normalEnd (bfp40-vadd origin normal))
      (bfp40-make-line origin normalEnd layNormal)
      (bfp40-make-text
        (bfp40-vadd normalEnd (list 0 (* txtHeight 0.5) 0))
        txtHeight
        "n"
        layNormal
      )
    )
  )

  ;; Coordinate planes (optional)
  (if (= optPlanes "Yes")
    (progn
      (bfp40-draw-plane origin e1 e2 layPlane)
      (bfp40-draw-plane origin e1 e3 layPlane)
      (bfp40-draw-plane origin e2 e3 layPlane)
    )
  )

  ;; Parallelepiped (optional)
  (if (= optBox "Yes")
    (bfp40-draw-parallelepiped origin e1 e2 e3 layBox)
  )

  ;; Restore system vars
  (setvar "CLAYER" oldLayer)
  (setvar "CELWEIGHT" oldLweight)

  (prompt "\nBASISFRAMEPLUS 4.0: Done.")
  
  ;; Zoom to full drawing
  (command "_.ZOOM" "A")
  
  (princ)
)
